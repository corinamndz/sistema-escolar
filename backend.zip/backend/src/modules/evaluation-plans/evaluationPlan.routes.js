const router = require('express').Router();
const controller = require('./evaluationPlan.controller');
const { authMiddleware } = require('../../middlewares/auth.middleware');
const { tenantMiddleware } = require('../../middlewares/tenant.middleware');
const { requirePermission } = require('../../middlewares/permission.middleware');
const scope = require('../access/teacherScope');
const activityExcel = require('./activityExcel.controller');
const { importUpload } = require('../../middlewares/upload.middleware');

// Docente: solo los planes de las materias y secciones de su carga (los demás → 404).
const ownPlan = (param) => scope.guardParam(scope.assertPlanAccess, param);
const ownProject = scope.guardParam(scope.assertProjectAccess, 'projectId');

router.use(authMiddleware, tenantMiddleware);

// Evaluación detallada desde Excel: plantilla y lectura para llenar el formulario (no guarda nada).
router.get('/activity-template', requirePermission('evaluation_plans', 'create'), activityExcel.downloadTemplate);
router.post('/activity-template/parse', requirePermission('evaluation_plans', 'create'), importUpload, activityExcel.parse);

router.get('/terms', requirePermission('evaluation_plans', 'read'), controller.listTerms);

// Opciones del formulario de planes, filtradas por la carga docente (antes de "/:id").
router.get('/options/school-periods', requirePermission('evaluation_plans', 'read'), controller.listPeriodOptions);
router.get('/options/sections', requirePermission('evaluation_plans', 'read'), controller.listSectionOptions);
router.get('/options/sections/:id/assignment', requirePermission('evaluation_plans', 'read'), controller.getSectionAssignmentOptions);

router.get('/', requirePermission('evaluation_plans', 'read'), controller.listPlans);
router.post('/', requirePermission('evaluation_plans', 'create'), controller.createPlan);
router.get('/:id', requirePermission('evaluation_plans', 'read'), ownPlan('id'), controller.getPlan);
// Reporte de confirmaciones de lectura de los representantes (Dirección y el docente del plan).
router.get('/:planId/acknowledgments', requirePermission('evaluation_plans', 'read'), ownPlan('planId'), controller.listAcknowledgments);
router.put('/:planId', requirePermission('evaluation_plans', 'update'), ownPlan('planId'), controller.updatePlan);
// Eliminar: permiso de borrar planes y, si es docente, que el plan sea de su carga.
router.delete('/:planId', requirePermission('evaluation_plans', 'delete'), ownPlan('planId'), controller.deletePlan);

router.post('/:planId/project', requirePermission('evaluation_plans', 'create'), ownPlan('planId'), controller.createProject);
router.post('/projects/:projectId/competencies', requirePermission('evaluation_plans', 'update'), ownProject, controller.addCompetency);

router.post('/:planId/activities', requirePermission('evaluation_plans', 'create'), ownPlan('planId'), controller.createActivity);
router.put('/:planId/activities/:activityId', requirePermission('evaluation_plans', 'update'), ownPlan('planId'), controller.updateActivity);
router.patch('/:planId/activities/:activityId/content', requirePermission('evaluation_plans', 'update'), ownPlan('planId'), controller.setActivityContent);
router.delete('/:planId/activities/:activityId', requirePermission('evaluation_plans', 'delete'), ownPlan('planId'), controller.deleteActivity);

router.post('/:planId/close', requirePermission('evaluation_plans', 'update'), ownPlan('planId'), controller.closePlan);
router.post('/:planId/reopen', requirePermission('evaluation_plans', 'update'), ownPlan('planId'), controller.reopenPlan);
// Duplicar para otro año escolar (crea un plan nuevo en el destino).
router.post('/:planId/duplicate', requirePermission('evaluation_plans', 'create'), ownPlan('planId'), controller.duplicatePlan);

module.exports = router;

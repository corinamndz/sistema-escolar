const { ApiError } = require('../../utils/ApiError');
const { exclusionOf } = require('../academics/sectionSubjects');
const { assertContentForPlan, sortByProgram } = require('../programmatic-content/programmaticContent.service');
const { weekendDay, weekendMessage } = require('../../utils/weekdays');

// ---------- Períodos/periodos ----------

async function listTerms(trx, tenantId, { schoolPeriodId } = {}) {
  const query = trx('terms').where({ tenant_id: tenantId }).orderByRaw('term_number NULLS LAST, start_date NULLS LAST, name');
  if (schoolPeriodId) query.andWhere({ school_period_id: schoolPeriodId });
  return query;
}

/** Período en la posición N del año; si el año no la tiene, error (se configuran en Configuración → Períodos de evaluación). */
async function ensureTerm(trx, tenantId, schoolPeriodId, termNumber) {
  const found = await trx('terms').where({ tenant_id: tenantId, school_period_id: schoolPeriodId, term_number: termNumber }).first();
  if (found) return found;
  const period = await trx('school_periods').where({ id: schoolPeriodId, tenant_id: tenantId }).first('name');
  throw ApiError.unprocessable(`El año escolar ${period?.name || ''} no tiene el período ${termNumber}: configúralo en Configuración → Períodos de evaluación.`, [{ path: 'termNumber', message: 'Período inexistente.' }]);
}

/** Período del plan a partir de su posición (`termNumber`) o de `termId`. */
async function resolveTermId(trx, tenantId, schoolPeriodId, { termId, termNumber }) {
  if (termNumber) return (await ensureTerm(trx, tenantId, schoolPeriodId, termNumber)).id;
  if (termId) return termId;
  throw ApiError.badRequest('Indica el período de evaluación.', [{ path: 'termNumber', message: 'Requerido.' }]);
}

// ---------- Planes de evaluación ----------

async function listPlans(trx, tenantId, { sectionId, termId, termNumber, teacherId } = {}) {
  const query = trx('evaluation_plans as ep')
    .join('sections as sec', 'sec.id', 'ep.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('education_levels as el', 'el.code', 'g.level_code')
    .join('terms as t', 't.id', 'ep.term_id')
    .join('staff as st', 'st.id', 'ep.teacher_id')
    .leftJoin('subjects as sub', 'sub.id', 'ep.subject_id')
    .where('ep.tenant_id', tenantId)
    .select(
      'ep.*',
      // Clave y nombre de la materia para agrupar (Materia → Período → planes):
      // la del catálogo si el plan tiene subject_id; si no (Inicial), el área escrita.
      trx.raw("COALESCE(ep.subject_id::text, 'txt:' || lower(trim(ep.subject))) AS subject_key"),
      trx.raw('COALESCE(sub.name, ep.subject) AS subject_name'),
      'sub.code as subject_code',
      'sec.name as section_name',
      'g.name as grade_name',
      'g.level_code',
      'el.name as level_name',
      't.name as term_name',
      't.term_number',
      't.school_period_id',
      trx.raw("st.first_name || ' ' || st.last_name AS teacher_name"),
      // Todas las secciones a las que se aplica el plan ("A, B").
      trx.raw(
        `(SELECT string_agg(s2.name, ', ' ORDER BY s2.name) FROM evaluation_plan_sections x
          JOIN sections s2 ON s2.id = x.section_id WHERE x.plan_id = ep.id) AS section_names`
      ),
      // Avance del plan: cuántas actividades tiene y cuánto suman sus porcentajes.
      trx.raw('(SELECT count(*)::int FROM evaluation_activities a WHERE a.evaluation_plan_id = ep.id) AS activity_count'),
      trx.raw('(SELECT COALESCE(sum(a.weight_percent), 0)::float FROM evaluation_activities a WHERE a.evaluation_plan_id = ep.id) AS total_weight')
    )
    // Orden lógico: Materia (A-Z) → Período (I, II, III) → grado (jerarquía escolar) → sección.
    .orderByRaw('lower(COALESCE(sub.name, ep.subject)), t.term_number NULLS LAST, el.sort_order, g.sort_order, sec.name, ep.created_at');
  // Filtrar por sección incluye los planes compartidos en los que participa.
  if (sectionId) {
    query.whereExists(trx('evaluation_plan_sections as x').whereRaw('x.plan_id = ep.id').andWhere('x.section_id', sectionId));
  }
  if (termId) query.andWhere('ep.term_id', termId);
  if (termNumber) query.andWhere('t.term_number', termNumber);
  if (teacherId) query.andWhere('ep.teacher_id', teacherId);
  return query;
}

/** Secciones del plan (la principal primero). */
async function listPlanSections(trx, planId) {
  return trx('evaluation_plan_sections as x')
    .join('sections as s', 's.id', 'x.section_id')
    .join('evaluation_plans as ep', 'ep.id', 'x.plan_id')
    .where('x.plan_id', planId)
    .select('s.id', 's.name', trx.raw('(s.id = ep.section_id) AS is_main'))
    .orderByRaw('(s.id = ep.section_id) DESC, s.name');
}

/**
 * Estructura detallada de varias actividades: criterios con sus indicadores,
 * fechas de aplicación por sección y si ya tienen notas. Map activityId → datos.
 */
async function loadActivityStructure(trx, activityIds) {
  if (activityIds.length === 0) return new Map();
  const [criteria, indicators, dates, scored] = [
    await trx('evaluation_criteria').whereIn('activity_id', activityIds).orderBy('position'),
    await trx('evaluation_indicators').whereIn('activity_id', activityIds).orderBy('position'),
    await trx('activity_section_dates').whereIn('activity_id', activityIds),
    await trx('activity_scores').whereIn('evaluation_activity_id', activityIds).distinct('evaluation_activity_id').pluck('evaluation_activity_id'),
  ];
  const map = new Map();
  activityIds.forEach((id) => {
    map.set(id, {
      criteria: criteria
        .filter((c) => c.activity_id === id)
        .map((c) => ({
          id: c.id,
          title: c.title,
          position: c.position,
          indicators: indicators
            .filter((i) => i.criterion_id === c.id)
            .map((i) => ({ id: i.id, description: i.description, points: Number(i.points), position: i.position })),
        })),
      section_dates: dates.filter((d) => d.activity_id === id).map((d) => ({ section_id: d.section_id, applied_on: d.applied_on })),
      has_scores: scored.includes(id),
    });
  });
  return map;
}

async function getPlanWithActivities(trx, tenantId, planId) {
  const plan = await trx('evaluation_plans as ep')
    .join('terms as t', 't.id', 'ep.term_id')
    .join('sections as sec', 'sec.id', 'ep.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .where({ 'ep.id': planId, 'ep.tenant_id': tenantId })
    .select('ep.*', 't.name as term_name', 't.term_number', 't.school_period_id', 't.start_date as term_start', 't.end_date as term_end', 'g.name as grade_name', 'g.level_code', 'g.grading_scale', 'sec.grade_id')
    .first();
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');

  // En el orden del contenido programático (unidad → tema), como en todas las vistas del plan.
  const rows = await sortByProgram(trx, await trx('evaluation_activities').where({ tenant_id: tenantId, evaluation_plan_id: planId }));
  const structure = await loadActivityStructure(trx, rows.map((a) => a.id));
  const contentIds = [...new Set(rows.map((a) => a.programmatic_content_id).filter(Boolean))];
  const contents = new Map(
    (contentIds.length ? await trx('programmatic_content').whereIn('id', contentIds).select('id', 'unit', 'topic') : []).map((c) => [c.id, c])
  );
  const activities = rows.map((a) => ({
    ...a,
    max_score: Number(a.max_score),
    ...structure.get(a.id),
    programmatic_content: contents.get(a.programmatic_content_id) || null,
  }));

  // Redondeo a centésimas: los porcentajes son NUMERIC(5,2) y 33.33 + 33.33 + 33.34 debe dar 100.
  const totalWeight = Math.round(activities.reduce((sum, a) => sum + Number(a.weight_percent), 0) * 100) / 100;

  const project = await trx('pedagogical_projects')
    .where({ tenant_id: tenantId, evaluation_plan_id: planId })
    .first();

  let competencies = [];
  if (project) {
    competencies = await trx('project_competencies')
      .where({ tenant_id: tenantId, pedagogical_project_id: project.id });
  }
  // La actividad del proyecto lo lleva consigo (se lista como una actividad más del plan).
  const projectView = project ? { ...project, competencies } : null;
  const linked = project?.evaluation_activity_id ? activities.find((a) => a.id === project.evaluation_activity_id) : null;
  if (linked) linked.project = projectView;

  // Secciones del mismo grado y año que se podrían sumar al plan (para la edición).
  const sections = await listPlanSections(trx, planId);
  const candidates = await trx('sections')
    .where({ tenant_id: tenantId, grade_id: plan.grade_id, school_period_id: trx('sections').where({ id: plan.section_id }).select('school_period_id') })
    .whereNotIn('id', sections.map((s) => s.id))
    // Solo las secciones donde se dicta la materia (migración 037).
    .modify((q) => plan.subject_id && q.whereNotExists(exclusionOf(trx, trx.ref('sections.id'), plan.subject_id)))
    .select('id', 'name')
    .orderBy('name');

  // Para "Mover a otra sección" (plan creado en la sección equivocada): solo
  // mientras no tenga notas; destinos = secciones del mismo año cuyo grado
  // incluye la materia (o, sin materia del catálogo, las del mismo grado).
  const hasGrades = await planHasGrades(trx, planId);
  const moveTargets = hasGrades
    ? []
    : await trx('sections as s')
        .join('grades as g', 'g.id', 's.grade_id')
        .join('education_levels as el', 'el.code', 'g.level_code')
        .where({ 's.tenant_id': tenantId, 's.school_period_id': plan.school_period_id })
        .whereNot('s.id', plan.section_id)
        .modify((q) => {
          if (plan.subject_id) q.whereExists(trx('grade_subjects as gs').whereRaw('gs.grade_id = g.id').andWhere('gs.subject_id', plan.subject_id)).whereNotExists(exclusionOf(trx, trx.ref('s.id'), plan.subject_id));
          else q.andWhere('s.grade_id', plan.grade_id);
        })
        .select('s.id', 's.name', 'g.name as grade_name')
        .orderBy([{ column: 'el.sort_order' }, { column: 'g.sort_order' }, { column: 's.name' }]);

  return {
    ...plan,
    sections,
    available_sections: candidates,
    has_grades: hasGrades,
    move_targets: moveTargets,
    activities,
    totalWeight,
    pedagogicalProject: projectView,
  };
}

async function loadSection(trx, tenantId, sectionId) {
  const section = await trx('sections as sec')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('education_levels as el', 'el.code', 'g.level_code')
    .where({ 'sec.id': sectionId, 'sec.tenant_id': tenantId })
    .select('sec.*', 'g.name as grade_name', 'el.name as level_name', 'el.assignment_mode', 'el.has_curriculum')
    .first();
  if (!section) throw ApiError.notFound('Sección no encontrada.');
  return section;
}

/**
 * Docente y materia del plan en UNA sección, según el nivel del grado:
 *  - Secundaria: `subjectId` obligatorio; la materia debe tener profesor
 *    asignado en la sección y el plan queda a nombre de ese profesor.
 *  - Primaria (con plan de estudios cargado): `subjectId` obligatorio, de una
 *    materia del plan del grado. Docente: el especialista de esa materia si lo
 *    hay; si no, el titular de la sección.
 *  - Inicial, o Primaria cuyo grado aún no tiene materias: `subject` es un
 *    área de texto libre y el docente debe ser el titular o el auxiliar.
 * Devuelve { teacherId, subject, subjectId (o null si es área libre) }.
 */
async function resolveSectionTeacher(trx, section, { teacherId: requestedTeacherId, subject: subjectText, subjectId }) {
  const where = `la sección ${section.name}`;
  let teacherId = requestedTeacherId;
  let subject = subjectText?.trim();

  const curriculumSize = section.has_curriculum
    ? Number((await trx('grade_subjects as gs').where({ 'gs.grade_id': section.grade_id }).whereNotExists(exclusionOf(trx, section.id, trx.ref('gs.subject_id'))).count('* as n').first()).n)
    : 0;
  const homeroomWithCurriculum = section.assignment_mode === 'homeroom' && curriculumSize > 0;

  if (homeroomWithCurriculum) {
    // ---- Primaria con plan de estudios ----
    if (!subjectId) {
      throw ApiError.badRequest(`En ${section.grade_name} el plan debe asociarse a una materia del plan de estudios.`, [
        { path: 'subjectId', message: 'Selecciona la materia.' },
      ]);
    }
    const inCurriculum = await trx('grade_subjects as gs')
      .join('subjects as s', 's.id', 'gs.subject_id')
      .where({ 'gs.grade_id': section.grade_id, 'gs.subject_id': subjectId })
      .whereNotExists(exclusionOf(trx, section.id, trx.ref('gs.subject_id')))
      .select('s.name')
      .first();
    if (!inCurriculum) {
      throw ApiError.unprocessable(`Esa materia no forma parte del plan de estudios de ${section.grade_name}.`, [
        { path: 'subjectId', message: 'No está en el plan de estudios.' },
      ]);
    }
    const specialist = await trx('teacher_subject_sections as t')
      .join('staff as st', 'st.id', 't.staff_id')
      .where({ 't.section_id': section.id, 't.subject_id': subjectId })
      .select('t.staff_id', 'st.first_name', 'st.last_name')
      .first();
    if (specialist) {
      if (teacherId && teacherId !== specialist.staff_id) {
        throw ApiError.unprocessable(
          `${inCurriculum.name} en ${where} la dicta el especialista ${specialist.first_name} ${specialist.last_name}.`,
          [{ path: 'teacherId', message: 'No es el docente de la materia.' }]
        );
      }
      teacherId = specialist.staff_id;
    } else {
      const homeroom = await trx('teacher_sections').where({ section_id: section.id }).select('staff_id', 'role');
      const lead = homeroom.find((h) => h.role === 'lead');
      if (!lead) {
        throw ApiError.unprocessable(`${where[0].toUpperCase()}${where.slice(1)} no tiene docente titular. Asígnalo antes de crear planes.`);
      }
      if (teacherId && !homeroom.some((h) => h.staff_id === teacherId)) {
        throw ApiError.unprocessable(`El docente debe ser el titular de ${where} o el especialista de la materia.`, [
          { path: 'teacherId', message: 'No está asignado a esta materia.' },
        ]);
      }
      teacherId = teacherId || lead.staff_id;
    }
    return { teacherId, subject: inCurriculum.name, subjectId };
  }

  if (section.assignment_mode === 'subjects') {
    if (!subjectId) {
      throw ApiError.badRequest(`En ${section.level_name} el plan debe asociarse a una materia del plan de estudios.`, [
        { path: 'subjectId', message: 'Selecciona la materia.' },
      ]);
    }
    const assignment = await trx('teacher_subject_sections as t')
      .join('subjects as s', 's.id', 't.subject_id')
      .join('staff as st', 'st.id', 't.staff_id')
      .where({ 't.section_id': section.id, 't.subject_id': subjectId })
      .select('s.name as subject_name', 't.staff_id', 'st.first_name', 'st.last_name')
      .first();
    if (!assignment) {
      throw ApiError.unprocessable(`Esa materia no tiene profesor asignado en ${where}. Asígnalo primero.`, [
        { path: 'subjectId', message: 'Sin profesor asignado.' },
      ]);
    }
    if (teacherId && teacherId !== assignment.staff_id) {
      throw ApiError.unprocessable(
        `${assignment.subject_name} en ${where} está asignada a ${assignment.first_name} ${assignment.last_name}.`,
        [{ path: 'teacherId', message: 'No es el profesor asignado.' }]
      );
    }
    return { teacherId: assignment.staff_id, subject: assignment.subject_name, subjectId };
  }

  if (!subject) {
    throw ApiError.badRequest('Indica el área o asignatura del plan.', [{ path: 'subject', message: 'Requerido.' }]);
  }
  const homeroom = await trx('teacher_sections').where({ section_id: section.id }).pluck('staff_id');
  if (homeroom.length === 0) {
    throw ApiError.unprocessable(`${where[0].toUpperCase()}${where.slice(1)} no tiene docente asignado. Asígnalo antes de crear planes.`);
  }
  if (!teacherId || !homeroom.includes(teacherId)) {
    throw ApiError.unprocessable(`El docente debe ser el titular o el auxiliar de ${where}.`, [
      { path: 'teacherId', message: 'No está asignado a esta sección.' },
    ]);
  }
  return { teacherId, subject, subjectId: null };
}

/**
 * Valida un conjunto de secciones para un plan: mismo grado y año escolar, el
 * mismo docente en todas (según su asignación), y que ninguna tenga ya un plan
 * de esa materia en ese período. Devuelve { sections, teacherId, subject, subjectId }.
 */
async function resolvePlanSections(trx, tenantId, sectionIds, input, { termId, excludePlanId = null }) {
  const ids = [...new Set(sectionIds)];
  const sections = [];
  for (const id of ids) sections.push(await loadSection(trx, tenantId, id));
  const main = sections[0];
  const odd = sections.find((s) => s.grade_id !== main.grade_id || s.school_period_id !== main.school_period_id);
  if (odd) {
    throw ApiError.unprocessable(`Todas las secciones del plan deben ser de ${main.grade_name} en el mismo año escolar (${odd.grade_name} ${odd.name} no lo es).`, [
      { path: 'sectionIds', message: 'Mismo grado y año escolar.' },
    ]);
  }

  const term = await trx('terms').where({ id: termId, tenant_id: tenantId }).first();
  if (!term || term.school_period_id !== main.school_period_id) {
    throw ApiError.badRequest('El período no pertenece al año escolar de la sección.', [{ path: 'termId', message: 'Período inválido.' }]);
  }

  let resolved = null;
  for (const section of sections) {
    const r = await resolveSectionTeacher(trx, section, input);
    if (resolved && r.teacherId !== resolved.teacherId) {
      const [a, b] = await trx('staff').whereIn('id', [resolved.teacherId, r.teacherId]).select('id', 'first_name', 'last_name');
      const name = (id) => [a, b].filter(Boolean).find((s) => s.id === id);
      const other = name(r.teacherId);
      throw ApiError.unprocessable(
        `${r.subject} la dicta otro docente en la sección ${section.name}${other ? ` (${other.first_name} ${other.last_name})` : ''}: un plan compartido debe ser del mismo docente en todas sus secciones.`,
        [{ path: 'sectionIds', message: 'Distinto docente.' }]
      );
    }
    resolved = resolved || r;
  }

  // Una sección no puede tener dos planes de la misma materia, período y docente.
  const taken = await trx('evaluation_plan_sections as x')
    .join('evaluation_plans as o', 'o.id', 'x.plan_id')
    .join('sections as s', 's.id', 'x.section_id')
    .where({ 'o.tenant_id': tenantId, 'o.term_id': termId, 'o.teacher_id': resolved.teacherId })
    .whereRaw('lower(o.subject) = lower(?)', [resolved.subject])
    .whereIn('x.section_id', ids)
    .modify((q) => excludePlanId && q.whereNot('o.id', excludePlanId))
    .select('s.name')
    .first();
  if (taken) {
    throw ApiError.conflict(`La sección ${taken.name} ya tiene un plan de ${resolved.subject} para este período y docente.`, [
      { path: 'sectionIds', message: 'Sección con plan.' },
    ]);
  }
  return { sections, ...resolved };
}

/**
 * Crea un plan de evaluación para una o varias secciones del mismo grado
 * (`sectionIds`; `sectionId` sigue funcionando para una sola). La primera es la
 * sección principal. `format`: 'simple' (por defecto) o 'detailed'.
 */
async function createPlan(trx, tenantId, { sectionId, sectionIds, termId: requestedTermId, termNumber, format = 'simple', ...input }) {
  const ids = sectionIds?.length ? sectionIds : [sectionId];
  if (!ids[0]) throw ApiError.badRequest('Indica al menos una sección.', [{ path: 'sectionIds', message: 'Requerido.' }]);
  const main = await loadSection(trx, tenantId, ids[0]);
  const termId = await resolveTermId(trx, tenantId, main.school_period_id, { termId: requestedTermId, termNumber });
  const { sections, teacherId, subject, subjectId } = await resolvePlanSections(trx, tenantId, ids, input, { termId });

  const [plan] = await trx('evaluation_plans')
    .insert({
      tenant_id: tenantId,
      section_id: sections[0].id,
      term_id: termId,
      teacher_id: teacherId,
      subject,
      subject_id: subjectId,
      format,
    })
    .returning('*');
  for (const s of sections) {
    await trx('evaluation_plan_sections').insert({ tenant_id: tenantId, plan_id: plan.id, section_id: s.id });
  }
  return { ...plan, section_ids: sections.map((s) => s.id) };
}

/**
 * Cambia el formato, el período académico o las secciones de un plan.
 *  - Período: el plan (con sus actividades y notas) pasa a otro período del mismo
 *    año, si el plan está abierto y ninguna de sus secciones tiene ya un plan
 *    de esa materia y docente en el período destino.
 *  - detallado → simple: solo si ninguna actividad tiene criterios/indicadores.
 *  - Quitar una sección: solo si sus alumnos no tienen notas en el plan.
 *  - Agregar: mismas reglas que al crear (grado, docente, sin plan duplicado).
 */
/** true si algún alumno ya tiene nota (o evaluación de competencias) en el plan. */
async function planHasGrades(trx, planId) {
  const score = await trx('activity_scores as sc')
    .join('evaluation_activities as a', 'a.id', 'sc.evaluation_activity_id')
    .where('a.evaluation_plan_id', planId)
    .first('sc.student_id');
  if (score) return true;
  const assessment = await trx('competency_assessments as ca')
    .join('project_competencies as pc', 'pc.id', 'ca.project_competency_id')
    .join('pedagogical_projects as pp', 'pp.id', 'pc.pedagogical_project_id')
    .where('pp.evaluation_plan_id', planId)
    .first('ca.student_id');
  return Boolean(assessment);
}

/**
 * Mueve un plan a OTRA sección (p. ej. se creó por error en 1er Año A en vez
 * de 3er Año A). Conserva actividades, ponderaciones y proyecto; solo se
 * permite mientras ningún alumno tenga notas en él. Valida el destino con las
 * mismas reglas que al crear: mismo año escolar, materia en el plan de
 * estudios del grado, docente de la materia en esa sección y sin otro plan de
 * la misma materia, período y docente. El plan queda solo en esa sección.
 */
async function movePlanToSection(trx, tenantId, plan, targetSectionId) {
  const current = await trx('evaluation_plan_sections').where({ plan_id: plan.id }).pluck('section_id');
  if (plan.section_id === targetSectionId && current.length === 1) return;
  if (await planHasGrades(trx, plan.id)) {
    throw ApiError.conflict('El plan ya tiene notas cargadas: no se puede mover a otra sección.', [{ path: 'moveToSectionId', message: 'Tiene notas.' }]);
  }
  const origin = await loadSection(trx, tenantId, plan.section_id);
  const target = await loadSection(trx, tenantId, targetSectionId);
  if (target.school_period_id !== origin.school_period_id) {
    throw ApiError.unprocessable('Solo se puede mover a una sección del mismo año escolar.', [{ path: 'moveToSectionId', message: 'Otro año escolar.' }]);
  }
  // Mismo docente si lo dicta en la sección destino; si no, resolvePlanSections explica el motivo.
  const resolved = await resolvePlanSections(
    trx,
    tenantId,
    [targetSectionId],
    { teacherId: plan.teacher_id, subject: plan.subject, subjectId: plan.subject_id },
    { termId: plan.term_id, excludePlanId: plan.id }
  );
  const activityIds = trx('evaluation_activities').where({ evaluation_plan_id: plan.id }).select('id');
  await trx('activity_section_dates').whereIn('activity_id', activityIds).delete();
  await trx('evaluation_plan_sections').where({ plan_id: plan.id }).delete();
  await trx('evaluation_plans')
    .where({ id: plan.id })
    .update({ section_id: targetSectionId, teacher_id: resolved.teacherId, subject: resolved.subject, subject_id: resolved.subjectId ?? plan.subject_id });
  await trx('evaluation_plan_sections').insert({ tenant_id: tenantId, plan_id: plan.id, section_id: targetSectionId });
  // El contenido programático es por grado: en otro grado sus actividades quedan sin contenido.
  if (target.grade_id !== origin.grade_id) {
    await trx('evaluation_activities').where({ evaluation_plan_id: plan.id }).whereNotNull('programmatic_content_id').update({ programmatic_content_id: null });
  }
  plan.section_id = targetSectionId;
}

async function updatePlan(trx, tenantId, planId, { format, sectionIds, termNumber, termId, moveToSectionId }) {
  const plan = await trx('evaluation_plans').where({ id: planId, tenant_id: tenantId }).forUpdate().first();
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');

  if (moveToSectionId) {
    await movePlanToSection(trx, tenantId, plan, moveToSectionId);
    return getPlanWithActivities(trx, tenantId, planId);
  }

  if (termNumber || termId) {
    const period = (await trx('terms').where({ id: plan.term_id }).first()).school_period_id;
    const newTermId = await resolveTermId(trx, tenantId, period, { termId, termNumber });
    if (newTermId !== plan.term_id) {
      if (plan.status === 'closed') throw ApiError.conflict('El plan está cerrado: reábrelo para cambiar su período.', [{ path: 'termNumber', message: 'Plan cerrado.' }]);
      const target = await trx('terms').where({ id: newTermId, tenant_id: tenantId }).first();
      if (!target || target.school_period_id !== period) {
        throw ApiError.badRequest('El período no pertenece al año escolar del plan.', [{ path: 'termNumber', message: 'Período inválido.' }]);
      }
      const current = await trx('evaluation_plan_sections').where({ plan_id: planId }).pluck('section_id');
      await resolvePlanSections(
        trx,
        tenantId,
        [plan.section_id, ...current.filter((id) => id !== plan.section_id)],
        { teacherId: plan.teacher_id, subject: plan.subject, subjectId: plan.subject_id },
        { termId: newTermId, excludePlanId: planId }
      );
      await trx('evaluation_plans').where({ id: planId }).update({ term_id: newTermId });
      plan.term_id = newTermId;
    }
  }

  if (format && format !== plan.format) {
    if (format === 'simple') {
      const detailed = await trx('evaluation_indicators as i')
        .join('evaluation_activities as a', 'a.id', 'i.activity_id')
        .where('a.evaluation_plan_id', planId)
        .first();
      if (detailed) {
        throw ApiError.unprocessable('El plan tiene actividades con criterios e indicadores: quítalos antes de pasar al formato simple.', [
          { path: 'format', message: 'Tiene estructura detallada.' },
        ]);
      }
    }
    await trx('evaluation_plans').where({ id: planId }).update({ format });
  }

  if (sectionIds) {
    const current = await trx('evaluation_plan_sections').where({ plan_id: planId }).pluck('section_id');
    const wanted = [...new Set(sectionIds)];
    if (!wanted.includes(plan.section_id)) {
      throw ApiError.unprocessable('La sección principal del plan no se puede quitar.', [{ path: 'sectionIds', message: 'Sección principal.' }]);
    }
    const removed = current.filter((id) => !wanted.includes(id));
    const added = wanted.filter((id) => !current.includes(id));

    for (const sectionId of removed) {
      const graded = await trx('activity_scores as sc')
        .join('evaluation_activities as a', 'a.id', 'sc.evaluation_activity_id')
        .join('enrollments as e', function joinEnrollment() {
          this.on('e.student_id', 'sc.student_id').andOn('e.section_id', trx.raw('?', [sectionId]));
        })
        .join('sections as s', 's.id', 'e.section_id')
        .where('a.evaluation_plan_id', planId)
        .select('s.name')
        .first();
      if (graded) {
        throw ApiError.conflict(`No se puede quitar la sección ${graded.name}: sus alumnos ya tienen notas en este plan.`, [
          { path: 'sectionIds', message: 'Tiene notas.' },
        ]);
      }
    }
    if (added.length) {
      await resolvePlanSections(
        trx,
        tenantId,
        [plan.section_id, ...added],
        { teacherId: plan.teacher_id, subject: plan.subject, subjectId: plan.subject_id },
        { termId: plan.term_id, excludePlanId: planId }
      );
    }
    if (removed.length) {
      await trx('activity_section_dates').whereIn('section_id', removed).whereIn('activity_id', trx('evaluation_activities').where({ evaluation_plan_id: planId }).select('id')).delete();
      await trx('evaluation_plan_sections').where({ plan_id: planId }).whereIn('section_id', removed).delete();
    }
    for (const sectionId of added) {
      await trx('evaluation_plan_sections').insert({ tenant_id: tenantId, plan_id: planId, section_id: sectionId });
    }
  }
  return getPlanWithActivities(trx, tenantId, planId);
}

// ---------- Proyectos pedagógicos y competencias ----------

/**
 * Proyecto pedagógico de aula = una actividad del plan (categoría 'project')
 * con su ponderación, más sus competencias (evaluación cualitativa). La
 * actividad pasa por upsertActivity: plan abierto, suma ≤ 100% y fecha dentro
 * del período, igual que cualquier otra. Un proyecto anterior a la integración
 * (sin actividad) se pondera con esta misma llamada.
 */
async function createPedagogicalProject(trx, tenantId, planId, { title, description, weightPercent, plannedDate, competencies = [] }) {
  const existing = await trx('pedagogical_projects')
    .where({ tenant_id: tenantId, evaluation_plan_id: planId })
    .first();
  if (existing?.evaluation_activity_id) throw ApiError.conflict('Este plan ya tiene un proyecto pedagógico.');

  const projectTitle = title || existing?.title;
  if (!projectTitle) throw ApiError.badRequest('Escribe el título del proyecto.', [{ path: 'title', message: 'Obligatorio.' }]);
  const projectDescription = description ?? existing?.description ?? null;
  const activity = await upsertActivity(trx, tenantId, planId, {
    title: projectTitle,
    category: 'project',
    weightPercent,
    description: projectDescription ? String(projectDescription).slice(0, 1000) : null,
    plannedDate: plannedDate || null,
  });

  let project;
  if (existing) {
    [project] = await trx('pedagogical_projects')
      .where({ id: existing.id })
      .update({ title: projectTitle, description: projectDescription, evaluation_activity_id: activity.id })
      .returning('*');
  } else {
    [project] = await trx('pedagogical_projects')
      .insert({ tenant_id: tenantId, evaluation_plan_id: planId, title: projectTitle, description: projectDescription, evaluation_activity_id: activity.id })
      .returning('*');
  }

  if (competencies.length > 0) {
    await trx('project_competencies').insert(
      competencies.map((description) => ({
        tenant_id: tenantId,
        pedagogical_project_id: project.id,
        description,
      }))
    );
  }

  const createdCompetencies = await trx('project_competencies').where({ pedagogical_project_id: project.id });
  return { ...project, competencies: createdCompetencies };
}

async function addCompetency(trx, tenantId, projectId, { description }) {
  const project = await trx('pedagogical_projects').where({ id: projectId, tenant_id: tenantId }).first();
  if (!project) throw ApiError.notFound('Proyecto pedagógico no encontrado.');

  const [competency] = await trx('project_competencies')
    .insert({ tenant_id: tenantId, pedagogical_project_id: projectId, description })
    .returning('*');
  return competency;
}

// ---------- Actividades de evaluación (con la validación crítica del 100%) ----------

/**
 * Crea o actualiza una actividad de evaluación, validando que la sumatoria
 * de `weight_percent` de TODAS las actividades del plan (excluyendo la que
 * se está editando) más la nueva no supere 100.
 *
 * `forUpdate()` bloquea las filas de actividades del plan hasta que la
 * transacción de este request termine (commit/rollback lo hace
 * tenant.middleware al final del request), así que si dos docentes intentan
 * agregar actividades al mismo plan al mismo tiempo, la segunda espera a que
 * la primera transacción cierre antes de leer el total — evitando que ambas
 * lean "40% usado" y las dos agreguen 70% sin verse.
 *
 * Como red de seguridad adicional existe un CONSTRAINT TRIGGER en la base de
 * datos (migrations/001_init.sql) que rechaza el INSERT/UPDATE si, por
 * cualquier vía, la suma igual queda por encima de 100.
 */
/** El plan debe existir y estar ABIERTO para modificar sus actividades. Bloquea la fila del plan. */
async function getOpenPlan(trx, tenantId, planId) {
  const plan = await trx('evaluation_plans as ep')
    .join('terms as t', 't.id', 'ep.term_id')
    .where({ 'ep.id': planId, 'ep.tenant_id': tenantId })
    .select('ep.*', 't.name as term_name', 't.start_date as term_start', 't.end_date as term_end')
    .forUpdate('ep')
    .first();
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');
  if (plan.status === 'closed') {
    throw ApiError.conflict('El plan de evaluación está cerrado. Reábrelo para modificar sus actividades.');
  }
  return plan;
}

/** "Primer Período (del 2026-09-14 al 2026-12-18)" para mensajes de fecha fuera de rango. */
function termRange(plan) {
  if (plan.term_start && plan.term_end) return plan.term_name + ' (del ' + plan.term_start + ' al ' + plan.term_end + ')';
  if (plan.term_start) return plan.term_name + ' (desde el ' + plan.term_start + ')';
  if (plan.term_end) return plan.term_name + ' (hasta el ' + plan.term_end + ')';
  return plan.term_name;
}

const round2 = (n) => Math.round(Number(n) * 100) / 100;

/**
 * Valida y normaliza la estructura detallada de una actividad:
 *  - criterios con al menos un indicador; indicadores con puntaje > 0;
 *  - la suma de puntajes de los indicadores = puntaje máximo de la actividad;
 *  - fechas de aplicación: una por sección DEL PLAN, dentro del período y de lunes a viernes.
 */
function validateDetailed(plan, planSections, { maxScore, criteria, sectionDates }) {
  if (criteria.length) {
    if (plan.format !== 'detailed') {
      throw ApiError.unprocessable('Los criterios e indicadores son del formato detallado: cambia el formato del plan primero.', [
        { path: 'criteria', message: 'Plan en formato simple.' },
      ]);
    }
    criteria.forEach((c, i) => {
      if (!c.indicators.length) {
        throw ApiError.badRequest(`El criterio ${i + 1} ("${c.title}") necesita al menos un indicador.`, [
          { path: `criteria.${i}.indicators`, message: 'Agrega un indicador.' },
        ]);
      }
    });
    const total = round2(criteria.flatMap((c) => c.indicators).reduce((n, ind) => n + Number(ind.points), 0));
    if (total !== round2(maxScore)) {
      throw ApiError.unprocessable(
        `Los puntajes de los indicadores suman ${total} y deben sumar el puntaje de la actividad (${round2(maxScore)}).`,
        [{ path: 'criteria', message: `Suman ${total} de ${round2(maxScore)}.` }]
      );
    }
  }

  const allowed = new Map(planSections.map((s) => [s.id, s.name]));
  const seen = new Set();
  sectionDates.forEach((d) => {
    if (!allowed.has(d.sectionId)) {
      throw ApiError.badRequest('Hay una fecha de aplicación para una sección que no pertenece al plan.', [
        { path: 'sectionDates', message: 'Sección ajena al plan.' },
      ]);
    }
    if (seen.has(d.sectionId)) throw ApiError.badRequest(`La sección ${allowed.get(d.sectionId)} tiene dos fechas de aplicación.`);
    seen.add(d.sectionId);
    // Sin evaluaciones en sábado ni domingo (400).
    if (weekendDay(d.date)) {
      throw ApiError.badRequest(weekendMessage(d.date, `Sección ${allowed.get(d.sectionId)}:`), [{ path: 'sectionDates', message: `Sección ${allowed.get(d.sectionId)}: fin de semana.` }]);
    }
    if ((plan.term_start && d.date < plan.term_start) || (plan.term_end && d.date > plan.term_end)) {
      throw ApiError.unprocessable(`La fecha de la sección ${allowed.get(d.sectionId)} debe estar dentro de ${termRange(plan)}.`, [
        { path: 'sectionDates', message: 'Fuera del período.' },
      ]);
    }
  });
}

/**
 * Guarda criterios e indicadores de una actividad comparando por id: se
 * actualizan los existentes, se crean los nuevos y se borran los que faltan.
 * Con notas registradas solo se permite cambiar textos: agregar, quitar o
 * cambiar el puntaje de un indicador cambiaría el significado de esas notas.
 */
async function saveCriteria(trx, tenantId, activityId, criteria, hasScores) {
  const oldCriteria = await trx('evaluation_criteria').where({ activity_id: activityId });
  const oldIndicators = await trx('evaluation_indicators').where({ activity_id: activityId });
  const incomingIndicators = criteria.flatMap((c) => c.indicators);

  if (hasScores) {
    const keptIds = new Set(incomingIndicators.filter((i) => i.id).map((i) => i.id));
    const changed =
      incomingIndicators.some((i) => !i.id) ||
      oldIndicators.some((o) => !keptIds.has(o.id)) ||
      incomingIndicators.some((i) => {
        const old = oldIndicators.find((o) => o.id === i.id);
        return old && round2(old.points) !== round2(i.points);
      });
    if (changed) {
      throw ApiError.conflict(
        'La actividad ya tiene notas: no se pueden agregar ni quitar indicadores, ni cambiar sus puntajes (sí corregir sus textos).',
        [{ path: 'criteria', message: 'Actividad con notas.' }]
      );
    }
  }

  // Ids enviados deben pertenecer a ESTA actividad (no a otra del colegio).
  const bad =
    criteria.some((c) => c.id && !oldCriteria.some((o) => o.id === c.id)) ||
    incomingIndicators.some((i) => i.id && !oldIndicators.some((o) => o.id === i.id));
  if (bad) throw ApiError.badRequest('Hay criterios o indicadores que no pertenecen a esta actividad.');

  // 1. Indicadores que ya no vienen (sin notas: lo garantiza la validación de arriba).
  const keepIndicatorIds = incomingIndicators.filter((i) => i.id).map((i) => i.id);
  await trx('evaluation_indicators').where({ activity_id: activityId }).whereNotIn('id', keepIndicatorIds).delete();

  // 2. Guardar criterios y mover cada indicador a su criterio (puede cambiar de grupo).
  // Los criterios viejos se borran AL FINAL, ya vacíos: borrarlos antes arrastraría en
  // cascada indicadores que se conservan (y que pueden tener notas).
  const usedCriteriaIds = [];
  for (const [ci, c] of criteria.entries()) {
    let criterionId = c.id;
    if (criterionId) {
      await trx('evaluation_criteria').where({ id: criterionId }).update({ title: c.title, position: ci + 1 });
    } else {
      [{ id: criterionId }] = await trx('evaluation_criteria')
        .insert({ tenant_id: tenantId, activity_id: activityId, position: ci + 1, title: c.title })
        .returning('id');
    }
    usedCriteriaIds.push(criterionId);
    for (const [ii, ind] of c.indicators.entries()) {
      const data = { criterion_id: criterionId, position: ii + 1, description: ind.description, points: ind.points };
      if (ind.id) await trx('evaluation_indicators').where({ id: ind.id }).update(data);
      else await trx('evaluation_indicators').insert({ ...data, tenant_id: tenantId, activity_id: activityId });
    }
  }

  // 3. Criterios que ya no se usan (ya sin indicadores).
  await trx('evaluation_criteria').where({ activity_id: activityId }).whereNotIn('id', usedCriteriaIds).delete();
}

/**
 * Crea o edita una actividad del plan. Campos comunes: título, tipo,
 * porcentaje, descripción, fecha estimada. Formato detallado además:
 * estrategia, referencias teórico-prácticas, puntaje máximo, criterios con
 * indicadores (puntos) y fecha de aplicación por sección. La suma de
 * porcentajes del plan nunca supera 100% (y para cerrarlo debe ser 100%).
 */
/**
 * Cambia el tema del contenido programático que evalúa una actividad (y con él
 * su unidad), sin tocar lo demás. `contentId` null la desvincula. Mismas reglas
 * que al editarla: plan abierto y contenido de la misma materia y grado.
 */
async function setActivityContent(trx, tenantId, planId, activityId, contentId) {
  const plan = await getOpenPlan(trx, tenantId, planId);
  const activity = await trx('evaluation_activities').where({ id: activityId, tenant_id: tenantId, evaluation_plan_id: planId }).first();
  if (!activity) throw ApiError.notFound('Actividad no encontrada.');
  const content = contentId ? await assertContentForPlan(trx, tenantId, contentId, plan) : null;
  await trx('evaluation_activities').where({ id: activityId }).update({ programmatic_content_id: contentId });
  return {
    id: activityId,
    programmatic_content: content ? { id: content.id, unit: content.unit, topic: content.topic } : null,
  };
}

async function upsertActivity(
  trx,
  tenantId,
  planId,
  {
    activityId,
    title,
    category,
    weightPercent,
    description,
    plannedDate,
    strategy,
    contentRefs,
    maxScore,
    criteria,
    sectionDates,
    programmaticContentId,
    instrument,
    planFormat,
  }
) {
  if (weightPercent <= 0 || weightPercent > 100) {
    throw ApiError.badRequest('El porcentaje debe estar entre 0 (exclusivo) y 100.');
  }

  const plan = await getOpenPlan(trx, tenantId, planId);
  const planSections = await listPlanSections(trx, planId);
  if (programmaticContentId) await assertContentForPlan(trx, tenantId, programmaticContentId, plan);

  // Actividad en formato detallado: exige criterios y, si el plan es simple, lo
  // pasa a detallado (pasar a detallado no tiene restricciones; las demás
  // actividades del plan se conservan tal cual).
  if (planFormat === 'detailed') {
    if (!criteria?.length) {
      throw ApiError.badRequest('El formato detallado requiere al menos un criterio con sus indicadores.', [
        { path: 'criteria', message: 'Agrega un criterio.' },
      ]);
    }
    if (plan.format !== 'detailed') {
      await trx('evaluation_plans').where({ id: planId }).update({ format: 'detailed' });
      plan.format = 'detailed';
    }
  }

  // Sin evaluaciones en sábado ni domingo (400). Vale para el formulario, el
  // proyecto pedagógico, "Incluir evaluación" y la carga desde Excel: todos pasan por aquí.
  if (weekendDay(plannedDate)) {
    throw ApiError.badRequest(weekendMessage(plannedDate), [{ path: 'plannedDate', message: `Es ${weekendDay(plannedDate)}: elige un día de lunes a viernes.` }]);
  }

  // La fecha estimada debe caer dentro del período (si el período tiene fechas).
  if (plannedDate && ((plan.term_start && plannedDate < plan.term_start) || (plan.term_end && plannedDate > plan.term_end))) {
    throw ApiError.unprocessable('La fecha estimada debe estar dentro de ' + termRange(plan) + '.', [
      { path: 'plannedDate', message: 'Fuera del período.' },
    ]);
  }

  const activities = await trx('evaluation_activities')
    .where({ tenant_id: tenantId, evaluation_plan_id: planId })
    .forUpdate();

  const existing = activityId ? activities.find((a) => a.id === activityId) : null;
  if (activityId && !existing) throw ApiError.notFound('Actividad no encontrada en este plan.');
  // La actividad del proyecto pedagógico siempre es de tipo "Proyecto".
  const linkedProject = existing ? await trx('pedagogical_projects').where({ evaluation_activity_id: activityId }).first('id') : null;
  if (linkedProject) category = 'project';
  const hasScores = existing ? Boolean(await trx('activity_scores').where({ evaluation_activity_id: activityId }).first()) : false;

  // Sin estructura enviada, se conserva la actual (editar solo título/porcentaje no borra indicadores).
  const effectiveMax = maxScore ?? (existing ? Number(existing.max_score) : 20);
  if (existing && hasScores && round2(effectiveMax) !== round2(existing.max_score)) {
    throw ApiError.conflict('La actividad ya tiene notas: no se puede cambiar su puntaje máximo.', [
      { path: 'maxScore', message: 'Actividad con notas.' },
    ]);
  }
  if (criteria !== undefined || sectionDates !== undefined || maxScore !== undefined) {
    validateDetailed(plan, planSections, {
      maxScore: effectiveMax,
      criteria: criteria ?? (existing ? (await loadActivityStructure(trx, [activityId])).get(activityId).criteria : []),
      sectionDates: sectionDates ?? [],
    });
  }

  const currentTotal = activities
    .filter((a) => a.id !== activityId)
    .reduce((sum, a) => sum + Number(a.weight_percent), 0);

  const newTotal = Math.round((currentTotal + Number(weightPercent)) * 100) / 100;

  if (newTotal > 100) {
    throw ApiError.unprocessable(
      `La suma de porcentajes excede 100%. Actual: ${currentTotal}%, intentando ${activityId ? 'actualizar a' : 'agregar'} ${weightPercent}% (total ${newTotal}%).`,
      { currentTotal, attempted: weightPercent, newTotal }
    );
  }

  const fields = {
    title,
    category,
    weight_percent: weightPercent,
    description: description ?? null,
    planned_date: plannedDate ?? null,
    ...(strategy !== undefined ? { strategy: strategy || null } : {}),
    ...(contentRefs !== undefined ? { content_refs: JSON.stringify(contentRefs) } : {}),
    ...(programmaticContentId !== undefined ? { programmatic_content_id: programmaticContentId } : {}),
    ...(instrument !== undefined ? { instrument } : {}),
    max_score: effectiveMax,
  };

  let saved;
  if (existing) {
    [saved] = await trx('evaluation_activities').where({ id: activityId, tenant_id: tenantId }).update(fields).returning('*');
    // `activity_scores.weighted_score` guarda (nota / máximo) × porcentaje: si cambia
    // el porcentaje hay que recalcularlo, o el acumulado de los alumnos queda desfasado.
    await trx('activity_scores')
      .where({ tenant_id: tenantId, evaluation_activity_id: activityId })
      .update({ weighted_score: trx.raw('(raw_score / max_score) * ?', [weightPercent]) });
  } else {
    [saved] = await trx('evaluation_activities')
      .insert({ tenant_id: tenantId, evaluation_plan_id: planId, ...fields })
      .returning('*');
  }

  // El proyecto toma el título y la descripción de su actividad.
  if (linkedProject) {
    await trx('pedagogical_projects').where({ id: linkedProject.id }).update({ title, description: description ?? null });
  }

  if (criteria !== undefined) await saveCriteria(trx, tenantId, saved.id, criteria, hasScores);
  if (sectionDates !== undefined) {
    await trx('activity_section_dates').where({ activity_id: saved.id }).delete();
    for (const d of sectionDates) {
      await trx('activity_section_dates').insert({ tenant_id: tenantId, activity_id: saved.id, section_id: d.sectionId, applied_on: d.date });
    }
  }

  const structure = await loadActivityStructure(trx, [saved.id]);
  return { ...saved, max_score: Number(saved.max_score), ...structure.get(saved.id) };
}

/**
 * Elimina un plan con todo lo que cuelga de él (en cascada: actividades,
 * criterios e indicadores, fechas por sección, proyecto pedagógico, secciones
 * del plan y comentarios de revisión). Se rechaza (409) si borrarlo haría
 * perder algo que no se puede recuperar:
 *   - notas o evaluaciones de competencias de algún alumno;
 *   - constancias de lectura de los representantes (069), que son el respaldo
 *     legal de la Dirección.
 * Devuelve un resumen para el mensaje de confirmación.
 */
async function deletePlan(trx, tenantId, planId) {
  const plan = await trx('evaluation_plans as ep')
    .join('sections as sec', 'sec.id', 'ep.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('terms as t', 't.id', 'ep.term_id')
    .leftJoin('subjects as sub', 'sub.id', 'ep.subject_id')
    .where({ 'ep.id': planId, 'ep.tenant_id': tenantId })
    .first('ep.id', trx.raw('COALESCE(sub.name, ep.subject) AS subject'), 'g.name as grade_name', 't.name as term_name');
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');

  if (await planHasGrades(trx, planId)) {
    throw ApiError.conflict(
      `El plan de ${plan.subject} (${plan.grade_name}, ${plan.term_name}) ya tiene notas de alumnos: eliminarlo borraría esas calificaciones. Si se creó por error, quita primero las notas desde Calificaciones.`
    );
  }
  const acks = await trx('evaluation_plan_acknowledgments').where({ tenant_id: tenantId, plan_id: planId }).count('* as n').first();
  if (Number(acks.n) > 0) {
    throw ApiError.conflict(
      `El plan tiene ${acks.n} ${Number(acks.n) === 1 ? 'constancia' : 'constancias'} de lectura de representantes: es el respaldo legal de la Dirección y no se puede borrar. Si necesitas cambiarlo, edítalo (las familias volverán a confirmar la nueva versión).`
    );
  }

  const { n: activities } = await trx('evaluation_activities').where({ evaluation_plan_id: planId }).count('* as n').first();
  await trx('evaluation_plans').where({ id: planId, tenant_id: tenantId }).delete();
  return { ...plan, deleted_activities: Number(activities) };
}

async function deleteActivity(trx, tenantId, planId, activityId) {
  await getOpenPlan(trx, tenantId, planId);
  // Debe pertenecer al plan de la URL (antes se podía borrar la actividad de otro plan).
  const activity = await trx('evaluation_activities')
    .where({ id: activityId, tenant_id: tenantId, evaluation_plan_id: planId })
    .first();
  if (!activity) throw ApiError.notFound('Actividad no encontrada en este plan.');

  const hasScores = await trx('activity_scores').where({ evaluation_activity_id: activityId }).first();
  if (hasScores) {
    throw ApiError.conflict('No se puede eliminar: ya hay calificaciones registradas para esta actividad.');
  }
  // Actividad de un proyecto pedagógico: se borra con él (y sus competencias), salvo que ya estén evaluadas.
  const assessed = await trx('competency_assessments as ca')
    .join('project_competencies as pc', 'pc.id', 'ca.project_competency_id')
    .join('pedagogical_projects as pp', 'pp.id', 'pc.pedagogical_project_id')
    .where('pp.evaluation_activity_id', activityId)
    .first('ca.id');
  if (assessed) {
    throw ApiError.conflict('No se puede eliminar: el proyecto pedagógico ya tiene competencias evaluadas.');
  }

  await trx('evaluation_activities').where({ id: activityId }).delete();
}

/**
 * Cierra el plan: solo si sus actividades suman EXACTAMENTE 100%. Cerrado, las
 * actividades quedan bloqueadas (las notas se siguen cargando con normalidad).
 */
async function closePlan(trx, tenantId, planId) {
  await getOpenPlan(trx, tenantId, planId);
  const { rows } = await trx.raw(
    'SELECT COALESCE(sum(weight_percent), 0)::numeric(6,2) AS total, count(*)::int AS n FROM evaluation_activities WHERE evaluation_plan_id = ?',
    [planId]
  );
  const total = Number(rows[0].total);
  if (rows[0].n === 0) throw ApiError.unprocessable('No se puede cerrar un plan sin actividades.');
  if (total !== 100) {
    const missing = Math.round((100 - total) * 100) / 100;
    throw ApiError.unprocessable(
      'No se puede cerrar: las actividades suman ' + total + '%. Faltan ' + missing + '% para llegar a 100%.',
      { total }
    );
  }
  await trx('evaluation_plans').where({ id: planId }).update({ status: 'closed', closed_at: trx.fn.now() });
  return getPlanWithActivities(trx, tenantId, planId);
}

async function reopenPlan(trx, tenantId, planId) {
  const plan = await trx('evaluation_plans').where({ id: planId, tenant_id: tenantId }).first();
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');
  if (plan.status !== 'closed') throw ApiError.conflict('El plan ya está abierto.');
  await trx('evaluation_plans').where({ id: planId }).update({ status: 'open', closed_at: null });
  return getPlanWithActivities(trx, tenantId, planId);
}

module.exports = {
  deletePlan,
  ensureTerm,
  updatePlan,
  listPlanSections,
  loadActivityStructure,
  setActivityContent,
  closePlan,
  reopenPlan,
  listTerms,
  listPlans,
  getPlanWithActivities,
  createPlan,
  createPedagogicalProject,
  addCompetency,
  upsertActivity,
  deleteActivity,
};

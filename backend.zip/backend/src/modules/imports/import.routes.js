const router = require('express').Router();
const controller = require('./import.controller');
const { getImporter } = require('./import.service');
const { authMiddleware } = require('../../middlewares/auth.middleware');
const { tenantMiddleware } = require('../../middlewares/tenant.middleware');
const { requirePermission } = require('../../middlewares/permission.middleware');
const scope = require('../access/teacherScope');
const reviews = require('../reviews/review.service');

/** Calificaciones: el plan (planId en la URL o en el formulario) debe ser de la carga del docente. */
async function requireOwnPlan(req, res, next) {
  try {
    // Calificaciones y carga masiva del plan: el plan debe ser de la carga del docente.
    if (req.params.type === 'scores' || req.params.type === 'plan_activities') {
      const planId = req.query.planId || req.body?.planId;
      if (planId) await scope.assertPlanAccess(req, planId);
    }
    // Contenido programático: solo materias de su carga y que no estén bloqueadas por la revisión.
    if (req.params.type === 'programmatic_content') {
      const gradeId = req.query.gradeId || req.body?.gradeId;
      const subjectId = req.query.subjectId || req.body?.subjectId;
      const schoolPeriodId = req.query.schoolPeriodId || req.body?.schoolPeriodId;
      if (gradeId && subjectId) {
        await scope.assertGradeSubjectAccess(req, gradeId, subjectId);
        if (req.method !== 'GET' && schoolPeriodId) await reviews.assertContentEditable(req, gradeId, subjectId, schoolPeriodId);
      }
    }
    next();
  } catch (err) {
    next(err);
  }
}
const { importUpload } = require('../../middlewares/upload.middleware');
const { getCoordinatorScope } = require('../access/coordinatorScope');
const { ApiError } = require('../../utils/ApiError');

/**
 * Personal: el Coordinador (migración 047) solo registra docentes de su etapa, y la
 * carga masiva no aplica ese alcance; registra uno a uno desde Personal.
 */
async function blockCoordinatorStaffImport(req, res, next) {
  try {
    if (req.params.type === 'staff' && (await getCoordinatorScope(req))) {
      throw ApiError.forbidden('Como coordinador registras a los docentes de tu etapa desde «Nuevo personal»; la importación masiva de personal es del Director.');
    }
    next();
  } catch (err) {
    next(err);
  }
}

router.use(authMiddleware, tenantMiddleware);

/**
 * El permiso depende del tipo: alumnos → students.create, personal →
 * staff.create, materias → academics.create, calificaciones → grading.update.
 * Se exige también para descargar la plantilla (la de calificaciones trae
 * nombres y notas de la sección).
 */
function requireImportPermission(req, res, next) {
  let importer;
  try {
    importer = getImporter(req.params.type);
  } catch (err) {
    return next(err);
  }
  return requirePermission(...importer.permission)(req, res, next);
}

router.get('/:type/template', requireImportPermission, blockCoordinatorStaffImport, requireOwnPlan, controller.downloadTemplate);
// El permiso se revisa ANTES de recibir el archivo.
router.post('/:type/validate', requireImportPermission, blockCoordinatorStaffImport, importUpload, requireOwnPlan, controller.validate);
router.post('/:type', requireImportPermission, blockCoordinatorStaffImport, importUpload, requireOwnPlan, controller.importFile);

module.exports = router;

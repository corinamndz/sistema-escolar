const { ApiError } = require('../../utils/ApiError');
const { exclusionOf } = require('../academics/sectionSubjects');
const { scaleDefinition } = require('../grading/gradingScale');
const { loadActivityStructure } = require('../evaluation-plans/evaluationPlan.service');
const { sortByProgram, compareUnits } = require('../programmatic-content/programmaticContent.service');
const { isContentReviewRequired: familiesSeeOnlyApproved } = require('../reviews/reviewSettings.service');
const { currentPeriodOrder } = require('../../utils/schoolPeriods');
const adjustments = require('../grading/gradeAdjustments.service');
const { studentRanks } = require('../grading/gradeSummary.service');
const { loadRules, roundGrade, annualAverage, yearAverage } = require('../grading/gradeAverages');

/**
 * Calificaciones acumuladas de un alumno para el portal del representante.
 *
 * Modelo (ya existente): evaluation_plans (sección + período + materia + docente)
 *   → evaluation_activities (título, % de la nota)
 *     → activity_scores (nota obtenida `raw_score` sobre `max_score`)
 *
 * Por cada plan (una materia en un período) se calcula:
 *   earned_percent   Σ (nota / máximo) × % actividad   → puntos ganados de 100
 *   evaluated_weight Σ % de las actividades ya calificadas
 *   accumulated      earned_percent / 100 × ESCALA      → "llevas X de 20"
 *   current_average  earned_percent / evaluated_weight × ESCALA → rendimiento en lo evaluado
 *   final_grade      = accumulated, solo cuando ya se evaluó el 100% del plan
 *
 * La ponderación se calcula aquí a partir de la nota y del % ACTUAL de la
 * actividad (no del `weighted_score` guardado), así el resultado es correcto
 * aunque el porcentaje se haya editado después de cargar notas.
 */

const GRADE_SCALE = 20; // escala de calificación del colegio (coincide con activity_scores.max_score por defecto)
const PASSING_GRADE = 10; // nota mínima aprobatoria sobre GRADE_SCALE

const round2 = (n) => Math.round(n * 100) / 100;

/** El alumno debe estar vinculado al representante del usuario; si no, 404 (no se revela su existencia). */
async function assertGuardianOfStudent(trx, tenantId, userId, studentId) {
  const link = await trx('student_guardians as sg')
    .join('guardians as g', 'g.id', 'sg.guardian_id')
    .join('students as s', 's.id', 'sg.student_id')
    .where({ 'g.tenant_id': tenantId, 'g.user_id': userId, 'sg.student_id': studentId })
    .select('s.id', 's.first_name', 's.last_name', 's.national_id', 's.status', 'sg.relationship')
    .first();
  if (!link) throw ApiError.notFound('Alumno no encontrado.');
  return link;
}

/** Mensaje para la familia cuando las calificaciones están bloqueadas por deuda. */
const GRADES_LOCKED_MESSAGE =
  'Acceso a detalles del alumno bloqueado por pagos pendientes. Por favor, comuníquese con administración o reporte su pago.';

/**
 * Cuotas VENCIDAS del alumno: pendientes, con la fecha de vencimiento pasada
 * y que la familia no haya reportado como pagadas (un pago reportado queda en
 * revisión y no bloquea). Misma regla que el estado "vencido" de los pagos.
 */
async function overdueCount(trx, tenantId, studentId) {
  const row = await trx('payments')
    .where({ tenant_id: tenantId, student_id: studentId, status: 'pending' })
    .whereNull('reported_at')
    .whereNotNull('due_date')
    .andWhere('due_date', '<', trx.raw('current_date'))
    .andWhere((q) => q.whereNull('issue_date').orWhere('issue_date', '<=', trx.raw('current_date')))
    .count('id as n')
    .first();
  return Number(row.n);
}

/**
 * Portal del representante: con cuotas vencidas, las calificaciones del
 * alumno (y su historial académico, que también muestra notas) quedan
 * bloqueadas → 403 con un mensaje para la familia.
 */
async function assertGradesUnlocked(trx, tenantId, studentId) {
  const overdue = await overdueCount(trx, tenantId, studentId);
  if (overdue > 0) {
    throw ApiError.forbidden(GRADES_LOCKED_MESSAGE, [{ path: 'payments', message: `GRADES_LOCKED: ${overdue} cuota(s) vencida(s)` }]);
  }
}

function summarizePlan(activities) {
  const graded = activities.filter((a) => a.raw_score !== null);
  const totalWeight = activities.reduce((n, a) => n + a.weight_percent, 0);
  const evaluatedWeight = graded.reduce((n, a) => n + a.weight_percent, 0);
  const earnedPercent = graded.reduce((n, a) => n + a.earned_percent, 0);
  const complete = activities.length > 0 && round2(totalWeight) === 100 && round2(evaluatedWeight) === 100;

  let status = 'in_progress';
  if (activities.length === 0) status = 'no_activities';
  else if (graded.length === 0) status = 'no_grades';
  else if (complete) status = 'final';

  const accumulated = round2((earnedPercent / 100) * GRADE_SCALE);
  return {
    status,
    total_weight: round2(totalWeight),
    evaluated_weight: round2(evaluatedWeight),
    earned_percent: round2(earnedPercent),
    accumulated,
    current_average: evaluatedWeight > 0 ? round2((earnedPercent / evaluatedWeight) * GRADE_SCALE) : null,
    final_grade: complete ? accumulated : null,
    graded_count: graded.length,
    activity_count: activities.length,
  };
}

async function getStudentGrades(trx, tenantId, userId, studentId, { schoolPeriodId } = {}) {
  const student = await assertGuardianOfStudent(trx, tenantId, userId, studentId);

  // Años escolares en los que el alumno tuvo inscripción (activa o no), el en curso primero.
  const periods = await trx('enrollments as e')
    .join('sections as sec', 'sec.id', 'e.section_id')
    .join('school_periods as sp', 'sp.id', 'sec.school_period_id')
    .where({ 'e.tenant_id': tenantId, 'e.student_id': studentId })
    // Un año por fila. GROUP BY la clave del año (y no DISTINCT): así el ORDER BY
    // puede usar sus otras columnas (closed_at, end_date…); con DISTINCT, PostgreSQL
    // exige que estén en la lista de resultados y la consulta fallaba (500).
    .select('sp.id', 'sp.name', 'sp.start_date', 'sp.is_active', 'sp.passing_grade')
    .groupBy('sp.id')
    .orderByRaw(currentPeriodOrder('sp')); // el en curso primero: es el que se abre por defecto

  const base = { student, scale: GRADE_SCALE, passing_grade: PASSING_GRADE, periods, school_period: null, terms: [], subjects: [] };
  if (periods.length === 0) return base;

  const period = schoolPeriodId ? periods.find((p) => p.id === schoolPeriodId) : periods[0];
  if (!period) throw ApiError.notFound('El alumno no tiene inscripciones en ese año escolar.');

  const sections = await trx('enrollments as e')
    .join('sections as sec', 'sec.id', 'e.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .where({ 'e.tenant_id': tenantId, 'e.student_id': studentId, 'sec.school_period_id': period.id })
    .select('sec.id', 'sec.name', 'g.name as grade_name', 'g.level_code', 'g.grading_scale', 'e.status as enrollment_status');

  // Planes de las secciones del alumno, incluidos los compartidos entre varias
  // secciones (migración 012). Si un alumno pasó por dos secciones del mismo
  // plan, el plan aparece una sola vez (con su sección vigente).
  // Revisión académica activa (059): solo los planes aprobados por coordinación.
  const onlyApproved = await familiesSeeOnlyApproved(trx, tenantId);
  const planRows = sections.length
    ? await trx('evaluation_plans as ep')
        .join('evaluation_plan_sections as eps', 'eps.plan_id', 'ep.id')
        .join('terms as t', 't.id', 'ep.term_id')
        // LEFT: un plan cuyo docente se eliminó del personal debe seguir viéndose.
        .leftJoin('staff as st', 'st.id', 'ep.teacher_id')
        .leftJoin('subjects as sub', 'sub.id', 'ep.subject_id')
        .where('ep.tenant_id', tenantId)
        .whereIn('eps.section_id', sections.map((s) => s.id))
        .modify((q) => onlyApproved && q.andWhere('ep.review_status', 'aprobado'))
        .select(
          'ep.id',
          'eps.section_id',
          'ep.subject',
          'ep.subject_id',
          'sub.code as subject_code',
          't.id as term_id',
          't.name as term_name',
          't.start_date as term_start',
          trx.raw("NULLIF(concat_ws(' ', st.first_name, st.last_name), '') AS teacher_name")
        )
        .orderByRaw('t.term_number NULLS LAST, t.start_date NULLS LAST, t.name, ep.subject')
    : [];
  const isActiveSection = (id) => sections.some((sec) => sec.id === id && sec.enrollment_status === 'active');
  const plans = [];
  planRows.forEach((row) => {
    const i = plans.findIndex((p) => p.id === row.id);
    if (i < 0) plans.push(row);
    else if (!isActiveSection(plans[i].section_id) && isActiveSection(row.section_id)) plans[i] = row;
  });
  const planIds = plans.map((p) => p.id);

  // En el orden del contenido programático (unidad → tema), igual que el plan del docente.
  const activities = planIds.length
    ? await sortByProgram(
        trx,
        await trx('evaluation_activities as a')
          .leftJoin('activity_scores as sc', function joinScore() {
            this.on('sc.evaluation_activity_id', 'a.id').andOn('sc.student_id', trx.raw('?', [studentId]));
          })
          .whereIn('a.evaluation_plan_id', planIds)
          .select(
            'a.id',
            'a.evaluation_plan_id',
            'a.title',
            'a.category',
            'a.weight_percent',
            'a.programmatic_content_id',
            'a.planned_date',
            'a.created_at',
            'sc.raw_score',
            'sc.max_score',
            'sc.graded_at'
          )
      )
    : [];

  // Proyecto pedagógico y competencias (evaluación cualitativa), si el plan lo tiene.
  const competencies = planIds.length
    ? await trx('pedagogical_projects as pp')
        .join('project_competencies as pc', 'pc.pedagogical_project_id', 'pp.id')
        .leftJoin('competency_assessments as ca', function joinAssessment() {
          this.on('ca.project_competency_id', 'pc.id').andOn('ca.student_id', trx.raw('?', [studentId]));
        })
        .whereIn('pp.evaluation_plan_id', planIds)
        .select('pp.evaluation_plan_id', 'pp.title as project_title', 'pc.id', 'pc.description', 'ca.result')
    : [];

  const planViews = plans.map((plan) => {
    const acts = activities
      .filter((a) => a.evaluation_plan_id === plan.id)
      .map((a) => {
        const weight = Number(a.weight_percent);
        const graded = a.raw_score !== null;
        const raw = graded ? Number(a.raw_score) : null;
        const max = graded ? Number(a.max_score) : null;
        return {
          id: a.id,
          title: a.title,
          category: a.category,
          weight_percent: weight,
          raw_score: raw,
          max_score: max,
          // Nota llevada a la escala del colegio (ej. 85/100 → 17/20) para comparar actividades.
          scaled_score: graded ? round2((raw / max) * GRADE_SCALE) : null,
          earned_percent: graded ? (raw / max) * weight : 0,
          graded_at: a.graded_at,
        };
      });
    const planCompetencies = competencies.filter((c) => c.evaluation_plan_id === plan.id);
    const section = sections.find((s) => s.id === plan.section_id);
    return {
      plan_id: plan.id,
      term_id: plan.term_id,
      term_name: plan.term_name,
      teacher_name: plan.teacher_name,
      section: `${section.grade_name} ${section.name}`,
      section_withdrawn: section.enrollment_status !== 'active',
      // Escala del grado de ESE plan (migración 023): cómo mostrar sus notas.
      grading_scale: section.grading_scale || 'quantitative',
      ...summarizePlan(acts),
      activities: acts.map(({ earned_percent: earned, ...a }) => ({ ...a, earned_percent: round2(earned) })),
      project: planCompetencies.length
        ? {
            title: planCompetencies[0].project_title,
            competencies: planCompetencies.map((c) => ({ id: c.id, description: c.description, result: c.result })),
          }
        : null,
      _subjectKey: plan.subject_id || plan.subject.trim().toLowerCase(),
      _subject: plan.subject,
      _subjectCode: plan.subject_code,
    };
  });

  // Agrupar por materia: por subject_id si el plan es de una materia del plan de estudios
  // (Primaria y Secundaria); si no, por el nombre del área (Inicial).
  const subjects = [];
  planViews.forEach(({ _subjectKey: key, _subject: name, _subjectCode: code, ...plan }) => {
    let subject = subjects.find((s) => s.key === key);
    if (!subject) {
      subject = { key, name, code, plans: [] };
      subjects.push(subject);
    }
    subject.plans.push(plan);
  });

  // TODAS las materias del plan de estudios del grado del alumno se listan,
  // aunque aún no tengan plan de evaluación en su sección (`pending: true`):
  // así el representante ve la materia (y la escuela detecta el plan que falta)
  // en vez de que desaparezca.
  const current = sections.find((s) => s.enrollment_status === 'active') || sections[0];
  if (current) {
    const curriculum = await trx('grade_subjects as gs')
      .join('sections as sec', 'sec.grade_id', 'gs.grade_id')
      .join('subjects as sub', 'sub.id', 'gs.subject_id')
      .where('sec.id', current.id)
      .whereNotExists(exclusionOf(trx, trx.ref('sec.id'), trx.ref('gs.subject_id')))
      .select('sub.id', 'sub.name', 'sub.code')
      .orderBy([{ column: 'gs.sort_order' }, { column: 'sub.name' }]);
    curriculum.forEach((c) => {
      if (!subjects.some((s) => s.key === c.id)) subjects.push({ key: c.id, name: c.name, code: c.code, plans: [], pending: true });
    });
  }
  subjects.sort((a, b) => a.name.localeCompare(b.name, 'es'));

  // Ajuste directivo de la definitiva (migración 084): la familia ve la nota vigente y que fue
  // ajustada por la dirección (con la fecha; el motivo queda en el historial interno).
  const effective = await adjustments.loadEffective(trx, tenantId, { studentIds: [studentId], periodIds: [period.id] });
  if (effective.size) {
    const isId = (k) => /^[0-9a-f-]{36}$/i.test(k);
    subjects.forEach((sub) =>
      sub.plans.forEach((plan) => {
        const adj = adjustments.findFor(effective, studentId, plan.term_id, { subjectId: isId(sub.key) ? sub.key : null, name: sub.name });
        if (!adj) return;
        plan.computed_final_grade = plan.final_grade;
        plan.final_grade = adj.grade;
        plan.status = 'final';
        plan.adjusted = { grade: adj.grade, at: adj.at };
      })
    );
  }

  const terms = [...new Map(plans.map((p) => [p.term_id, { id: p.term_id, name: p.term_name }])).values()];

  // Promedio anual con la normativa del año, sobre los períodos definidos y los planes que la familia puede ver.
  const rules = (await loadRules(trx, tenantId, [period.id])).get(period.id);
  const planGrade = (plan) => {
    if (!plan) return null;
    if (plan.adjusted) return plan.final_grade;
    const value = plan.final_grade ?? (plan.graded_count ? plan.accumulated : null);
    return value === null ? null : roundGrade(value, rules.grade_rounding);
  };
  subjects.forEach((sub) => {
    sub.annual = annualAverage(rules.terms.map((t) => ({ term_id: t.id, grade: planGrade(sub.plans.find((p) => p.term_id === t.id && p.graded_count > 0) || sub.plans.find((p) => p.term_id === t.id)) })), rules);
  });
  const annualOf = subjects.map((s) => ({ final: s.annual.final, pending: s.annual.pending }));
  const year_average = {
    value: yearAverage(annualOf, rules),
    provisional: subjects.some((s) => s.annual.provisional),
    pending: subjects.some((s) => s.annual.pending),
  };

  // Nota mínima: la de la normativa del año escolar consultado (migración 014).
  const passingGrade = period.passing_grade === undefined || period.passing_grade === null ? PASSING_GRADE : Number(period.passing_grade);
  // Escala de la sección vigente del alumno (la de sus planes actuales) y las equivalencias de los literales.
  const gradingScale = current?.grading_scale || 'quantitative';
  // Puesto en la sección. Con revisión académica activa, la familia no ve los planes sin aprobar:
  // no se muestra un puesto calculado con notas que aún no puede ver.
  const ranks = await studentRanks(trx, tenantId, studentId, period.id);
  if (ranks && onlyApproved && current) {
    const pending = await trx('evaluation_plans as ep')
      .join('evaluation_plan_sections as eps', 'eps.plan_id', 'ep.id')
      .where({ 'ep.tenant_id': tenantId, 'eps.section_id': current.id })
      .whereNot('ep.review_status', 'aprobado')
      .distinct('ep.term_id')
      .pluck('ep.term_id');
    pending.forEach((id) => {
      ranks.terms[id] = null;
    });
    if (pending.length) ranks.annual = null;
  }
  return { ...base, passing_grade: passingGrade, school_period: { id: period.id, name: period.name }, sections, terms, subjects, year_average, grading_scale: gradingScale, scale_def: scaleDefinition(), section_ranks: ranks };
}

/**
 * Plan de evaluación completo (solo lectura) de una materia para el portal:
 * referencias, estrategia, criterios e indicadores con puntaje, ponderación y
 * la fecha de aplicación en la sección del alumno. Solo planes de una sección
 * en la que el alumno está o estuvo inscrito (404 si no); no expone otras
 * secciones ni datos de otros alumnos.
 */
async function getStudentPlanDetail(trx, tenantId, studentId, planId) {
  const section = await trx('evaluation_plan_sections as eps')
    .join('enrollments as e', 'e.section_id', 'eps.section_id')
    .join('sections as sec', 'sec.id', 'eps.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .where({ 'eps.plan_id': planId, 'e.student_id': studentId, 'e.tenant_id': tenantId })
    .select('sec.id', 'sec.name', 'g.name as grade_name', 'g.grading_scale')
    .orderByRaw("(e.status = 'active') DESC")
    .first();
  if (!section) throw ApiError.notFound('Plan de evaluación no encontrado.');
  return buildPlanDetail(trx, tenantId, planId, section);
}

/**
 * El plan tal como lo ve la familia de un alumno de `section` ({ id, name,
 * grade_name, grading_scale }): fechas de esa sección y temas del contenido
 * programático. También lo usa el reporte de confirmaciones de lectura para
 * saber qué versión es la vigente en cada sección. 404 si no está publicado.
 */
async function buildPlanDetail(trx, tenantId, planId, section) {
  const plan = await trx('evaluation_plans as ep')
    .join('terms as t', 't.id', 'ep.term_id')
    .leftJoin('subjects as sub', 'sub.id', 'ep.subject_id')
    .leftJoin('staff as st', 'st.id', 'ep.teacher_id')
    .where({ 'ep.id': planId, 'ep.tenant_id': tenantId })
    .select(
      'ep.id',
      'ep.review_status',
      'ep.format',
      trx.raw('COALESCE(sub.name, ep.subject) AS subject'),
      'sub.code as subject_code',
      't.name as term_name',
      't.term_number',
      trx.raw("NULLIF(concat_ws(' ', st.first_name, st.last_name), '') AS teacher_name")
    )
    .first();
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');
  // Sin aprobar no se publica (revisión académica activa): igual que si no existiera.
  if (plan.review_status !== 'aprobado' && (await familiesSeeOnlyApproved(trx, tenantId))) throw ApiError.notFound('Plan de evaluación no encontrado.');
  delete plan.review_status;

  const rows = (
    await sortByProgram(
      trx,
      await trx('evaluation_activities')
        .where({ tenant_id: tenantId, evaluation_plan_id: planId })
        .select('id', 'title', 'category', 'weight_percent', 'instrument', 'strategy', 'content_refs', 'max_score', 'programmatic_content_id', 'created_at',
          trx.raw("to_char(planned_date, 'YYYY-MM-DD') AS planned_date"))
    )
  ).map(({ created_at: _c, ...a }) => a);
  const structure = await loadActivityStructure(trx, rows.map((a) => a.id));
  const contentIds = [...new Set(rows.map((a) => a.programmatic_content_id).filter(Boolean))];
  const contents = new Map(
    (contentIds.length ? await trx('programmatic_content').whereIn('id', contentIds).select('id', 'unit', 'topic') : []).map((c) => [c.id, c])
  );

  const activities = rows.map(({ programmatic_content_id: contentId, planned_date: plannedDate, ...a }) => {
    const { criteria = [], section_dates: dates = [] } = structure.get(a.id) || {};
    const own = dates.find((d) => d.section_id === section.id);
    return {
      ...a,
      weight_percent: Number(a.weight_percent),
      max_score: Number(a.max_score),
      content_refs: a.content_refs || [],
      criteria: criteria.map(({ position, ...c }) => ({ ...c, indicators: c.indicators.map(({ position: _p, ...i }) => i) })),
      // Fecha en la sección del alumno; si el plan no la tiene por sección, la estimada de la actividad.
      section_dates: own ? [own] : plannedDate ? [{ section_id: section.id, applied_on: plannedDate }] : [],
      programmatic_content: contents.get(contentId) || null,
    };
  });

  return {
    ...plan,
    grade_name: section.grade_name,
    grading_scale: section.grading_scale || 'quantitative',
    section: { id: section.id, name: section.name },
    total_weight: round2(activities.reduce((n, a) => n + a.weight_percent, 0)),
    activities,
  };
}

/**
 * Contenido programático de una materia con las evaluaciones de la sección del
 * alumno, para el portal. Con la revisión académica activa solo se publica lo
 * aprobado por coordinación: el contenido (si su programa está aprobado) y las
 * evaluaciones de los planes aprobados. Cada evaluación trae estrategia,
 * porcentaje y su fecha EN LA SECCIÓN del alumno (o la estimada del plan).
 */
async function getStudentSubjectProgram(trx, tenantId, studentId, subjectId, { schoolPeriodId } = {}) {
  const section = await trx('enrollments as e')
    .join('sections as sec', 'sec.id', 'e.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('school_periods as sp', 'sp.id', 'sec.school_period_id')
    .where({ 'e.tenant_id': tenantId, 'e.student_id': studentId })
    .modify((q) => schoolPeriodId && q.andWhere('sec.school_period_id', schoolPeriodId))
    .select('sec.id', 'sec.name', 'sec.grade_id', 'g.name as grade_name', 'sp.id as period_id', 'sp.name as period_name')
    .orderByRaw(`(e.status = 'active') DESC, ${currentPeriodOrder('sp')}`)
    .first();
  if (!section) throw ApiError.notFound('El alumno no tiene inscripciones en ese año escolar.');
  const subject = await trx('grade_subjects as gs')
    .join('subjects as s', 's.id', 'gs.subject_id')
    .where({ 'gs.grade_id': section.grade_id, 'gs.subject_id': subjectId, 's.tenant_id': tenantId })
    .first('s.id', 's.name', 's.code');
  if (!subject) throw ApiError.notFound('La materia no se dicta en el grado del alumno.');

  const onlyApproved = await familiesSeeOnlyApproved(trx, tenantId);

  // Evaluaciones de los planes (publicados) de la materia en la sección del alumno, en el año.
  const activities = await trx('evaluation_activities as a')
    .join('evaluation_plans as ep', 'ep.id', 'a.evaluation_plan_id')
    .join('evaluation_plan_sections as eps', function onSection() {
      this.on('eps.plan_id', 'ep.id').andOn('eps.section_id', trx.raw('?', [section.id]));
    })
    .join('terms as t', 't.id', 'ep.term_id')
    .leftJoin('activity_section_dates as d', function onDate() {
      this.on('d.activity_id', 'a.id').andOn('d.section_id', trx.raw('?', [section.id]));
    })
    .leftJoin('programmatic_content as pc', 'pc.id', 'a.programmatic_content_id')
    .where({ 'a.tenant_id': tenantId, 'ep.subject_id': subjectId, 't.school_period_id': section.period_id })
    .modify((q) => onlyApproved && q.andWhere('ep.review_status', 'aprobado'))
    .select(
      'a.id',
      'a.title',
      'a.category',
      'a.strategy',
      'a.instrument',
      'a.weight_percent',
      'a.programmatic_content_id',
      'pc.unit',
      'pc.topic',
      't.term_number',
      't.name as term_name',
      trx.raw("to_char(COALESCE(d.applied_on, a.planned_date), 'YYYY-MM-DD') AS date")
    )
    .orderByRaw('t.term_number NULLS LAST, COALESCE(d.applied_on, a.planned_date) NULLS LAST, a.created_at');
  const evaluation = ({ programmatic_content_id: _c, unit: _u, topic: _t, ...a }) => ({ ...a, weight_percent: Number(a.weight_percent) });

  // Contenido: con la revisión activa, solo si el programa está aprobado.
  // Temario y revisión del año de la inscripción del alumno (068).
  const programWhere = { tenant_id: tenantId, grade_id: section.grade_id, subject_id: subjectId, school_period_id: section.period_id };
  const review = await trx('programmatic_content_reviews').where(programWhere).first('status');
  const items = await trx('programmatic_content').where(programWhere).orderBy(['sort_order', 'created_at']);
  const published = items.length > 0 && (!onlyApproved || review?.status === 'aprobado');
  const units = published
    ? [...new Set(items.map((i) => i.unit))].sort(compareUnits).map((unit) => ({
        unit,
        items: items
          .filter((i) => i.unit === unit)
          .map((i) => ({ id: i.id, topic: i.topic, description: i.description, evaluations: activities.filter((a) => a.programmatic_content_id === i.id).map(evaluation) })),
      }))
    : [];
  const shown = new Set(published ? items.map((i) => i.id) : []);
  const otherEvaluations = activities
    .filter((a) => !shown.has(a.programmatic_content_id))
    .map((a) => ({ ...evaluation(a), topic: a.topic || null, unit: a.unit || null }));

  return {
    subject: { id: subject.id, name: subject.name, code: subject.code },
    grade_name: section.grade_name,
    section_name: section.name,
    school_period: { id: section.period_id, name: section.period_name },
    content_status: !items.length ? 'empty' : published ? 'published' : 'pending',
    units,
    other_evaluations: otherEvaluations,
    total_weight_by_term: [...new Map(activities.map((a) => [a.term_name, 0])).keys()].map((term) => ({
      term_name: term,
      total: round2(activities.filter((a) => a.term_name === term).reduce((s, a) => s + Number(a.weight_percent), 0)),
    })),
  };
}

module.exports = {
  assertGuardianOfStudent, assertGradesUnlocked, overdueCount, GRADES_LOCKED_MESSAGE, getStudentGrades, getStudentPlanDetail, buildPlanDetail, getStudentSubjectProgram, GRADE_SCALE, PASSING_GRADE };

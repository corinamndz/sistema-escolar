const { ApiError } = require('../../utils/ApiError');
const teacherScope = require('../access/teacherScope');
const coordinatorScope = require('../access/coordinatorScope');
const { isAdmin } = require('../../middlewares/admin.middleware');
const { getEffectivePermissions } = require('../../middlewares/permission.middleware');
const { isContentReviewRequired } = require('./reviewSettings.service');
const notifications = require('../notifications/notification.service');
const familyNotify = require('../notifications/notify');

/**
 * Revisión y aprobación (migración 058) de Planes de evaluación y Contenido
 * programático entre el Docente y quien revisa.
 *
 *   borrador ─enviar─▶ en_revision ─aprobar─▶ aprobado
 *                         └─devolver (con observaciones)─▶ observado ─reenviar─▶ en_revision
 *   Cualquier cambio a algo en_revision o aprobado lo devuelve a borrador (trigger).
 *
 * Quién hace qué (por cada plan o programa):
 *   Revisor   el Coordinador de SU nivel (el del grado de la sección o del programa)
 *             o el Director (Administrador / quien edita roles).
 *   Docente   quien tiene el plan o la materia en su carga (alcance del docente).
 *   Lectura   cualquier otro con acceso a Planes (sin restricción de carga ni nivel).
 * Un coordinador de otro nivel o un docente sin esa carga reciben 404.
 *
 * Contenido programático (migración 059): la revisión es un ajuste del colegio
 * (tenant_settings.requires_academic_review). Desactivada, el docente publica
 * sin revisión. Activada, mientras el programa está en revisión o aprobado el
 * docente no lo puede editar (`locked`); para cambiar algo aprobado, quien
 * revisa lo reabre. Los planes de evaluación siguen su flujo de siempre.
 *
 * Aprobación DIRECTA (migración 081): el Administrador o el Coordinador del
 * nivel aprueban sin que el docente lo envíe (borrador / con observaciones /
 * en revisión → aprobado), con las mismas condiciones que para enviarlo
 * (plan al 100 %, programa con contenido). Queda registrado: approval_mode =
 * 'direct', reviewed_at / reviewed_by y el evento 'direct_approved' en el hilo.
 *
 * Avisos (campana, personales): al enviar → los coordinadores del nivel (o el
 * Director si el nivel no tiene coordinador); al aprobar, pedir ajustes o
 * reabrir → el docente que lo envió.
 */

const STATUS_LABELS = { borrador: 'Borrador', en_revision: 'En revisión', observado: 'Con observaciones', aprobado: 'Aprobado' };
const ROLE_LABELS = { docente: 'Docente', coordinacion: 'Coordinación', direccion: 'Dirección', sistema: 'Sistema' };
const LEVEL_NAMES = coordinatorScope.LEVEL_LABELS;

// ---------------------------------------------------------------------------
// Objetivo de la revisión: un plan o el programa de una materia en un grado
// ---------------------------------------------------------------------------

async function loadPlanTarget(trx, tenantId, planId) {
  const plan = await trx('evaluation_plans as ep')
    .join('sections as sec', 'sec.id', 'ep.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('terms as t', 't.id', 'ep.term_id')
    .join('staff as st', 'st.id', 'ep.teacher_id')
    .leftJoin('subjects as sub', 'sub.id', 'ep.subject_id')
    .where({ 'ep.id': planId, 'ep.tenant_id': tenantId })
    .select(
      'ep.id',
      'ep.subject_id',
      'ep.teacher_id',
      'ep.review_status as status',
      'ep.submitted_at',
      'ep.submitted_by',
      'ep.reviewed_at',
      'ep.reviewed_by',
      'ep.approval_mode',
      'g.level_code',
      'g.name as grade_name',
      'sec.name as section_name',
      't.name as term_name',
      trx.raw('COALESCE(sub.name, ep.subject) AS subject_name'),
      trx.raw("st.first_name || ' ' || st.last_name AS teacher_name"),
      trx.raw('(SELECT count(*)::int FROM evaluation_activities a WHERE a.evaluation_plan_id = ep.id) AS activity_count'),
      trx.raw('(SELECT COALESCE(sum(a.weight_percent), 0)::float FROM evaluation_activities a WHERE a.evaluation_plan_id = ep.id) AS total_weight')
    )
    .first();
  if (!plan) throw ApiError.notFound('Plan de evaluación no encontrado.');
  const sectionIds = await trx('evaluation_plan_sections').where({ plan_id: planId }).pluck('section_id');
  return {
    type: 'plan',
    key: { planId },
    enabled: true,
    ...plan,
    sectionIds: sectionIds.length ? sectionIds : [],
    title: `${plan.subject_name} · ${plan.grade_name} ${plan.section_name} · ${plan.term_name}`,
  };
}

/** Programa de una materia en un grado EN UN AÑO (068: cada año tiene su temario y su revisión). */
async function loadContentTarget(trx, tenantId, gradeId, subjectId, schoolPeriodId) {
  const pair = await trx('grade_subjects as gs')
    .join('grades as g', 'g.id', 'gs.grade_id')
    .join('subjects as s', 's.id', 'gs.subject_id')
    .where({ 'gs.grade_id': gradeId, 'gs.subject_id': subjectId, 'g.tenant_id': tenantId })
    .select('g.level_code', 'g.name as grade_name', 's.name as subject_name')
    .first();
  if (!pair) throw ApiError.notFound('La materia no se dicta en ese grado.');
  const period = await trx('school_periods').where({ id: schoolPeriodId, tenant_id: tenantId }).first('id', 'name');
  if (!period) throw ApiError.notFound('Año escolar no encontrado.');
  const where = { tenant_id: tenantId, grade_id: gradeId, subject_id: subjectId, school_period_id: schoolPeriodId };
  const review = await trx('programmatic_content_reviews').where(where).first();
  const items = await trx('programmatic_content').where(where).count('* as n').first();
  return {
    type: 'content',
    key: { gradeId, subjectId, schoolPeriodId },
    enabled: await isContentReviewRequired(trx, tenantId),
    id: review?.id || null,
    status: review?.status || 'borrador',
    submitted_at: review?.submitted_at || null,
    submitted_by: review?.submitted_by || null,
    reviewed_at: review?.reviewed_at || null,
    reviewed_by: review?.reviewed_by || null,
    approval_mode: review?.approval_mode || null,
    level_code: pair.level_code,
    grade_name: pair.grade_name,
    subject_name: pair.subject_name,
    item_count: Number(items.n),
    title: `${pair.subject_name} · ${pair.grade_name} · ${period.name}`,
  };
}

// ---------------------------------------------------------------------------
// Papel del usuario frente a ESE plan o programa
// ---------------------------------------------------------------------------

/** 'reviewer' | 'author' | 'viewer' (404 si no puede verlo). */
async function roleFor(req, target) {
  const perms = req.permissions || (await getEffectivePermissions(req.db, req.tenantId, req.user.id));
  const admin = await isAdmin(req.db, req.tenantId, req.user.id);
  if (perms.roles?.can_update || admin) return { role: 'reviewer', as: 'direccion', admin };

  const coord = await coordinatorScope.getCoordinatorScope(req);
  if (coord) {
    coordinatorScope.assertHasLevel(coord);
    if (coord.level !== target.level_code) throw ApiError.notFound(`${target.type === 'plan' ? 'Plan' : 'Contenido'} no encontrado o fuera de tu nivel de coordinación.`);
    return { role: 'reviewer', as: 'coordinacion' };
  }

  const scope = await teacherScope.getTeacherScope(req);
  if (scope) {
    const covers =
      target.type === 'plan'
        ? target.teacher_id === scope.staffId || teacherScope.coversPlan(scope, { subject_id: target.subject_id }, target.sectionIds)
        : (await teacherScope.teachingPairs(req)).has(`${target.key.gradeId}|${target.key.subjectId}`);
    if (!covers) throw ApiError.notFound(`${target.type === 'plan' ? 'Plan' : 'Contenido'} no encontrado o fuera de tu carga docente.`);
    return { role: 'author', as: 'docente' };
  }
  return { role: 'viewer', as: null };
}

const LOCKED_STATUSES = ['en_revision', 'aprobado'];

/** Aprobación directa: solo el Administrador o el Coordinador del nivel (no basta con editar roles). */
const canApproveDirectly = (role) => role.role === 'reviewer' && (role.admin === true || role.as === 'coordinacion');

const canDo = (role, status, enabled = true, direct = false) => ({
  submit: enabled && role === 'author' && ['borrador', 'observado'].includes(status),
  directApprove: enabled && direct && status !== 'aprobado',
  review: enabled && role === 'reviewer' && status === 'en_revision',
  reopen: enabled && role === 'reviewer' && status === 'aprobado',
  comment: role === 'author' || role === 'reviewer',
});

/** El docente no edita un programa en revisión o aprobado (solo con la revisión activada). */
const isLockedFor = (role, target) => target.type === 'content' && target.enabled && role === 'author' && LOCKED_STATUSES.includes(target.status);

// ---------------------------------------------------------------------------
// Lectura
// ---------------------------------------------------------------------------

async function commentsOf(trx, target) {
  if (target.type === 'content' && !target.id) return [];
  return trx('review_comments')
    .where(target.type === 'plan' ? { plan_id: target.id } : { content_review_id: target.id })
    .orderBy('created_at')
    .select('id', 'user_id', 'author_name', 'author_role', 'kind', 'body', 'created_at')
    .then((rows) => rows.map((c) => ({ ...c, author_role_label: ROLE_LABELS[c.author_role] || null })));
}

async function nameOf(trx, userId) {
  if (!userId) return null;
  const u = await trx('users').where({ id: userId }).first('full_name', 'username');
  return u?.full_name || u?.username || null;
}

async function present(req, target, role) {
  const can = canDo(role.role, target.status, target.enabled, canApproveDirectly(role));
  return {
    type: target.type,
    ...target.key,
    enabled: target.enabled,
    locked: isLockedFor(role.role, target),
    title: target.title,
    level_code: target.level_code,
    level_name: LEVEL_NAMES[target.level_code] || null,
    teacher_name: target.teacher_name || null,
    status: target.status,
    status_label: STATUS_LABELS[target.status],
    submitted_at: target.submitted_at,
    submitted_by_name: await nameOf(req.db, target.submitted_by),
    reviewed_at: target.reviewed_at,
    reviewed_by_name: await nameOf(req.db, target.reviewed_by),
    // Cómo quedó aprobado: 'review' (revisión normal) | 'direct' (aprobación directa).
    approval_mode: target.status === 'aprobado' ? target.approval_mode || 'review' : null,
    my_role: role.role,
    can,
    comments: await commentsOf(req.db, target),
  };
}

const loadTarget = (req, type, key) => (type === 'plan' ? loadPlanTarget(req.db, req.tenantId, key.planId) : loadContentTarget(req.db, req.tenantId, key.gradeId, key.subjectId, key.schoolPeriodId));

async function getReview(req, type, key) {
  const target = await loadTarget(req, type, key);
  return present(req, target, await roleFor(req, target));
}

// ---------------------------------------------------------------------------
// Acciones
// ---------------------------------------------------------------------------

/** Programa: crea su registro de revisión la primera vez que se usa. */
async function ensureContentReview(trx, tenantId, target) {
  if (target.id) return target.id;
  const [row] = await trx('programmatic_content_reviews')
    .insert({ tenant_id: tenantId, grade_id: target.key.gradeId, subject_id: target.key.subjectId, school_period_id: target.key.schoolPeriodId })
    .onConflict(['tenant_id', 'grade_id', 'subject_id', 'school_period_id'])
    .merge({ tenant_id: tenantId })
    .returning('id');
  target.id = row.id;
  return row.id;
}

async function addEntry(req, target, role, { kind, body = null }) {
  const id = target.type === 'plan' ? target.id : await ensureContentReview(req.db, req.tenantId, target);
  await req.db('review_comments').insert({
    tenant_id: req.tenantId,
    ...(target.type === 'plan' ? { plan_id: id } : { content_review_id: id }),
    user_id: req.user.id,
    author_name: await nameOf(req.db, req.user.id),
    author_role: role.as || (role.role === 'author' ? 'docente' : null),
    kind,
    body: body?.trim() || null,
  });
}

async function setStatus(req, target, status, extra) {
  if (target.type === 'plan') {
    await req.db('evaluation_plans').where({ id: target.id }).update({ review_status: status, ...extra });
  } else {
    const id = await ensureContentReview(req.db, req.tenantId, target);
    await req.db('programmatic_content_reviews').where({ id }).update({ status, ...extra });
  }
  target.status = status;
  Object.assign(target, extra);
}

const whatOf = (target) => (target.type === 'plan' ? 'el plan' : 'el contenido');

// ---------------------------------------------------------------------------
// Avisos de la campana (personales, migración 059)
// ---------------------------------------------------------------------------

/** Usuarios activos con un rol de sistema (ej. 'Administrador'), opcionalmente filtrados. */
const usersWithRole = (trx, tenantId, roleName) =>
  trx('users as u')
    .join('user_roles as ur', 'ur.user_id', 'u.id')
    .join('roles as r', 'r.id', 'ur.role_id')
    .where({ 'u.tenant_id': tenantId, 'u.status': 'active', 'r.tenant_id': tenantId, 'r.name': roleName });

/** Quien recibe lo enviado: los coordinadores del nivel; si el nivel no tiene, el Director. */
async function reviewersOf(trx, tenantId, level) {
  const coordinators = await usersWithRole(trx, tenantId, 'Coordinador')
    .join('staff as st', function onStaff() {
      this.on('st.user_id', 'u.id').andOn('st.tenant_id', 'u.tenant_id');
    })
    .where('st.coordination_level', level)
    .distinct('u.id')
    .pluck('u.id');
  if (coordinators.length) return coordinators;
  return usersWithRole(trx, tenantId, 'Administrador').where('r.is_system', true).distinct('u.id').pluck('u.id');
}

const linkOf = (target) =>
  target.type === 'plan'
    ? `/evaluation-plans/${target.key.planId}?revision=1`
    : `/programmatic-content?materia=${target.key.subjectId}&grado=${target.key.gradeId}&ano=${target.key.schoolPeriodId}&revision=1`;

const clip = (text, max) => (text && text.length > max ? `${text.slice(0, max - 1)}…` : text);

async function notify(req, target, userIds, { type, title, body }) {
  const to = [...new Set(userIds.filter((id) => id && id !== req.user.id))];
  if (!to.length) return;
  await notifications.createNotification(req.db, req.tenantId, {
    type,
    title: clip(title, 150),
    body: clip(body, 500),
    targetUserIds: to,
    data: { links: { users: linkOf(target) }, link_label: type === 'review_request' ? 'Revisar' : 'Ver revisión', review: { type: target.type, ...target.key } },
  });
}

/** Avisa a los coordinadores del nivel (o al Director) que algo espera su revisión. */
async function notifyReviewers(req, target, { resend, comment }) {
  const who = await nameOf(req.db, req.user.id);
  const what = target.type === 'plan' ? 'el plan de evaluación' : 'el contenido programático';
  await notify(req, target, await reviewersOf(req.db, req.tenantId, target.level_code), {
    type: 'review_request',
    title: target.type === 'plan' ? 'Plan de evaluación por revisar' : 'Contenido programático por revisar',
    body: `${who || 'Un docente'} ${resend ? 'reenvió, tras ajustarlo,' : 'envió a revisión'} ${what} de ${target.title} (${LEVEL_NAMES[target.level_code] || 'nivel'}).${comment ? ` Nota: «${clip(comment, 160)}»` : ''}`,
  });
}

/** Avisa al docente que lo envió el resultado de la revisión. */
async function notifyAuthor(req, target, submittedBy, { decision, comment }) {
  const who = await nameOf(req.db, req.user.id);
  const subject = target.type === 'plan' ? 'Plan de evaluación' : 'Contenido programático';
  const texts = {
    approve: [`${subject} aprobado`, `${who || 'Coordinación'} aprobó ${whatOf(target)} de ${target.title}.`],
    observe: [`Ajustes solicitados: ${subject.toLowerCase()}`, `${who || 'Coordinación'} pidió ajustes en ${whatOf(target)} de ${target.title}.`],
    reopen: [`${subject} reabierto`, `${who || 'Coordinación'} reabrió ${whatOf(target)} de ${target.title}: ya puedes editarlo y reenviarlo.`],
  };
  const [title, body] = texts[decision];
  await notify(req, target, [submittedBy], { type: 'review_result', title, body: `${body}${comment ? ` «${clip(comment, 200)}»` : ''}` });
}

/**
 * Plan APROBADO → aviso a las familias (evento 'evaluation_plan' de la matriz
 * de avisos: campana y, si el colegio lo activa, correo). Uno por alumno
 * inscrito en las secciones del plan, dirigido a sus representantes, con el
 * enlace a la materia en el portal de ESE alumno.
 */
async function notifyFamiliesPlanApproved(req, target) {
  const sectionIds = target.sectionIds?.length ? target.sectionIds : [];
  if (!sectionIds.length) return 0;
  const students = await req
    .db('enrollments as e')
    .join('students as s', 's.id', 'e.student_id')
    .join('sections as sec', 'sec.id', 'e.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .where({ 'e.tenant_id': req.tenantId, 'e.status': 'active' })
    .whereIn('e.section_id', sectionIds)
    .select('s.id', 's.first_name', 's.last_name', 'g.name as grade_name', 'sec.name as section_name');
  let sent = 0;
  for (const s of students) {
    const guardianIds = await familyNotify.guardiansOfStudents(req.db, req.tenantId, [s.id]);
    if (!guardianIds.length) continue;
    await familyNotify.notify(req.db, req.tenantId, {
      event: 'evaluation_plan',
      guardianIds,
      title: 'Plan de evaluación publicado',
      body: `Nuevo Plan de Evaluación aprobado y publicado para la cátedra ${target.subject_name} (${s.first_name} ${s.last_name}, ${s.grade_name} ${s.section_name}, ${target.term_name}).`,
      data: { plan_id: target.id, student_id: s.id, subject_id: target.subject_id },
      links: { guardians: `/portal/students/${s.id}?materia=${target.subject_id || ''}` },
      linkLabel: 'Ver contenido y evaluaciones',
    });
    sent += 1;
  }
  return sent;
}

/** Docente: borrador u observado → en_revision. */
async function submit(req, type, key, { comment } = {}) {
  const target = await loadTarget(req, type, key);
  const role = await roleFor(req, target);
  if (role.role !== 'author') throw ApiError.forbidden('Solo el docente a cargo envía a revisión.');
  if (!target.enabled) throw ApiError.conflict('El colegio no tiene activada la revisión académica: el contenido se publica al guardarlo.');
  if (!canDo(role.role, target.status).submit) throw ApiError.conflict(`No se puede enviar: ${whatOf(target)} está ${STATUS_LABELS[target.status].toLowerCase()}.`);
  assertComplete(target, 'enviar');
  const resend = target.status === 'observado';
  await setStatus(req, target, 'en_revision', { submitted_at: req.db.fn.now(), submitted_by: req.user.id });
  await addEntry(req, target, role, { kind: 'submitted', body: comment || (resend ? 'Reenviado tras ajustar las observaciones.' : null) });
  await notifyReviewers(req, target, { resend, comment });
  return getReview(req, type, key);
}

/**
 * Revisor: en_revision → observado (ajustes, con comentario obligatorio) o →
 * aprobado; aprobado → borrador con 'reopen' (para que el docente lo cambie).
 */
async function review(req, type, key, { decision, comment }) {
  const target = await loadTarget(req, type, key);
  const role = await roleFor(req, target);
  if (role.role !== 'reviewer') throw ApiError.forbidden('Solo el coordinador del nivel o el Director revisan.');
  if (!target.enabled) throw ApiError.conflict('El colegio no tiene activada la revisión académica del contenido programático.');
  const submittedBy = target.submitted_by;

  if (decision === 'reopen') {
    if (target.status !== 'aprobado') throw ApiError.conflict(`Solo se reabre lo aprobado (${whatOf(target)} está ${STATUS_LABELS[target.status].toLowerCase()}).`);
    await setStatus(req, target, 'borrador', { approval_mode: null });
    await addEntry(req, target, role, { kind: 'reset', body: comment?.trim() || `Reabierto por ${role.as === 'direccion' ? 'la Dirección' : 'coordinación'} para hacer ajustes.` });
    await notifyAuthor(req, target, submittedBy, { decision, comment });
    return getReview(req, type, key);
  }

  if (target.status !== 'en_revision') throw ApiError.conflict(`${whatOf(target).replace(/^el /, 'El ')} no está en revisión (está ${STATUS_LABELS[target.status].toLowerCase()}).`);
  if (decision === 'observe' && !comment?.trim()) {
    throw ApiError.badRequest('Escribe los ajustes que pides al docente.', [{ path: 'comment', message: 'Obligatorio al pedir ajustes.' }]);
  }
  const status = decision === 'approve' ? 'aprobado' : 'observado';
  await setStatus(req, target, status, { reviewed_at: req.db.fn.now(), reviewed_by: req.user.id, approval_mode: status === 'aprobado' ? 'review' : null });
  await addEntry(req, target, role, { kind: decision === 'approve' ? 'approved' : 'observed', body: comment });
  await notifyAuthor(req, target, submittedBy, { decision, comment });
  // Aprobado = publicado en el portal: se avisa a las familias de sus secciones.
  if (decision === 'approve' && target.type === 'plan') await notifyFamiliesPlanApproved(req, target);
  return getReview(req, type, key);
}

/** Lo mínimo para enviar o aprobar: plan con actividades al 100 %, programa con contenido. */
function assertComplete(target, verb) {
  const action = verb === 'aprobar' ? 'aprobarlo' : 'enviarlo a revisión';
  if (target.type === 'plan') {
    if (!target.activity_count) throw ApiError.unprocessable(`Agrega al menos una actividad al plan antes de ${action}.`);
    if (Math.abs(target.total_weight - 100) > 0.01) {
      throw ApiError.unprocessable(`Las actividades deben sumar 100 % para ${action} (suman ${Number(target.total_weight.toFixed(2))} %).`);
    }
  } else if (!target.item_count) {
    throw ApiError.unprocessable(`Agrega al menos una unidad o tema al contenido antes de ${action}.`);
  }
}

/**
 * APROBACIÓN DIRECTA (Administrador o Coordinador del nivel): borrador, con
 * observaciones o en revisión → aprobado, sin que el docente lo envíe. Se
 * valida el rol EN EL SERVIDOR (roleFor + canApproveDirectly), no solo el botón.
 */
async function directApprove(req, type, key, { comment } = {}) {
  const target = await loadTarget(req, type, key);
  const role = await roleFor(req, target);
  if (!canApproveDirectly(role)) throw ApiError.forbidden('Solo el Administrador o el Coordinador del nivel pueden aprobar directamente.');
  if (!target.enabled) throw ApiError.conflict('El colegio no tiene activada la revisión académica: el contenido se publica al guardarlo.');
  if (target.status === 'aprobado') throw ApiError.conflict(`${whatOf(target).replace(/^el /, 'El ')} ya está aprobado.`);
  assertComplete(target, 'aprobar');

  const from = target.status;
  // Destinatario del aviso: quien lo envió o, si nunca se envió, el docente del plan.
  let author = target.submitted_by;
  if (!author && target.type === 'plan' && target.teacher_id) author = (await req.db('staff').where({ id: target.teacher_id }).first('user_id'))?.user_id || null;

  await setStatus(req, target, 'aprobado', { reviewed_at: req.db.fn.now(), reviewed_by: req.user.id, approval_mode: 'direct' });
  await addEntry(req, target, role, {
    kind: 'direct_approved',
    body: comment?.trim() || `Aprobación directa (estaba ${STATUS_LABELS[from].toLowerCase()}).`,
  });
  await notifyAuthor(req, target, author, { decision: 'approve', comment });
  if (target.type === 'plan') await notifyFamiliesPlanApproved(req, target);
  return getReview(req, type, key);
}

/**
 * Programa de una materia en un grado: ¿lo puede editar este usuario ahora?
 * Lanza 409 si es el docente y está en revisión o aprobado (revisión activada).
 */
async function assertContentEditable(req, gradeId, subjectId, schoolPeriodId) {
  const target = await loadContentTarget(req.db, req.tenantId, gradeId, subjectId, schoolPeriodId);
  if (!target.enabled || !LOCKED_STATUSES.includes(target.status)) return;
  const role = await roleFor(req, target);
  if (!isLockedFor(role.role, target)) return;
  throw ApiError.conflict(
    target.status === 'en_revision'
      ? `El contenido de ${target.title} está en revisión: no se puede editar hasta que coordinación responda.`
      : `El contenido de ${target.title} está aprobado: para cambiarlo, pide a coordinación que lo reabra.`
  );
}

/** Estado de revisión del programa para la página de Contenido programático. */
async function contentReviewState(req, gradeId, subjectId, schoolPeriodId) {
  const target = await loadContentTarget(req.db, req.tenantId, gradeId, subjectId, schoolPeriodId);
  const role = await roleFor(req, target);
  return {
    enabled: target.enabled,
    status: target.status,
    status_label: STATUS_LABELS[target.status],
    my_role: role.role,
    locked: isLockedFor(role.role, target),
    // Botón de aprobación directa (Administrador / Coordinador del nivel).
    can_direct_approve: canDo(role.role, target.status, target.enabled, canApproveDirectly(role)).directApprove,
    approval_mode: target.status === 'aprobado' ? target.approval_mode || 'review' : null,
  };
}

/** Docente o revisor: comentario en el hilo (sin cambiar el estado). */
async function comment(req, type, key, { body }) {
  const target = await loadTarget(req, type, key);
  const role = await roleFor(req, target);
  if (!canDo(role.role, target.status).comment) throw ApiError.forbidden('Solo el docente a cargo y quien revisa pueden comentar.');
  await addEntry(req, target, role, { kind: 'comment', body });
  return getReview(req, type, key);
}

// ---------------------------------------------------------------------------
// Bandeja del revisor: lo que espera revisión en su alcance
// ---------------------------------------------------------------------------

async function inbox(req) {
  const perms = req.permissions || (await getEffectivePermissions(req.db, req.tenantId, req.user.id));
  const director = perms.roles?.can_update || (await isAdmin(req.db, req.tenantId, req.user.id));
  const coord = director ? null : await coordinatorScope.getCoordinatorScope(req);
  if (!director && !coord) return { reviewer: false, items: [] };
  coordinatorScope.assertHasLevel(coord);
  const level = coord?.level || null;

  const plans = await req
    .db('evaluation_plans as ep')
    .join('sections as sec', 'sec.id', 'ep.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('terms as t', 't.id', 'ep.term_id')
    .join('staff as st', 'st.id', 'ep.teacher_id')
    .leftJoin('subjects as sub', 'sub.id', 'ep.subject_id')
    .leftJoin('users as u', 'u.id', 'ep.submitted_by')
    .where({ 'ep.tenant_id': req.tenantId, 'ep.review_status': 'en_revision' })
    .modify((q) => level && q.andWhere('g.level_code', level))
    .select(
      'ep.id as plan_id',
      'ep.submitted_at',
      'g.level_code',
      req.db.raw("COALESCE(sub.name, ep.subject) || ' · ' || g.name || ' ' || sec.name || ' · ' || t.name AS title"),
      req.db.raw("st.first_name || ' ' || st.last_name AS teacher_name"),
      req.db.raw('COALESCE(u.full_name, u.username) AS submitted_by_name')
    )
    .orderBy('ep.submitted_at');
  // Con la revisión del contenido desactivada, los programas no esperan a nadie.
  const contentEnabled = await isContentReviewRequired(req.db, req.tenantId);
  const contents = !contentEnabled ? [] : await req
    .db('programmatic_content_reviews as r')
    .join('grades as g', 'g.id', 'r.grade_id')
    .join('subjects as s', 's.id', 'r.subject_id')
    .join('school_periods as sp', 'sp.id', 'r.school_period_id')
    .leftJoin('users as u', 'u.id', 'r.submitted_by')
    .where({ 'r.tenant_id': req.tenantId, 'r.status': 'en_revision' })
    .modify((q) => level && q.andWhere('g.level_code', level))
    .select(
      'r.grade_id',
      'r.subject_id',
      'r.school_period_id',
      'r.submitted_at',
      'g.level_code',
      req.db.raw("s.name || ' · ' || g.name || ' · ' || sp.name AS title"),
      req.db.raw('COALESCE(u.full_name, u.username) AS submitted_by_name')
    )
    .orderBy('r.submitted_at');

  const items = [
    ...plans.map((p) => ({ type: 'plan', planId: p.plan_id, title: p.title, teacher_name: p.teacher_name, submitted_by_name: p.submitted_by_name, submitted_at: p.submitted_at, level_name: LEVEL_NAMES[p.level_code] })),
    ...contents.map((c) => ({ type: 'content', gradeId: c.grade_id, subjectId: c.subject_id, schoolPeriodId: c.school_period_id, title: c.title, submitted_by_name: c.submitted_by_name, submitted_at: c.submitted_at, level_name: LEVEL_NAMES[c.level_code] })),
  ].sort((a, b) => new Date(a.submitted_at) - new Date(b.submitted_at));
  return { reviewer: true, level: level ? { code: level, name: LEVEL_NAMES[level] } : null, items };
}

module.exports = {
  directApprove, STATUS_LABELS, getReview, submit, review, comment, inbox, assertContentEditable, contentReviewState };

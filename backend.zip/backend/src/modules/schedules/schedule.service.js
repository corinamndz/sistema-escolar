const { ApiError } = require('../../utils/ApiError');
const assignmentService = require('../academics/assignment.service');
const { restrictStaffToLevel } = require('../access/coordinatorScope');
const { generateSchedulePdf } = require('../../services/pdf/scheduleGenerator');
const { generateEvaluationCalendarPdf } = require('../../services/pdf/evaluationCalendarGenerator');
const evaluationCalendar = require('./evaluationCalendar.service');
const { resolveLogoFileOrDefault } = require('../../services/storage/logoStorage');
const { currentPeriodOrder } = require('../../utils/schoolPeriods');

/**
 * Horarios de clase.
 *
 *   Bloques (time_slots): por año escolar y JORNADA (migración 074). Cada nivel
 *     (Inicial, Primaria, Secundaria) puede tener su jornada propia, con sus
 *     bloques y todos los recreos que necesite; si no, usa la jornada general.
 *   Clase (class_schedules): sección + materia + docente + día + bloque.
 *
 * El docente de cada clase sale de la carga docente de la sección (el
 * profesor de la materia, o en Primaria el titular si la materia no tiene
 * especialista). Al colocar o mover una clase se valida, con mensajes claros,
 * que la celda esté libre, que el bloque sea de la jornada del nivel y no un
 * recreo, y que el docente NO tenga otra clase ese día que se SOLAPE en el
 * tiempo (en cualquier sección y nivel, aunque las jornadas tengan horas
 * distintas). La base de datos además lo garantiza (074) por si dos personas
 * guardan a la vez.
 */

const DAYS = [
  { day: 1, name: 'Lunes' },
  { day: 2, name: 'Martes' },
  { day: 3, name: 'Miércoles' },
  { day: 4, name: 'Jueves' },
  { day: 5, name: 'Viernes' },
];
const dayName = (d) => DAYS.find((x) => x.day === Number(d))?.name || '';
const hhmm = (t) => String(t).slice(0, 5);
const toMinutes = (t) => {
  const [h, m] = hhmm(t).split(':').map(Number);
  return h * 60 + m;
};

// ---------------------------------------------------------------------------
// Bloques horarios
// ---------------------------------------------------------------------------

async function loadPeriod(trx, tenantId, periodId) {
  const period = await trx('school_periods').where({ id: periodId, tenant_id: tenantId }).first();
  if (!period) throw ApiError.notFound('Año escolar no encontrado.');
  return period;
}

const formatSlot = (s) => ({ ...s, start_time: hhmm(s.start_time), end_time: hhmm(s.end_time) });
/** ¿Se solapan dos intervalos [inicio, fin) de horas? */
const overlaps = (a, b) => toMinutes(a.start_time) < toMinutes(b.end_time) && toMinutes(b.start_time) < toMinutes(a.end_time);

/**
 * Bloques de un año escolar (migración 074: jornada por nivel).
 *   `levelCode` undefined → TODOS los bloques del año (todas las jornadas);
 *   null                  → la jornada general;
 *   'primary'…            → la jornada propia de ese nivel (vacía si no tiene).
 */
function listSlots(trx, tenantId, periodId, { levelCode } = {}) {
  return trx('time_slots')
    .where({ tenant_id: tenantId, school_period_id: periodId })
    .modify((q) => {
      if (levelCode === null) q.whereNull('level_code');
      else if (levelCode !== undefined) q.where('level_code', levelCode);
    })
    .orderBy([{ column: 'level_key' }, { column: 'start_time' }])
    .then((rows) => rows.map(formatSlot));
}

/** Jornada que usa un nivel: la propia si la tiene; si no, la general. */
async function slotsForLevel(trx, tenantId, periodId, levelCode) {
  if (levelCode) {
    const own = await listSlots(trx, tenantId, periodId, { levelCode });
    if (own.length) return own;
  }
  return listSlots(trx, tenantId, periodId, { levelCode: null });
}

/**
 * Jornadas del año para el editor: la general y, por nivel, si tiene jornada
 * propia y cuál usa en la práctica.
 * → { general: [slots], levels: [{ code, name, own, slots (propios), effective }] }
 */
async function listStructures(trx, tenantId, periodId) {
  await loadPeriod(trx, tenantId, periodId);
  const all = await listSlots(trx, tenantId, periodId);
  const general = all.filter((s) => !s.level_code);
  const levels = await trx('education_levels').orderBy('sort_order').select('code', 'name');
  return {
    general,
    levels: levels.map((l) => {
      const own = all.filter((s) => s.level_code === l.code);
      return { code: l.code, name: l.name, own: own.length > 0, slots: own, effective: own.length ? own : general };
    }),
  };
}

/**
 * Une varias jornadas en una sola grilla (vistas por docente o de todo el año):
 * los bloques con las mismas horas se muestran en una fila; `alias` lleva cada
 * bloque a la fila que lo representa. Un bloque de una sola jornada de nivel
 * se rotula con el nivel ("Bloque 1 · Primaria") para distinguirlo.
 */
function mergeSlots(slots, levelNames = {}) {
  const rows = new Map();
  const alias = new Map();
  [...slots]
    .sort((a, b) => toMinutes(a.start_time) - toMinutes(b.start_time) || toMinutes(a.end_time) - toMinutes(b.end_time))
    .forEach((s) => {
      const key = `${s.start_time}|${s.end_time}|${s.is_break}`;
      if (!rows.has(key)) rows.set(key, { ...s, levels: new Set() });
      const row = rows.get(key);
      row.levels.add(s.level_code || '*');
      alias.set(s.id, row.id);
    });
  const distinctStructures = new Set(slots.map((s) => s.level_code || '*')).size;
  const out = [...rows.values()].map(({ levels, ...s }) => {
    const only = levels.size === 1 ? [...levels][0] : null;
    const label = distinctStructures > 1 && only && only !== '*' ? `${s.name} · ${levelNames[only] || only}` : s.name;
    return { ...s, name: label, level_codes: [...levels].filter((l) => l !== '*') };
  });
  return { slots: out, alias };
}

/**
 * Reemplaza los bloques de UNA jornada (`levelCode` null = general): actualiza
 * los que traen id, crea los nuevos y borra los que ya no vienen. Reglas:
 *   - dentro de la jornada, bloques y recreos (todos los que se quieran) no se
 *     solapan: así ninguna clase cae en un recreo de su nivel;
 *   - un bloque con clases no se puede borrar ni convertir en recreo;
 *   - al crear (o quitar, con `slots` vacío) la jornada propia de un nivel, sus
 *     clases pasan al bloque de la nueva jornada que empieza a la misma hora;
 *     si alguna no tiene equivalente, no se guarda nada (409 con el detalle);
 *   - ningún docente puede quedar con dos clases solapadas (también en la base).
 */
async function saveSlots(trx, tenantId, periodId, slots, { levelCode = null } = {}) {
  const period = await loadPeriod(trx, tenantId, periodId);
  if (period.closed_at) throw ApiError.unprocessable(`El año escolar ${period.name} está finalizado.`);
  let levelName = 'la jornada general';
  if (levelCode) {
    const level = await trx('education_levels').where({ code: levelCode }).first('name');
    if (!level) throw ApiError.badRequest('Nivel educativo inválido.', [{ path: 'levelCode', message: 'Nivel inválido.' }]);
    levelName = level.name;
  }

  const sorted = [...slots].sort((a, b) => toMinutes(a.startTime) - toMinutes(b.startTime));
  sorted.forEach((s, i) => {
    if (toMinutes(s.endTime) <= toMinutes(s.startTime)) {
      throw ApiError.badRequest(`${s.name}: la hora de fin debe ser posterior a la de inicio.`, [{ path: `slots.${i}`, message: 'Horas inválidas.' }]);
    }
    const prev = sorted[i - 1];
    if (prev && toMinutes(s.startTime) < toMinutes(prev.endTime)) {
      const what = prev.isBreak || s.isBreak ? 'Un bloque de clase no puede solaparse con un recreo' : 'Los bloques no pueden solaparse';
      throw ApiError.badRequest(`${what}: ${prev.name} (${prev.startTime}–${prev.endTime}) y ${s.name} (${s.startTime}–${s.endTime}).`, [
        { path: `slots.${i}`, message: 'Se solapa con otro bloque.' },
      ]);
    }
  });

  const scope = (q) => (levelCode ? q.where('level_code', levelCode) : q.whereNull('level_code'));
  const existing = await trx('time_slots').where({ tenant_id: tenantId, school_period_id: periodId }).modify(scope);
  const keep = new Set(sorted.filter((s) => s.id).map((s) => s.id));
  if (sorted.some((s) => s.id && !existing.some((x) => x.id === s.id))) {
    throw ApiError.badRequest(`Hay bloques que no pertenecen a ${levelName} de este año escolar.`);
  }
  const hadOwn = Boolean(levelCode) && existing.length > 0;
  const willHaveOwn = Boolean(levelCode) && sorted.length > 0;
  // Al cambiar de jornada (crear o quitar la propia) las clases se reubican abajo; si no, no se borran bloques con clases.
  const relocating = Boolean(levelCode) && hadOwn !== willHaveOwn;
  const used = new Set(await trx('class_schedules').whereIn('time_slot_id', existing.map((s) => s.id)).distinct().pluck('time_slot_id'));
  if (!relocating) {
    for (const s of existing.filter((x) => !keep.has(x.id))) {
      if (used.has(s.id)) throw ApiError.conflict(`${s.name} (${hhmm(s.start_time)}–${hhmm(s.end_time)}) tiene clases asignadas: quítalas del horario antes de eliminar el bloque.`);
    }
  }
  for (const s of sorted.filter((x) => x.id && x.isBreak)) {
    if (used.has(s.id)) throw ApiError.conflict(`${s.name} tiene clases asignadas: no puede pasar a ser recreo.`);
  }

  // Quitar la jornada propia: sus clases vuelven primero a la general (si no, sus bloques no se pueden borrar).
  if (relocating && !willHaveOwn) await relocateLevelClasses(trx, tenantId, periodId, levelCode, levelName, { toOwn: false });
  await trx('time_slots').where({ tenant_id: tenantId, school_period_id: periodId }).modify(scope).whereNotIn('id', [...keep]).delete();
  // Bloques nuevos / actualizados (el UNIQUE por jornada y hora es diferible: se puede reordenar).
  for (const [i, s] of sorted.entries()) {
    const row = { name: s.name.trim(), start_time: s.startTime, end_time: s.endTime, is_break: Boolean(s.isBreak), sort_order: i };
    if (s.id) await trx('time_slots').where({ id: s.id, tenant_id: tenantId }).update(row);
    else await trx('time_slots').insert({ ...row, tenant_id: tenantId, school_period_id: periodId, level_code: levelCode });
  }
  // Crear la jornada propia: sus clases pasan a ella.
  if (relocating && willHaveOwn) await relocateLevelClasses(trx, tenantId, periodId, levelCode, levelName, { toOwn: true });

  // TODAS las restricciones diferidas se verifican ya, dentro de la petición: si
  // alguna fallara recién al confirmar, el cambio se revertiría en silencio.
  try {
    await trx.raw('SET CONSTRAINTS ALL IMMEDIATE');
  } catch (err) {
    if (err.code === '23P01') throw ApiError.conflict(`${dbMessage(err)} Revisa las horas: un docente que da clase en varios niveles no puede tener dos clases a la vez.`);
    if (err.code === '23505') throw ApiError.conflict(`Hay dos bloques que empiezan a la misma hora en ${levelName}.`, [{ path: 'slots', message: 'Hora de inicio repetida.' }]);
    throw err;
  }
  return listStructures(trx, tenantId, periodId);
}

/** Mensaje de una excepción de los triggers (sin el prefijo técnico). */
const dbMessage = (err) => String(err.message || '').replace(/^.* - /, '');

/**
 * Tras crear o quitar la jornada propia de un nivel, sus clases pasan a la
 * jornada que ahora usan sus secciones: al bloque (de clase) que empieza a la
 * misma hora. Si alguna no tiene equivalente, se aborta con el detalle.
 */
async function relocateLevelClasses(trx, tenantId, periodId, levelCode, levelName, { toOwn }) {
  const target = (await listSlots(trx, tenantId, periodId, { levelCode: toOwn ? levelCode : null })).filter((s) => !s.is_break);
  const byStart = new Map(target.map((s) => [s.start_time, s]));
  const targetIds = new Set(target.map((s) => s.id));
  const classes = await trx('class_schedules as cs')
    .join('sections as sec', 'sec.id', 'cs.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('time_slots as ts', 'ts.id', 'cs.time_slot_id')
    .join('subjects as sub', 'sub.id', 'cs.subject_id')
    .where({ 'cs.tenant_id': tenantId, 'sec.school_period_id': periodId, 'g.level_code': levelCode })
    .select('cs.id', 'cs.day_of_week', 'ts.start_time', 'ts.end_time', 'g.name as grade_name', 'sec.name as section_name', 'sub.name as subject_name', 'cs.time_slot_id');
  const pending = classes.filter((c) => !targetIds.has(c.time_slot_id));
  const orphans = pending.filter((c) => !byStart.has(hhmm(c.start_time)));
  if (orphans.length) {
    const sample = orphans.slice(0, 4).map((c) => `${c.grade_name} ${c.section_name}: ${c.subject_name} (${dayName(c.day_of_week).toLowerCase()} ${hhmm(c.start_time)})`);
    throw ApiError.conflict(
      `${orphans.length} clase${orphans.length === 1 ? '' : 's'} de ${levelName} ${orphans.length === 1 ? 'está' : 'están'} en horas que no existen en la nueva jornada: ${sample.join('; ')}${orphans.length > 4 ? '…' : ''}. ` +
        'Agrega un bloque que empiece a esa hora o mueve esas clases antes de guardar.'
    );
  }
  for (const c of pending) {
    try {
      await trx('class_schedules').where({ id: c.id }).update({ time_slot_id: byStart.get(hhmm(c.start_time)).id });
    } catch (err) {
      if (err.code === '23P01' || err.code === '23505') {
        throw ApiError.conflict(`No se pudo pasar ${c.subject_name} de ${c.grade_name} ${c.section_name} (${dayName(c.day_of_week).toLowerCase()} ${hhmm(c.start_time)}) a la nueva jornada: ${dbMessage(err)}`);
      }
      throw err;
    }
  }
  return pending.length;
}

// ---------------------------------------------------------------------------
// Disponibilidad de los docentes (migración 050)
// ---------------------------------------------------------------------------

let unavailabilityReady = false;
async function hasUnavailability(trx) {
  if (unavailabilityReady) return true;
  const { rows } = await trx.raw("SELECT to_regclass('teacher_unavailability') IS NOT NULL AS ok");
  unavailabilityReady = rows[0].ok;
  return unavailabilityReady;
}

/**
 * No disponibilidad de esos docentes en el año, con las horas de cada bloque
 * (de cualquier jornada): se compara por horas contra la jornada de cada sección.
 * → [{ staff_id, day_of_week, time_slot_id, reason, start_time, end_time }]
 */
async function unavailabilityInPeriod(trx, tenantId, staffIds, periodId) {
  if (!staffIds.length || !(await hasUnavailability(trx))) return [];
  return (
    await trx('teacher_unavailability as u')
      .join('time_slots as ts', 'ts.id', 'u.time_slot_id')
      .where({ 'u.tenant_id': tenantId, 'ts.school_period_id': periodId })
      .whereIn('u.staff_id', staffIds)
      .select('u.staff_id', 'u.day_of_week', 'u.time_slot_id', 'u.reason', 'ts.start_time', 'ts.end_time')
  ).map(formatSlot);
}

// ---------------------------------------------------------------------------
// Horario de una sección
// ---------------------------------------------------------------------------

async function loadSection(trx, tenantId, sectionId) {
  const section = await trx('sections as sec')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('school_periods as sp', 'sp.id', 'sec.school_period_id')
    .where({ 'sec.id': sectionId, 'sec.tenant_id': tenantId })
    .select('sec.id', 'sec.name', 'sec.grade_id', 'sec.school_period_id', 'g.name as grade_name', 'g.level_code', 'sp.name as school_period_name', 'sp.closed_at as period_closed_at')
    .first();
  if (!section) throw ApiError.notFound('Sección no encontrada.');
  return section;
}

/** Clases con materia, docente y sección (para mostrar y para avisar cruces). */
function entriesQuery(trx, tenantId) {
  return trx('class_schedules as cs')
    .join('subjects as sub', 'sub.id', 'cs.subject_id')
    .join('staff as st', 'st.id', 'cs.staff_id')
    .join('sections as sec', 'sec.id', 'cs.section_id')
    .join('grades as g', 'g.id', 'sec.grade_id')
    .join('time_slots as ts', 'ts.id', 'cs.time_slot_id')
    .where('cs.tenant_id', tenantId)
    .select(
      'cs.id',
      'cs.section_id',
      'cs.subject_id',
      'cs.staff_id',
      'cs.day_of_week',
      'cs.time_slot_id',
      'sub.name as subject_name',
      trx.raw("st.first_name || ' ' || st.last_name AS teacher_name"),
      'sec.name as section_name',
      'g.name as grade_name',
      'ts.start_time',
      'ts.end_time'
    );
}

const formatEntry = (e) => ({ ...e, start_time: hhmm(e.start_time), end_time: hhmm(e.end_time) });

/** Materias del plan de estudios de la sección con su docente según la carga docente. */
async function sectionSubjects(trx, tenantId, sectionId, assignment = null) {
  const a = assignment || (await assignmentService.getSectionAssignments(trx, tenantId, sectionId));
  return (a.subjects || []).map((s) => ({
    subject_id: s.id,
    subject_name: s.name,
    weekly_hours: s.weekly_hours ?? null,
    // Profesor en campos planos (quién la dicta de verdad) y de dónde sale:
    // 'subject' asignado a la materia, 'homeroom' el titular (Primaria), null sin profesor.
    teacher_id: s.effectiveTeacher?.id || null,
    teacher_name: s.effectiveTeacher?.name || null,
    teacher_source: s.teacher ? 'subject' : s.effectiveTeacher ? 'homeroom' : null,
    teacher: s.effectiveTeacher ? { id: s.effectiveTeacher.id, name: s.effectiveTeacher.name } : null,
  }));
}

/**
 * Horario de la sección. `editable`: además el banco de materias (con horas
 * semanales colocadas) y, por docente, las horas en que ya da clase en OTRAS
 * secciones del año (para marcar en rojo las celdas con cruce al arrastrar).
 */
async function getSectionSchedule(trx, tenantId, sectionId, { editable = false } = {}) {
  const section = await loadSection(trx, tenantId, sectionId);
  // Jornada del nivel de la sección (la propia o, si no tiene, la general).
  const slots = await slotsForLevel(trx, tenantId, section.school_period_id, section.level_code);
  section.own_slots = slots.some((s) => s.level_code);
  const entries = (await entriesQuery(trx, tenantId).andWhere('cs.section_id', sectionId)).map(formatEntry);
  const result = { section, days: DAYS, slots, entries, read_only: !editable || Boolean(section.period_closed_at) };
  if (!editable) return result;

  const assignment = await assignmentService.getSectionAssignments(trx, tenantId, sectionId);
  const subjects = await sectionSubjects(trx, tenantId, sectionId, assignment);
  // Cómo se asignan los docentes en la sección (para la asignación rápida desde el panel):
  // 'homeroom' (Primaria: titular que dicta lo que no tiene especialista) o 'subjects' (Secundaria).
  result.assignment = { mode: assignment.mode, lead: assignment.homeroom?.lead || null };
  const teacherOf = new Map(subjects.map((s) => [s.subject_id, s.teacher?.id || null]));
  // Clase cuyo docente ya no coincide con la carga docente actual (se cambió la asignación).
  result.entries = entries.map((e) => ({ ...e, teacher_changed: teacherOf.has(e.subject_id) && teacherOf.get(e.subject_id) !== e.staff_id }));
  result.bank = subjects.map((s) => ({ ...s, placed: entries.filter((e) => e.subject_id === s.subject_id).length }));

  const teacherIds = [...new Set(subjects.map((s) => s.teacher?.id).filter(Boolean))];
  const busy = teacherIds.length
    ? await entriesQuery(trx, tenantId).whereIn('cs.staff_id', teacherIds).whereNot('cs.section_id', sectionId).andWhere('sec.school_period_id', section.school_period_id)
    : [];
  // Ocupación del docente llevada a ESTA jornada: cada clase (o bloque no
  // disponible) de otra sección marca los bloques de la sección que se solapan
  // en el tiempo, aunque sea de otro nivel con otras horas.
  const classSlots = slots.filter((s) => !s.is_break);
  const onThisGrid = (item) => classSlots.filter((s) => overlaps(s, item));
  result.teacher_busy = {};
  busy.map(formatEntry).forEach((e) => {
    onThisGrid(e).forEach((s) =>
      (result.teacher_busy[e.staff_id] ||= []).push({
        day_of_week: e.day_of_week,
        time_slot_id: s.id,
        where: `${e.grade_name} ${e.section_name}`,
        subject_name: `${e.subject_name} (${e.start_time}–${e.end_time})`,
      })
    );
  });
  // Bloques en que el docente no está disponible: también se marcan al arrastrar.
  (await unavailabilityInPeriod(trx, tenantId, teacherIds, section.school_period_id)).forEach((u) => {
    onThisGrid(u).forEach((s) =>
      (result.teacher_busy[u.staff_id] ||= []).push({
        day_of_week: u.day_of_week,
        time_slot_id: s.id,
        where: 'No disponible',
        subject_name: u.reason || `No disponible (${u.start_time}–${u.end_time})`,
        unavailable: true,
      })
    );
  });
  return result;
}

/** Mensaje del cruce: "El profesor X ya dicta clase en 2do Año A a esta misma hora (Matemática, lunes 07:00–07:45)". */
const conflictMessage = (c) =>
  `Conflicto de horario: El profesor ${c.teacher_name} ya dicta clase en ${c.grade_name} ${c.section_name} a esta misma hora (${c.subject_name}, ${dayName(c.day_of_week).toLowerCase()} ${hhmm(c.start_time)}–${hhmm(c.end_time)}).`;

/**
 * Coloca una materia en una celda (o mueve una clase existente si viene
 * `entryId`). Valida: año abierto, bloque del año y no recreo, materia del
 * plan de estudios con docente asignado y SIN cruce del docente.
 *
 * Si la celda ya tiene otra clase de la sección, `onOccupied` decide:
 *   - (sin indicar) → 409 "Esa hora ya tiene…";
 *   - 'replace'     → la clase que estaba se quita y entra la nueva;
 *   - 'swap'        → solo al mover (`entryId`): la que estaba pasa a la celda
 *                     de origen de la que se mueve (intercambio), con las
 *                     mismas validaciones (p. ej. cruce de su profesor).
 * Todo ocurre en la transacción del request: si algo falla, no queda nada a medias.
 * Devuelve la clase guardada y, si hubo, `replaced` / `swapped` (la otra clase).
 */
async function placeEntry(trx, tenantId, sectionId, { subjectId, dayOfWeek, timeSlotId }, { entryId = null, onOccupied = null } = {}) {
  const section = await loadSection(trx, tenantId, sectionId);
  if (section.period_closed_at) throw ApiError.unprocessable(`El año escolar ${section.school_period_name} está finalizado: su horario es de solo lectura.`);
  if (!DAYS.some((d) => d.day === Number(dayOfWeek))) throw ApiError.badRequest('Día inválido (lunes a viernes).', [{ path: 'dayOfWeek', message: 'Día inválido.' }]);

  const slot = await trx('time_slots').where({ id: timeSlotId, tenant_id: tenantId }).first();
  if (!slot || slot.school_period_id !== section.school_period_id) {
    throw ApiError.badRequest('El bloque horario no pertenece al año escolar de la sección.', [{ path: 'timeSlotId', message: 'Bloque inválido.' }]);
  }
  // Solo bloques de la jornada del nivel de la sección.
  const grid = await slotsForLevel(trx, tenantId, section.school_period_id, section.level_code);
  if (!grid.some((s) => s.id === slot.id)) {
    throw ApiError.badRequest(`Ese bloque no es de la jornada de ${section.grade_name}: usa los bloques de su nivel.`, [{ path: 'timeSlotId', message: 'Bloque de otra jornada.' }]);
  }
  if (slot.is_break) throw ApiError.unprocessable(`${slot.name} es un recreo: no admite clases.`, [{ path: 'timeSlotId', message: 'Recreo.' }]);

  const subject = (await sectionSubjects(trx, tenantId, sectionId)).find((s) => s.subject_id === subjectId);
  if (!subject) {
    throw ApiError.unprocessable(`La materia no está en el plan de estudios de ${section.grade_name}.`, [{ path: 'subjectId', message: 'Materia inválida.' }]);
  }
  if (!subject.teacher) {
    throw ApiError.unprocessable(
      `${subject.subject_name} no tiene profesor asignado en ${section.grade_name} ${section.name}: asígnalo en la carga docente antes de ponerla en el horario.`,
      [{ path: 'subjectId', message: 'Sin profesor.' }]
    );
  }

  const where = { 'cs.day_of_week': dayOfWeek, 'cs.time_slot_id': timeSlotId };
  const occupied = await entriesQuery(trx, tenantId).where({ ...where, 'cs.section_id': sectionId }).modify((q) => entryId && q.whereNot('cs.id', entryId)).first();
  const origin = entryId ? await trx('class_schedules').where({ id: entryId, tenant_id: tenantId }).first() : null;
  const action = occupied && (onOccupied === 'replace' || (onOccupied === 'swap' && origin) ? onOccupied : null);
  if (occupied && !action) {
    throw ApiError.conflict(`Esa hora ya tiene ${occupied.subject_name} (${dayName(dayOfWeek)} ${hhmm(slot.start_time)}–${hhmm(slot.end_time)}). Muévela o quítala primero.`, [
      { path: 'cell', message: 'Celda ocupada.' },
    ]);
  }
  // La clase que ocupaba la celda sale (se repone en el origen si es intercambio).
  if (action) await trx('class_schedules').where({ id: occupied.id, tenant_id: tenantId }).delete();
  // Anti-cruce por HORAS (cada nivel puede tener otra jornada): cualquier clase
  // del docente ese día que se solape con este bloque, en cualquier sección.
  const clash = await entriesQuery(trx, tenantId)
    .where({ 'cs.day_of_week': dayOfWeek, 'cs.staff_id': subject.teacher.id })
    .andWhere('ts.start_time', '<', slot.end_time)
    .andWhere('ts.end_time', '>', slot.start_time)
    .modify((q) => entryId && q.whereNot('cs.id', entryId))
    .first();
  if (clash) {
    throw ApiError.conflict(conflictMessage(clash), [{ path: 'teacher', message: 'Cruce de horario del docente.' }]);
  }
  const blocked = (await unavailabilityInPeriod(trx, tenantId, [subject.teacher.id], section.school_period_id)).find(
    (u) => u.day_of_week === Number(dayOfWeek) && overlaps(u, formatSlot(slot))
  );
  if (blocked) {
    const when = `${dayName(dayOfWeek).toLowerCase()} ${hhmm(slot.start_time)}–${hhmm(slot.end_time)}`;
    throw ApiError.conflict(`El profesor ${subject.teacher.name} no está disponible el ${when}${blocked.reason ? ` (${blocked.reason})` : ''}.`, [
      { path: 'teacher', message: 'Docente no disponible.' },
    ]);
  }

  const row = { subject_id: subjectId, staff_id: subject.teacher.id, day_of_week: dayOfWeek, time_slot_id: timeSlotId };
  let id = entryId;
  try {
    if (entryId) await trx('class_schedules').where({ id: entryId, tenant_id: tenantId }).update(row);
    else [{ id }] = await trx('class_schedules').insert({ ...row, tenant_id: tenantId, section_id: sectionId, grade_id: section.grade_id }).returning('id');
  } catch (err) {
    // Otra persona guardó al mismo tiempo: los índices únicos y el anti-cruce por horas (074) lo frenan.
    if (err.code === '23505' || err.code === '23P01') throw ApiError.conflict('Esa hora acaba de ocuparse (o el docente acaba de recibir otra clase a esa hora). Recarga el horario.');
    if (err.code === '23514') throw ApiError.unprocessable(dbMessage(err));
    throw err;
  }

  const saved = formatEntry(await entriesQuery(trx, tenantId).where('cs.id', id).first());
  if (action === 'replace') return { ...saved, replaced: formatEntry(occupied) };
  if (action === 'swap') {
    // La desplazada va a la celda de origen, con todas las validaciones.
    let swapped;
    try {
      swapped = await placeEntry(trx, tenantId, sectionId, { subjectId: occupied.subject_id, dayOfWeek: origin.day_of_week, timeSlotId: origin.time_slot_id });
    } catch (err) {
      if (err instanceof ApiError) throw ApiError.conflict(`No se puede intercambiar con ${occupied.subject_name}: ${err.message}`, err.details);
      throw err;
    }
    return { ...saved, swapped };
  }
  return saved;
}

async function loadEntry(trx, tenantId, entryId) {
  const entry = await trx('class_schedules').where({ id: entryId, tenant_id: tenantId }).first();
  if (!entry) throw ApiError.notFound('Clase no encontrada en el horario.');
  return entry;
}

/** Mueve una clase a otro día/bloque de la misma sección (mismas validaciones). */
async function moveEntry(trx, tenantId, entryId, { dayOfWeek, timeSlotId, onOccupied = null }) {
  const entry = await loadEntry(trx, tenantId, entryId);
  return placeEntry(trx, tenantId, entry.section_id, { subjectId: entry.subject_id, dayOfWeek, timeSlotId }, { entryId, onOccupied });
}

async function removeEntry(trx, tenantId, entryId) {
  const entry = await loadEntry(trx, tenantId, entryId);
  const section = await loadSection(trx, tenantId, entry.section_id);
  if (section.period_closed_at) throw ApiError.unprocessable(`El año escolar ${section.school_period_name} está finalizado: su horario es de solo lectura.`);
  await trx('class_schedules').where({ id: entryId }).delete();
  return { ok: true };
}

/**
 * Vacía el horario de una sección: borra todas sus clases de la semana en una
 * sola sentencia (dentro de la transacción del request: o todas o ninguna).
 * La carga de los docentes se libera sola (se calcula de las clases). No toca
 * los bloques horarios del año ni la asignación de docentes.
 */
async function clearSection(trx, tenantId, sectionId) {
  const section = await loadSection(trx, tenantId, sectionId);
  if (section.period_closed_at) throw ApiError.unprocessable(`El año escolar ${section.school_period_name} está finalizado: su horario es de solo lectura.`);
  const removed = await trx('class_schedules').where({ tenant_id: tenantId, section_id: sectionId }).delete();
  return { removed, section: { id: section.id, name: section.name, grade_name: section.grade_name } };
}

/** Sección de un año escolar (para validar el acceso del docente). */
async function sectionOfEntry(trx, tenantId, entryId) {
  return (await loadEntry(trx, tenantId, entryId)).section_id;
}

// ---------------------------------------------------------------------------
// Consulta filtrada (administración): por grado/sección o por docente
// ---------------------------------------------------------------------------

/**
 * Docentes para el filtro "Ver por docente", de la A a la Z: el personal
 * docente activo y, además, cualquiera que ya tenga clases en el año (aunque
 * hoy esté inactivo, para poder auditarlo). `classes` = horas por semana.
 */
async function listTeachers(trx, tenantId, periodId, { levelCode = null } = {}) {
  await loadPeriod(trx, tenantId, periodId);
  const load = trx('class_schedules as cs')
    .join('sections as sec', 'sec.id', 'cs.section_id')
    .where({ 'cs.tenant_id': tenantId, 'sec.school_period_id': periodId })
    .groupBy('cs.staff_id')
    .select('cs.staff_id', trx.raw('COUNT(*)::int AS classes'), trx.raw('COUNT(DISTINCT cs.section_id)::int AS sections'))
    .as('c');
  const rows = await trx('staff as st')
    .leftJoin(load, 'c.staff_id', 'st.id')
    .where('st.tenant_id', tenantId)
    .modify((q) =>
      levelCode
        ? restrictStaffToLevel(q, trx, levelCode, 'st') // coordinador: docentes de su nivel
        : q.andWhere((w) => w.where({ 'st.staff_type': 'teaching', 'st.status': 'active' }).orWhereNotNull('c.staff_id'))
    )
    .select('st.id', 'st.first_name', 'st.last_name', 'st.status', 'c.classes', 'c.sections')
    .orderBy([{ column: 'st.first_name' }, { column: 'st.last_name' }]);
  return rows.map((r) => ({
    id: r.id,
    name: `${r.first_name} ${r.last_name}`,
    active: r.status === 'active',
    classes: Number(r.classes || 0),
    sections: Number(r.sections || 0),
  }));
}

/**
 * Grados para el selector de Horarios: TODOS los del colegio (no solo los que
 * ya tienen sección), en orden de la jerarquía escolar (Inicial → Primaria →
 * Secundaria y, dentro, su orden), cada uno con sus secciones en el año
 * elegido. Un grado sin secciones aparece igual (con `sections: []`) para que
 * se vea que existe y se le pueda crear una.
 */
async function listGradesForSchedule(trx, tenantId, periodId, { levelCode = null } = {}) {
  await loadPeriod(trx, tenantId, periodId);
  const grades = await trx('grades as g')
    .join('education_levels as el', 'el.code', 'g.level_code')
    .where('g.tenant_id', tenantId)
    .modify((q) => levelCode && q.andWhere('g.level_code', levelCode))
    .select('g.id', 'g.name', 'g.level_code', 'g.sort_order', 'el.name as level_name')
    .orderBy([{ column: 'el.sort_order' }, { column: 'g.sort_order' }, { column: 'g.name' }]);
  const sections = await trx('sections')
    .where({ tenant_id: tenantId, school_period_id: periodId })
    .select('id', 'name', 'grade_id')
    .orderBy('name');
  return grades.map((g) => ({
    ...g,
    sections: sections
      .filter((s) => s.grade_id === g.id)
      .map(({ id, name }) => ({ id, name }))
      .sort((a, b) => a.name.localeCompare(b.name, 'es', { numeric: true })),
  }));
}

/**
 * Resumen para auditar una grilla (sobre todo la de un docente):
 *   - clases por día y total;
 *   - huecos: horas de clase LIBRES entre la primera y la última clase de un
 *     mismo día (tiempo muerto del docente);
 *   - cruces: celdas con más de una clase (la base de datos no lo permite
 *     para un docente, pero se informa por si acaso);
 *   - secciones que atiende, con sus horas.
 */
function summarize(days, slots, entries) {
  const classSlots = slots.filter((s) => !s.is_break);
  const gaps = [];
  const byDay = days.map((d) => {
    const taken = classSlots.map((s) => entries.some((e) => e.day_of_week === d.day && e.time_slot_id === s.id));
    const first = taken.indexOf(true);
    const last = taken.lastIndexOf(true);
    for (let i = first + 1; first >= 0 && i < last; i += 1) {
      if (!taken[i]) gaps.push({ day_of_week: d.day, time_slot_id: classSlots[i].id });
    }
    return { day_of_week: d.day, name: d.name, classes: taken.filter(Boolean).length };
  });

  const cells = new Map();
  entries.forEach((e) => {
    const k = `${e.day_of_week}|${e.time_slot_id}`;
    cells.set(k, (cells.get(k) || 0) + 1);
  });
  const conflicts = [...cells.entries()]
    .filter(([, n]) => n > 1)
    .map(([k]) => {
      const [day, slot] = k.split('|');
      return { day_of_week: Number(day), time_slot_id: slot };
    });

  const sections = new Map();
  entries.forEach((e) => {
    if (!sections.has(e.section_id)) sections.set(e.section_id, { section_id: e.section_id, label: `${e.grade_name} ${e.section_name}`, classes: 0 });
    sections.get(e.section_id).classes += 1;
  });

  return {
    classes: entries.length,
    capacity: classSlots.length * days.length,
    free_days: byDay.filter((d) => !d.classes).map((d) => d.name),
    by_day: byDay,
    gaps,
    conflicts,
    sections: [...sections.values()].sort((a, b) => a.label.localeCompare(b.label, 'es', { numeric: true })),
  };
}

/**
 * Horario filtrado de un año escolar. Filtros opcionales y combinables:
 *   - sectionId: una sección (define el año si no se indica);
 *   - gradeId: todas las secciones de un grado;
 *   - teacherId: todas las clases de un docente, en cualquier sección.
 * Devuelve la grilla (días, bloques, clases), el grado/sección/docente
 * filtrados y un resumen para auditar la carga (huecos, días libres, cruces).
 */
async function querySchedule(trx, tenantId, { schoolPeriodId = null, gradeId = null, sectionId = null, teacherId = null, levelCode = null }) {
  let periodId = schoolPeriodId;
  let section = null;
  if (sectionId) {
    section = await loadSection(trx, tenantId, sectionId);
    if (periodId && periodId !== section.school_period_id) {
      throw ApiError.badRequest('La sección no pertenece a ese año escolar.', [{ path: 'section_id', message: 'Sección de otro año.' }]);
    }
    if (gradeId && gradeId !== section.grade_id) {
      throw ApiError.badRequest('La sección no pertenece a ese grado.', [{ path: 'section_id', message: 'Sección de otro grado.' }]);
    }
    periodId = section.school_period_id;
  }
  if (!periodId) {
    throw ApiError.badRequest('Indica el año escolar (school_period_id) o la sección (section_id).', [{ path: 'school_period_id', message: 'Requerido.' }]);
  }
  const period = await loadPeriod(trx, tenantId, periodId);

  let grade = null;
  if (gradeId) {
    grade = await trx('grades').where({ id: gradeId, tenant_id: tenantId }).select('id', 'name', 'level_code').first();
    if (!grade) throw ApiError.notFound('Grado no encontrado.');
  }
  let teacher = null;
  if (teacherId) {
    const st = await trx('staff').where({ id: teacherId, tenant_id: tenantId }).select('id', 'first_name', 'last_name', 'staff_type', 'status').first();
    if (!st) throw ApiError.notFound('Docente no encontrado.');
    teacher = { id: st.id, name: `${st.first_name} ${st.last_name}`, staff_type: st.staff_type, active: st.status === 'active' };
  }

  const entries = (
    await entriesQuery(trx, tenantId)
      .andWhere('sec.school_period_id', period.id)
      .modify((q) => {
        if (sectionId) q.andWhere('cs.section_id', sectionId);
        if (gradeId) q.andWhere('sec.grade_id', gradeId);
        if (teacherId) q.andWhere('cs.staff_id', teacherId);
        if (levelCode) q.andWhere('g.level_code', levelCode);
      })
      .orderBy([{ column: 'cs.day_of_week' }, { column: 'ts.start_time' }, { column: 'g.name' }, { column: 'sec.name' }])
  ).map(formatEntry);
  // Grilla: la jornada del nivel si la vista es de un solo nivel (sección, grado
  // o filtro de nivel); si mezcla niveles (docente, todo el año), la unión de
  // las jornadas involucradas, con las clases ubicadas en la fila de su hora.
  const singleLevel = section?.level_code || grade?.level_code || levelCode || null;
  const grid = singleLevel
    ? { slots: await slotsForLevel(trx, tenantId, period.id, singleLevel), alias: null }
    : await gridForEntries(trx, tenantId, period.id, entries);
  const slots = grid.slots;
  if (grid.alias) entries.forEach((e) => (e.time_slot_id = grid.alias.get(e.time_slot_id) || e.time_slot_id));

  return {
    school_period: { id: period.id, name: period.name, closed: Boolean(period.closed_at) },
    filters: { school_period_id: period.id, grade_id: gradeId, section_id: sectionId, teacher_id: teacherId },
    grade,
    section,
    teacher,
    days: DAYS,
    slots,
    entries,
    summary: summarize(DAYS, slots, entries),
  };
}

/**
 * Grilla para clases de varios niveles: une las jornadas en uso (las de los
 * niveles de esas clases; sin clases, la general y todas las propias).
 * → { slots, alias } (alias: bloque → fila que lo representa).
 */
async function gridForEntries(trx, tenantId, periodId, entries) {
  const structures = await listStructures(trx, tenantId, periodId);
  const levelNames = Object.fromEntries(structures.levels.map((l) => [l.code, LEVEL_SHORT[l.code] || l.name]));
  let slots;
  if (entries.length) {
    const used = new Set(entries.map((e) => e.time_slot_id));
    const levelsUsed = structures.levels.filter((l) => l.effective.some((s) => used.has(s.id)));
    slots = [...new Map(levelsUsed.flatMap((l) => l.effective).map((s) => [s.id, s])).values()];
  } else {
    const own = structures.levels.filter((l) => l.own).flatMap((l) => l.slots);
    slots = [...structures.general, ...own];
  }
  return mergeSlots(slots, levelNames);
}
const LEVEL_SHORT = { initial: 'Inicial', primary: 'Primaria', secondary: 'Secundaria' };

/** "3er Año · Sección A" → "3er-ano-seccion-a" (nombre de archivo sin acentos ni espacios). */
const slugify = (s) =>
  String(s)
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);

/**
 * PDF del horario que se está viendo: por sección (materia + profesor en cada
 * clase) o por docente (sección + materia, con sus huecos marcados). Lleva el
 * logo del colegio (o el de MoDo Educa si no tiene) y sus colores.
 * Devuelve { buffer, fileName }.
 */
async function schedulePdf(trx, tenantId, filters) {
  if (!filters.sectionId && !filters.teacherId && !filters.gradeId) {
    throw ApiError.badRequest('Elige una sección o un docente para descargar su horario.', [{ path: 'section_id', message: 'Requerido.' }]);
  }
  const data = await querySchedule(trx, tenantId, filters);
  const tenant = await trx('tenants').where({ id: tenantId }).first();
  const settings = await trx('tenant_settings').where({ tenant_id: tenantId }).first();

  const byTeacher = Boolean(data.teacher);
  const s = data.summary;
  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  let kicker;
  let title;
  let subtitle = '';
  let summary;
  if (byTeacher) {
    kicker = 'Horario del docente';
    title = data.section ? `${data.teacher.name} · ${data.section.grade_name} ${data.section.name}` : data.teacher.name;
    subtitle = s.sections.length ? `Secciones: ${s.sections.map((x) => x.label).join(' · ')}` : '';
    summary = [
      plural(s.classes, 'hora de clase por semana', 'horas de clase por semana'),
      plural(s.sections.length, 'sección', 'secciones'),
      plural(s.gaps.length, 'hueco', 'huecos'),
      s.free_days.length ? `sin clases: ${s.free_days.join(', ').toLowerCase()}` : null,
    ]
      .filter(Boolean)
      .join('  ·  ');
  } else if (data.section) {
    kicker = 'Horario de clases';
    title = `${data.section.grade_name} · Sección ${data.section.name}`;
    const subjects = new Set(data.entries.map((e) => e.subject_id)).size;
    summary = `${plural(s.classes, 'hora de clase por semana', 'horas de clase por semana')}  ·  ${plural(subjects, 'materia', 'materias')}`;
  } else {
    kicker = 'Horario de clases';
    title = data.grade.name;
    subtitle = s.sections.length ? `Secciones: ${s.sections.map((x) => x.label).join(' · ')}` : '';
    summary = plural(s.classes, 'hora de clase por semana', 'horas de clase por semana');
  }

  const buffer = await generateSchedulePdf({
    tenant: {
      name: tenant.name,
      logoPath: resolveLogoFileOrDefault(settings?.logo_url), // sin logo propio: el de MoDo Educa
      primaryColor: settings?.primary_color,
      secondaryColor: settings?.secondary_color,
    },
    kicker,
    title,
    subtitle,
    periodName: data.school_period.name,
    days: data.days,
    slots: data.slots,
    entries: data.entries,
    // Por docente: qué sección y qué materia; por sección: materia y profesor
    // (si se ve un grado completo, también la sección).
    entryText: byTeacher
      ? (e) => ({ title: `${e.grade_name} ${e.section_name}`, sub: e.subject_name })
      : data.section
        ? (e) => ({ title: e.subject_name, sub: e.teacher_name })
        : (e) => ({ title: `${e.subject_name} (${e.section_name})`, sub: e.teacher_name }),
    colorKey: byTeacher ? (e) => e.section_id : (e) => e.subject_id,
    gapKeys: byTeacher ? new Set(s.gaps.map((g) => `${g.day_of_week}|${g.time_slot_id}`)) : new Set(),
    summary,
  });
  const fileName = `horario-${slugify(byTeacher ? data.teacher.name : title)}-${slugify(data.school_period.name)}.pdf`;
  return { buffer, fileName };
}

/** PDF del calendario de evaluaciones de una sección (y período). Devuelve { buffer, fileName }. */
async function evaluationCalendarPdf(trx, tenantId, { sectionId, termNumber }) {
  const cal = await evaluationCalendar.getEvaluationCalendar(trx, tenantId, { sectionId, termNumber });
  const tenant = await trx('tenants').where({ id: tenantId }).first();
  const settings = await trx('tenant_settings').where({ tenant_id: tenantId }).first();
  const s = cal.summary;
  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  const buffer = await generateEvaluationCalendarPdf({
    tenant: {
      name: tenant.name,
      logoPath: resolveLogoFileOrDefault(settings?.logo_url),
      primaryColor: settings?.primary_color,
      secondaryColor: settings?.secondary_color,
    },
    title: `${cal.section.grade_name} · Sección ${cal.section.name}`,
    subtitle: [cal.term ? cal.term.name : 'Todos los períodos', s.undated ? `${plural(s.undated, 'evaluación', 'evaluaciones')} sin fecha (no ${s.undated === 1 ? 'aparece' : 'aparecen'})` : null].filter(Boolean).join('  ·  '),
    periodName: cal.school_period.name,
    termName: cal.term ? cal.term.name : null,
    from: s.from,
    to: s.to,
    evaluations: cal.evaluations.filter((e) => !e.weekend),
    overloadedDates: new Set(s.overloaded_days),
    summary: [plural(s.scheduled, 'evaluación programada', 'evaluaciones programadas'), plural(s.heavy, 'de ponderación alta', 'de ponderación alta'), s.overloaded_days.length ? plural(s.overloaded_days.length, 'día cargado', 'días cargados') : 'sin días cargados'].join('  ·  '),
  });
  const term = cal.term ? `-periodo-${cal.term.term_number}` : '';
  return { buffer, fileName: `evaluaciones-${slugify(`${cal.section.grade_name} ${cal.section.name}`)}${term}-${slugify(cal.school_period.name)}.pdf` };
}

// ---------------------------------------------------------------------------
// Consultas de solo lectura: docente y representante
// ---------------------------------------------------------------------------

/**
 * "Mi horario" del docente: sus clases de la semana en los años escolares
 * activos (todas sus secciones), con los bloques de ese año.
 */
async function getTeacherSchedule(trx, tenantId, staffId) {
  const periods = await trx('school_periods').where({ tenant_id: tenantId, is_active: true }).whereNull('closed_at').orderBy('start_date', 'desc');
  const out = [];
  for (const p of periods) {
    const entries = (await entriesQuery(trx, tenantId).where('cs.staff_id', staffId).andWhere('sec.school_period_id', p.id)).map(formatEntry);
    if (!entries.length) continue;
    // Puede dar clase en niveles con jornadas distintas: una grilla con todas sus horas.
    const grid = await gridForEntries(trx, tenantId, p.id, entries);
    entries.forEach((e) => (e.time_slot_id = grid.alias.get(e.time_slot_id) || e.time_slot_id));
    out.push({ school_period: { id: p.id, name: p.name }, days: DAYS, slots: grid.slots, entries });
  }
  return { staff_id: staffId, periods: out };
}

/** Horario de la sección en que el alumno cursa (inscripción activa del año en curso). */
async function getStudentSchedule(trx, tenantId, studentId) {
  const enrollment = await trx('enrollments as e')
    .join('sections as sec', 'sec.id', 'e.section_id')
    .join('school_periods as sp', 'sp.id', 'sec.school_period_id')
    .where({ 'e.tenant_id': tenantId, 'e.student_id': studentId, 'e.status': 'active' })
    .orderByRaw(currentPeriodOrder('sp'))
    .select('e.section_id')
    .first();
  if (!enrollment) return { section: null, days: DAYS, slots: [], entries: [], read_only: true };
  return getSectionSchedule(trx, tenantId, enrollment.section_id);
}

module.exports = {
  DAYS,
  listSlots,
  saveSlots,
  loadPeriod,
  getSectionSchedule,
  placeEntry,
  moveEntry,
  removeEntry, clearSection,
  sectionOfEntry,
  getTeacherSchedule,
  getStudentSchedule,
  listTeachers,
  listGradesForSchedule,
  querySchedule,
  schedulePdf,
  evaluationCalendarPdf,
  summarize,
  slotsForLevel,
  listStructures,
  mergeSlots,
  overlaps,
  unavailabilityInPeriod,
};

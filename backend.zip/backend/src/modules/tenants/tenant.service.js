const { ApiError } = require('../../utils/ApiError');
const { getPortalViews } = require('./portalViews.service');
const { toPublicUrl } = require('../../services/storage/logoStorage');
const { GRADING_SCALES, scaleDefinition } = require('../grading/gradingScale');

async function getSettings(trx, tenantId) {
  const tenant = await trx('tenants').where({ id: tenantId }).first();
  if (!tenant) throw ApiError.notFound('Colegio no encontrado.');

  const settings = await trx('tenant_settings').where({ tenant_id: tenantId }).first();

  return {
    id: tenant.id,
    name: tenant.name,
    slug: tenant.slug,
    status: tenant.status,
    // En BD se guarda la ruta relativa (logos/<tenant>/<archivo>); al cliente se le da la URL servible.
    logoUrl: toPublicUrl(settings?.logo_url),
    primaryColor: settings?.primary_color || '#2563EB',
    secondaryColor: settings?.secondary_color || '#1E293B',
    // Apariencia avanzada (migración 021): el resto de los tonos se derivan en el frontend.
    menuGradient: settings?.menu_gradient || 'deep',
    accentSecondaryColor: settings?.accent2_color || null,
    tableHeaderStyle: settings?.table_header_style || 'subtle',
    contactPhone: settings?.contact_phone || null,
    contactEmail: settings?.contact_email || null,
    rif: settings?.rif || null,
    // Dirección física (migración 079): membrete de los documentos oficiales.
    address: settings?.address || null,
    // Secciones del portal del representante ({ payments: true, … }; migración 066).
    portalViews: await getPortalViews(trx, tenantId),
  };
}

/**
 * Columnas de apariencia agregadas por la migración 021. Si la base aún no
 * la tiene aplicada, se omiten al guardar (con un aviso en la consola) en
 * lugar de romper TODO el guardado con un 500: nombre, colores, logo y
 * contacto viven en columnas que existen desde la 001.
 */
const OPTIONAL_COLUMNS = ['menu_gradient', 'accent2_color', 'table_header_style', 'rif', 'address'];
let settingsColumnsCache = null;

async function settingsColumns(trx) {
  // Se cachea solo cuando ya están todas: si falta alguna se vuelve a mirar,
  // así basta con correr la migración (sin reiniciar el servidor).
  if (settingsColumnsCache) return settingsColumnsCache;
  const names = await trx('information_schema.columns')
    .where({ table_name: 'tenant_settings' })
    .whereRaw('table_schema = current_schema()')
    .pluck('column_name');
  const columns = new Set(names);
  if (OPTIONAL_COLUMNS.every((c) => columns.has(c))) settingsColumnsCache = columns;
  return columns;
}

/**
 * Actualiza la configuración del colegio. `logoPath` es la ruta relativa de un
 * logo recién guardado en disco; `removeLogo` lo quita sin reemplazarlo.
 * Devuelve `replacedLogo` (la ruta anterior) para que el controlador borre el
 * archivo viejo una vez confirmada la transacción.
 */
async function updateSettings(
  trx,
  tenantId,
  { name, logoPath, removeLogo, primaryColor, secondaryColor, menuGradient, accentSecondaryColor, tableHeaderStyle, contactPhone, contactEmail, rif, address }
) {
  if (name) {
    await trx('tenants').where({ id: tenantId }).update({ name, updated_at: trx.fn.now() });
  }

  const existing = await trx('tenant_settings').where({ tenant_id: tenantId }).first();

  let logoValue;
  if (logoPath) logoValue = logoPath;
  else if (removeLogo) logoValue = null;

  const payload = {
    logo_url: logoValue,
    primary_color: primaryColor,
    secondary_color: secondaryColor,
    menu_gradient: menuGradient,
    // 'auto' vuelve al acento secundario automático (NULL).
    accent2_color: accentSecondaryColor === 'auto' ? null : accentSecondaryColor,
    table_header_style: tableHeaderStyle,
    contact_phone: contactPhone,
    contact_email: contactEmail,
    rif,
    address,
    updated_at: trx.fn.now(),
  };
  // Solo pisa las columnas que vinieron en el request (permite updates parciales).
  Object.keys(payload).forEach((key) => payload[key] === undefined && delete payload[key]);

  // Columnas opcionales que la base todavía no tiene (migración 021 pendiente).
  const requested = OPTIONAL_COLUMNS.filter((c) => c in payload);
  if (requested.length) {
    const columns = await settingsColumns(trx);
    const missing = requested.filter((c) => !columns.has(c));
    if (missing.length) {
      missing.forEach((c) => delete payload[c]);
      // eslint-disable-next-line no-console
      console.warn(`[tenant_settings] Faltan las columnas ${missing.join(', ')} (migraciones 021/044 pendientes: ejecuta "npm run migrate"). Se guardó el resto.`);
    }
  }

  if (existing) {
    await trx('tenant_settings').where({ tenant_id: tenantId }).update(payload);
  } else {
    await trx('tenant_settings').insert({ tenant_id: tenantId, ...payload });
  }

  const replacedLogo = logoValue !== undefined && existing?.logo_url !== logoValue ? existing?.logo_url || null : null;

  return { settings: await getSettings(trx, tenantId), replacedLogo };
}

/**
 * Perfil del colegio para CUALQUIER usuario con sesión (docentes, familias…):
 * nombre, logo, apariencia y datos de contacto. Sin datos administrativos
 * (id, estado). Es lo que necesitan el diseño y el pie de página del inicio.
 */
async function getProfile(trx, tenantId) {
  const { name, logoUrl, primaryColor, secondaryColor, menuGradient, accentSecondaryColor, tableHeaderStyle, contactPhone, contactEmail, rif, address, portalViews } =
    await getSettings(trx, tenantId);
  return { name, logoUrl, primaryColor, secondaryColor, menuGradient, accentSecondaryColor, tableHeaderStyle, contactPhone, contactEmail, rif, address, portalViews };
}



// ---------------------------------------------------------------------------
// Escalas de calificación por grado (migración 023)
// ---------------------------------------------------------------------------



/** Todos los grados (jerarquía escolar) con su escala, más la definición de las escalas. */
async function listGradingScales(trx, tenantId) {
  const grades = await trx('grades as g')
    .join('education_levels as el', 'el.code', 'g.level_code')
    .where('g.tenant_id', tenantId)
    .select('g.id', 'g.name', 'g.level_code', 'el.name as level_name', 'g.grading_scale')
    .orderBy([{ column: 'el.sort_order' }, { column: 'g.sort_order' }, { column: 'g.name' }]);
  return { grades, scales: GRADING_SCALES, ...scaleDefinition() };
}

/** Cambia la escala de uno o varios grados: [{ gradeId, gradingScale }]. */
async function setGradingScales(trx, tenantId, list) {
  const ids = [...new Set(list.map((x) => x.gradeId))];
  const found = await trx('grades').where({ tenant_id: tenantId }).whereIn('id', ids).pluck('id');
  if (found.length !== ids.length) throw ApiError.badRequest('Hay grados que no existen en el colegio.', [{ path: 'grades', message: 'Grado inválido.' }]);
  for (const { gradeId, gradingScale } of list) {
    await trx('grades').where({ id: gradeId, tenant_id: tenantId }).update({ grading_scale: gradingScale });
  }
  return listGradingScales(trx, tenantId);
}

module.exports = { getSettings, getProfile, updateSettings, listGradingScales, setGradingScales };

import { axiosClient } from '../axiosClient';
import { registerCurrencies } from '../../features/payments/currency';
import { fileNameFrom, saveBlob, unwrapBlobError } from './imports.api';

const get = (url, params) => axiosClient.get(url, { params }).then((r) => r.data);
const post = (url, data) => axiosClient.post(url, data).then((r) => r.data);

/**
 * Con archivo adjunto: multipart/form-data (campos + `proof`); sin archivo: JSON.
 * Hay que pisar el Content-Type JSON por defecto del cliente: si no, axios
 * serializa el FormData a JSON y el archivo se pierde.
 */
function postWithProof(url, data, file) {
  if (!file) return post(url, data || {});
  const form = new FormData();
  Object.entries(data || {}).forEach(([k, v]) => v !== undefined && v !== null && form.append(k, v));
  form.append('proof', file);
  return axiosClient.post(url, form, { headers: { 'Content-Type': 'multipart/form-data' } }).then((r) => r.data);
}

const paymentsApi = {
  /**
   * `status`: "due" (pendiente + vencido + reportado) o estados separados por coma.
   * `currency`: moneda de referencia en que se estiman los pendientes (columnas conv_*).
   */
  list: (params) => get('/payments', params),
  /**
   * Descarga el Excel con los filtros de la pantalla: { status, schoolPeriodId, q }.
   * Devuelve { fileName, count }.
   */
  exportExcel: async (params) => {
    const res = await axiosClient.get('/payments/export', { params, responseType: 'blob' }).catch(unwrapBlobError);
    const fileName = fileNameFrom(res.headers, 'reporte_pagos_filtrados.xlsx');
    saveBlob(res.data, fileName);
    return { fileName, count: Number(res.headers?.['x-export-count'] ?? 0) };
  },
  // Datos de otros módulos para los formularios, bajo el permiso de Pagos (rol Finanzas).
  schoolPeriodOptions: () => get('/payments/options/school-periods'),
  studentOptions: () => get('/payments/options/students'),
  studentGuardianOptions: (studentId) => get(`/payments/options/students/${studentId}/guardians`),
  /** Totales por estado + `total_ref` en `currency` (o la predeterminada). */
  summary: (params) => get('/payments/summary', params),
  listMine: (params) => get('/payments/mine', params),
  /** Cotización exacta de un pago: { currency: 'COP', date: 'YYYY-MM-DD' } → { amount, rate, rate_date, … }. */
  quote: (id, params) => get(`/payments/${id}/quote`, params),
  getOne: (id) => get(`/payments/${id}`),
  register: (data) => post('/payments', data),
  /** Registra el pago (administración). `details` opcional: { method, reference, paidOn, note, currency }. */
  markAsPaid: (id, details, proofFile) => postWithProof(`/payments/${id}/mark-paid`, details, proofFile),
  cancel: (id) => post(`/payments/${id}/cancel`),
  /** Vuelve a generar el PDF del comprobante de un pago confirmado (diseño/logo actuales). */
  regenerateReceipt: (id) => post(`/payments/${id}/receipt`),
  /** Representante: informa que ya pagó ({ method, reference, paidOn, note, currency }). */
  report: (id, data, proofFile) => postWithProof(`/payments/${id}/report`, data, proofFile),
  // ---- Pagos agrupados (varias cuotas, un comprobante) ----
  /** Familia: total de varias cuotas en una moneda y fecha: { paymentIds, currency, date } → { base_total, amount, rate, items, … } */
  batchQuote: (data) => post('/payments/batches/quote', data),
  /** Familia: reporta un pago por varias cuotas: { paymentIds, method, reference, paidOn, note, currency } + comprobante */
  createBatch: (data, proofFile) => postWithProof('/payments/batches', { ...data, paymentIds: JSON.stringify(data.paymentIds) }, proofFile),
  myBatches: () => get('/payments/batches/mine'),
  withdrawBatch: (id) => post(`/payments/batches/${id}/withdraw`),
  /** Administración: status 'reported' (por revisar) | 'approved' | 'rejected' | 'withdrawn' | 'all' */
  listBatches: (status = 'reported') => get('/payments/batches', { status }),
  getBatch: (id) => get(`/payments/batches/${id}`),
  /** Aprueba todas sus cuotas. `details` opcional: { method, reference, paidOn, note, currency } → { batch, solvency, emailSent, … } */
  approveBatch: (id, details = {}) => post(`/payments/batches/${id}/approve`, details),
  rejectBatch: (id, reason) => post(`/payments/batches/${id}/reject`, { reason }),
  getBatchProofBlob: (id) => axiosClient.get(`/payments/batches/${id}/proof`, { responseType: 'blob' }).then((r) => r.data),

  /** Comprobante adjunto (privado): se descarga con la sesión del usuario como Blob. */
  getProofBlob: (id) => axiosClient.get(`/payments/${id}/proof`, { responseType: 'blob' }).then((r) => r.data),
  /** Recibo PDF (privado): se descarga con la sesión del usuario como Blob. */
  getReceiptBlob: (id) => axiosClient.get(`/payments/${id}/receipt`, { responseType: 'blob' }).then((r) => r.data),

  listFees: (schoolPeriodId) => get('/payments/tuition/fees', { schoolPeriodId }),
  upsertFee: (data) => axiosClient.put('/payments/tuition/fees', data).then((r) => r.data),
  deleteFee: (id) => axiosClient.delete(`/payments/tuition/fees/${id}`).then((r) => r.data),
  generateTuition: (schoolPeriodId) => post('/payments/tuition/generate', { schoolPeriodId }),
  /** Agosto del año escolar: { charge_month, charge_label, configured, options: [{ value, label }], generated, august_label } */
  augustStatus: (schoolPeriodId) => get('/payments/tuition/august', { schoolPeriodId }),
  /** Con qué mes regular se cobra agosto: chargeMonth 'YYYY-MM-01' → estado + { created, rescheduled } */
  setAugust: (schoolPeriodId, chargeMonth) => axiosClient.put('/payments/tuition/august', { schoolPeriodId, chargeMonth }).then((r) => r.data),
  // ---- Tarifas especiales (becas, convenios) ----
  /** [{ id, name, kind: 'percentage'|'fixed', percentage, amount, description, student_count }] */
  listFeePlans: () => get('/payments/fee-plans'),
  /** { name, kind, percentage?, amount?, description? } */
  createFeePlan: (data) => post('/payments/fee-plans', data),
  /** → { plan, recalculated: null | { students, updated, cancelled, reactivated } } */
  updateFeePlan: (id, data) => axiosClient.put(`/payments/fee-plans/${id}`, data).then((r) => r.data),
  deleteFeePlan: (id) => axiosClient.delete(`/payments/fee-plans/${id}`).then((r) => r.data),
  /** Mensualidad vigente del alumno: { plan, plan_label, note, enrollment, base, effective_amount, upcoming_months } */
  studentFee: (studentId) => get(`/payments/students/${studentId}/fee`),
  /** { feePlanId: uuid | null (tarifa general del nivel), note } → { fee, applied: { updated, cancelled, created, reactivated } } */
  assignStudentFeePlan: (studentId, data) => axiosClient.put(`/payments/students/${studentId}/fee-plan`, data).then((r) => r.data),
  /** Acuerdo de pago: { graceDays: 1–60 | null (plazo estándar), note } → { fee, updated } */
  setPaymentAgreement: (studentId, data) => axiosClient.put(`/payments/students/${studentId}/payment-agreement`, data).then((r) => r.data),

  /** Catálogo de monedas + activas del colegio ({ base, default_currency, catalog: [{ code, name, enabled, … }] }). */
  listCurrencies: () => get('/payments/currencies'),
  /** { currencies: ['VES', 'COP'], defaultCurrency: 'VES' } */
  setCurrencies: (data) => axiosClient.put('/payments/currencies', data).then((r) => r.data),
  /**
   * Tasas vigentes de cada moneda activa (cualquier usuario con sesión):
   * { today, default_currency, currencies: [{ code, name, current, next, stale, … }] }.
   */
  currentRate: () =>
    get('/payments/exchange-rates/current').then((status) => {
      registerCurrencies(status.currencies); // nombres/símbolos del colegio para formatear montos
      return status;
    }),

  // ---- Administración de monedas del colegio ----
  /** { currencies: [configuradas, activas e inactivas, con tasa], available: [catálogo sin configurar], default_currency } */
  currencyAdmin: () =>
    get('/payments/currencies/admin').then((data) => {
      registerCurrencies(data.currencies);
      return data;
    }),
  /** { code, name?, symbol?, decimals?, isActive?, isDefault? } */
  addCurrency: (data) => post('/payments/currencies', data),
  /** Editar / activar / desactivar / marcar predeterminada. */
  updateCurrency: (code, data) => axiosClient.put(`/payments/currencies/${code}`, data).then((r) => r.data),
  /** Solo si nunca se usó (sin tasas ni pagos); si no, hay que desactivarla. */
  /** Qué se borraría: { currency, rates, payments: { total, in_currency, paid_with_currency, by_status, proofs, receipts }, needs_confirmation, blocked_reason } */
  currencyDeletionImpact: (code) => get(`/payments/currencies/${code}/deletion-impact`),
  /** Elimina la moneda JUNTO con sus pagos y tasas. confirmCode: el código (obligatorio si tiene registros). */
  removeCurrency: (code, confirmCode) => axiosClient.delete(`/payments/currencies/${code}`, { data: confirmCode ? { confirmCode } : {} }).then((r) => r.data),
  /** Historial de cambios de la tasa: `{ from?, to? }` por fecha valor → { current, items: [{ action, rate_date, rate, previous_rate, change_pct, source, changed_by_name, changed_at, is_current, is_scheduled }] }. */
  rateHistory: (code, { from, to } = {}) => get(`/payments/currencies/${code}/rate-history`, { from: from || undefined, to: to || undefined }),
  listRates: (currency) => get('/payments/exchange-rates', currency ? { currency } : undefined),
  /** { currency, rateDate: 'YYYY-MM-DD' (fecha valor), rate: moneda local por 1 USD } */
  upsertRate: (data) => axiosClient.put('/payments/exchange-rates', data).then((r) => r.data),
  /**
   * «Actualizar tasa ahora»: consulta la tasa oficial del BCV (o su respaldo) y la guarda con su fecha valor.
   * → { fetched: { rate, rate_date, source: 'bcv' | 'bcv_api' }, …estado de tasas, sync }
   */
  syncBcvRate: () => post('/exchange-rate/sync'),
  fetchBcvRate: () => post('/exchange-rate/sync'),
  /** Prueba de la campana: aviso de una tasa simulada (NO se registra). { rate?, audience?: 'all' | 'staff' } → { notification, rate, recipients } */
  simulateBcvRate: (data) => post('/exchange-rate/simulate', data),
  clearBcvSimulations: () => axiosClient.delete('/exchange-rate/simulate').then((r) => r.data),
  deleteRate: (id) => axiosClient.delete(`/payments/exchange-rates/${id}`).then((r) => r.data),
};

export default paymentsApi;

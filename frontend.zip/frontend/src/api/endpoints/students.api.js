import { axiosClient } from '../axiosClient';

const studentsApi = {
  /** `params.enrollmentPeriodId`: año del estatus «Inscrito / No inscrito» (por defecto, el vigente). */
  list: (params) => axiosClient.get('/students', { params }).then((r) => r.data),
  getOne: (id) => axiosClient.get(`/students/${id}`).then((r) => r.data),
  /** Años cursados: grado, sección, resultado (promovido, repite…), promedio y boleta por materia. */
  academicHistory: (id) => axiosClient.get(`/students/${id}/academic-history`).then((r) => r.data),
  create: (data) => axiosClient.post('/students', data).then((r) => r.data),
  update: (id, data) => axiosClient.put(`/students/${id}`, data).then((r) => r.data),
  /** Retiro lógico: { withdrawnOn?, reason? } → { closed_enrollments, cancelled_tuition, left_clubs } */
  withdraw: (id, data) => axiosClient.post(`/students/${id}/withdraw`, data).then((r) => r.data),
  /** → { restored[], not_restored[{ reason }], restored_tuition } */
  reactivate: (id) => axiosClient.post(`/students/${id}/reactivate`).then((r) => r.data),
  linkGuardian: (id, data) => axiosClient.post(`/students/${id}/guardians`, data).then((r) => r.data),
  unlinkGuardian: (id, guardianId) =>
    axiosClient.delete(`/students/${id}/guardians/${guardianId}`).then((r) => r.data),

  listGuardians: () => axiosClient.get('/guardians').then((r) => r.data),
  getGuardian: (id) => axiosClient.get(`/guardians/${id}`).then((r) => r.data),
  createGuardian: (data) => axiosClient.post('/guardians', data).then((r) => r.data),
  updateGuardian: (id, data) => axiosClient.put(`/guardians/${id}`, data).then((r) => r.data),
  /** Solo el acceso al portal: crear { email?, password? } o gestionar { email?, resetPassword?, password?, status? } → { portal, temporaryPassword } */
  updateGuardianPortal: (id, data) => axiosClient.put(`/guardians/${id}/portal`, data).then((r) => r.data),
  deleteGuardian: (id) => axiosClient.delete(`/guardians/${id}`).then((r) => r.data),
};

export default studentsApi;

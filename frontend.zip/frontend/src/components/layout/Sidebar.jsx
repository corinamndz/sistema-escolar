import { useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import Icon from '../ui/Icon';
import SchoolLogo from '../ui/SchoolLogo';
import { NAV_SECTIONS, isNavItemVisible, navItemLabel } from './navigation';
import { initials } from './initials';
import { useExpandedSet } from '../../hooks/useExpandedSet';
import { useReviewCounts } from '../../features/reviews/useReviewCounts';

// Rutas que solo se marcan activas si coinciden exactamente (igual que `end` en NavLink).
const EXACT_PATHS = new Set(['/', '/payments', '/schedules']);
const isActivePath = (path, pathname) => (EXACT_PATHS.has(path) ? pathname === path : pathname === path || pathname.startsWith(`${path}/`));

function Sidebar({ collapsed, mobileOpen, onCloseMobile, onToggleCollapsed }) {
  const { can, user } = useAuth();
  const { settings } = useTenant();
  // Coordinador / Director: cuántos planes y contenidos esperan su revisión.
  const reviewCounts = useReviewCounts({ can, user });

  // En el drawer móvil siempre se muestran las etiquetas, aunque en desktop esté colapsado.
  const compact = collapsed && !mobileOpen;

  const sections = NAV_SECTIONS.map((section) => ({
    ...section,
    items: section.items
      .filter((item) => isNavItemVisible(item, { can, user, portalViews: settings.portalViews }))
      .map((item) => ({ ...item, label: navItemLabel(item, user) }))
      // `sortAlphabetically`: la sección se lista por orden alfabético del nombre visible (ej. Administración).
      .sort((a, b) => (section.sortAlphabetically ? a.label.localeCompare(b.label, 'es', { sensitivity: 'base' }) : 0)),
  })).filter((section) => section.items.length > 0);

  const displayName = user?.fullName || user?.username;

  // Grupos del menú CERRADOS al entrar (no se recuerdan entre recargas: el menú
  // arranca siempre limpio).
  // El grupo de la página actual se abre al llegar a ella (si no, no se vería
  // dónde estás); después se puede cerrar igual que los demás.
  const location = useLocation();
  const { isOpen: isSectionOpen, toggle: toggleSection, open: openSection } = useExpandedSet();
  const activeSection = sections.find((section) => section.items.some((item) => isActivePath(item.path, location.pathname)))?.label;
  // Opción activa: la coincidencia MÁS específica (en /academics/subjects se marca
  // "Materias", no también otra opción cuya ruta sea un prefijo).
  const activePath = sections
    .flatMap((section) => section.items.map((item) => item.path))
    .filter((path) => isActivePath(path, location.pathname))
    .sort((a, b) => b.length - a.length)[0];
  useEffect(() => {
    if (activeSection) openSection(activeSection);
  }, [activeSection, openSection]);

  return (
    <aside
      className={['sidebar', compact ? 'sidebar--collapsed' : '', mobileOpen ? 'sidebar--mobile-open' : '']
        .filter(Boolean)
        .join(' ')}
      aria-label="Menú principal"
    >
      <div className={`sidebar__brand${compact ? '' : ' sidebar__brand--hero'}`}>
        {/* Logo del colegio (Configuración → Apariencia), transparente sobre el menú; sin logo
            propio (o si no carga), el de MoDo Educa para fondo oscuro. Con el menú en íconos, la versión compacta. */}
        <SchoolLogo
          src={settings.logoUrl}
          name={settings.name}
          variant={compact ? 'compact' : 'full'}
          tone="dark"
          className={compact ? 'sidebar__logo' : 'sidebar__hero-logo'}
        />

        {!compact && (
          <div className="sidebar__brand-text">
            <span className="sidebar__school-name" title={settings.name}>
              {settings.name}
            </span>
            <span className="sidebar__school-sub">Panel de gestión</span>
          </div>
        )}
        <button type="button" className="sidebar__close" onClick={onCloseMobile} aria-label="Cerrar menú">
          <Icon name="x" size={18} />
        </button>
      </div>

      <nav className="sidebar__nav">
        {sections.map((section) => {
          // Con el menú en modo íconos no se colapsan grupos: todos los íconos a la vista.
          const open = compact || isSectionOpen(section.label);
          const bodyId = `sidebar-section-${section.label.replace(/\s+/g, '-').toLowerCase()}`;
          const hasActive = section.items.some((item) => isActivePath(item.path, location.pathname));
          return (
            <div key={section.label} className={`sidebar__section ${open ? 'is-open' : 'is-closed'}`}>
              {compact ? (
                <div className="sidebar__section-label">{section.label}</div>
              ) : (
                <button
                  type="button"
                  className="sidebar__section-label sidebar__section-toggle"
                  onClick={() => toggleSection(section.label)}
                  aria-expanded={open}
                  aria-controls={bodyId}
                >
                  <span>{section.label}</span>
                  {/* Grupo contraído que contiene la página actual: punto indicador. */}
                  {!open && hasActive && <span className="sidebar__section-dot" aria-label="Contiene la página actual" />}
                  <Icon name="chevronDown" size={14} className="sidebar__section-chevron" />
                </button>
              )}
              {/* grid-template-rows 0fr ↔ 1fr: altura animada sin medir el contenido. */}
              <div id={bodyId} className="sidebar__section-body" aria-hidden={!open} {...(open ? {} : { inert: '' })}>
                <div className="sidebar__section-items">
                  {section.items.map((item) => (
                    <NavLink
                      // La ruta es única; el módulo no (Pagos y Monedas y tasas comparten "payments").
                      key={item.path}
                      to={item.path}
                      end={EXACT_PATHS.has(item.path) || (activePath !== item.path && Boolean(activePath?.startsWith(`${item.path}/`)))}
                      className={({ isActive }) => `sidebar__link ${isActive ? 'sidebar__link--active' : ''}`}
                      onClick={onCloseMobile}
                      data-tooltip={compact ? item.label : undefined}
                      aria-label={compact ? item.label : undefined}
                    >
                      <span className="sidebar__icon">
                        <Icon name={item.icon} size={19} />
                        {compact && item.reviewBadge && reviewCounts[item.reviewBadge] > 0 && <span className="sidebar__dot" aria-hidden="true" />}
                      </span>
                      {!compact && <span className="sidebar__label">{item.label}</span>}
                      {!compact && item.reviewBadge && reviewCounts[item.reviewBadge] > 0 && (
                        <span className="sidebar__badge" title={`${reviewCounts[item.reviewBadge]} por revisar`} aria-label={`${reviewCounts[item.reviewBadge]} por revisar`}>
                          {reviewCounts[item.reviewBadge]}
                        </span>
                      )}
                    </NavLink>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </nav>

      <div className="sidebar__footer">
        {user && (
          <div className="sidebar__user" title={compact ? displayName : undefined}>
            <div className="avatar avatar--sm">{initials(displayName)}</div>
            {!compact && (
              <div style={{ minWidth: 0 }}>
                <div className="sidebar__user-name">{displayName}</div>
                <div className="sidebar__user-sub">@{user.username}</div>
              </div>
            )}
          </div>
        )}
        <button
          type="button"
          className="sidebar__collapse-btn"
          onClick={onToggleCollapsed}
          aria-label={compact ? 'Expandir menú' : 'Colapsar menú'}
        >
          <Icon name={compact ? 'chevronRight' : 'chevronLeft'} size={16} />
          {!compact && 'Colapsar menú'}
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;

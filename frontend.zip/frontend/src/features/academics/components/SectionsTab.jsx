import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import academicsApi from '../../../api/endpoints/academics.api';
import { useAuth } from '../../../context/AuthContext';
import { useFetch } from '../../../hooks/useFetch';
import { useMutation } from '../../../hooks/useMutation';
import DataTable from '../../../components/ui/DataTable';
import Button from '../../../components/ui/Button';
import Drawer from '../../../components/ui/Drawer';
import Field from '../../../components/ui/Field';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Alert from '../../../components/ui/Alert';
import Spinner from '../../../components/ui/Spinner';
import { useToast } from '../../../components/ui/Toast';
import { LEVELS, LEVEL_CODES, LevelBadge, LevelFilter, LevelRule } from '../levels';
import TeacherAssignmentModal from './TeacherAssignmentModal';
import ImportActions from '../../../components/import/ImportActions';
import HelpTip from '../../../components/ui/HelpTip';
import { useDefaultSchoolPeriod } from '../../../hooks/useDefaultSchoolPeriod';

/** Personal docente de una sección según su nivel (docente / auxiliar / docente guía). */
export function TeachersSummary({ section }) {
  if (section.assignment_mode === 'subjects') {
    return (
      <div className="teacher-stack">
        {section.guide_teacher_name ? <span>{section.guide_teacher_name}</span> : <span className="teacher-stack__missing">Sin docente guía</span>}
        <span className="cell-person__sub">Docente guía</span>
      </div>
    );
  }
  const { lead, assistant } = section.teachers || {};
  return (
    <div className="teacher-stack">
      {lead ? <span>{lead.name}</span> : <span className="teacher-stack__missing">Sin docente</span>}
      {section.allows_assistant &&
        (assistant ? (
          <span className="cell-person__sub">Aux.: {assistant.name}</span>
        ) : (
          <span className="cell-person__sub teacher-stack__missing">Sin docente auxiliar</span>
        ))}
    </div>
  );
}

function SectionsTab({ onChanged }) {
  const { can } = useAuth();
  const navigate = useNavigate();
  const { data: sections, loading, error, refetch } = useFetch(() => academicsApi.listSections(), []);
  const reload = () => {
    refetch();
    onChanged?.();
  };
  const [level, setLevel] = useState('');
  const [editing, setEditing] = useState(null); // null | {} crear | sección
  const [assigning, setAssigning] = useState(null); // id de sección

  const counts = useMemo(
    () => (sections || []).reduce((acc, s) => ({ ...acc, [s.level_code]: (acc[s.level_code] || 0) + 1 }), {}),
    [sections]
  );
  const rows = useMemo(() => (sections || []).filter((s) => !level || s.level_code === level), [sections, level]);

  const columns = [
    {
      key: 'name',
      header: 'Sección',
      render: (s) => (
        <div>
          <Link to={`/academics/sections/${s.id}`} className="cell-person__name">
            {s.grade_name} · {s.name}
          </Link>
          <div className="cell-person__sub">
            {s.school_period_name}
            {s.classroom_name && ` · ${s.classroom_name}`}
          </div>
        </div>
      ),
      sortValue: (s) => `${LEVEL_CODES.indexOf(s.level_code)}-${s.grade_name}-${s.name}`,
    },
    { key: 'level_code', header: 'Nivel', render: (s) => <LevelBadge code={s.level_code} />, sortValue: (s) => LEVEL_CODES.indexOf(s.level_code) },
    {
      key: 'teachers',
      header: (
        <>
          Personal docente{' '}
          <HelpTip placement="bottom">Inicial: docente y docente auxiliar. Primaria: docente. Secundaria: docente guía. Los docentes por materia se asignan en Materias.</HelpTip>
        </>
      ), render: (s) => <TeachersSummary section={s} /> },
    {
      key: 'enrolled_count',
      header: 'Inscritos',
      render: (s) => (
        <span className={s.enrolled_count >= s.max_students ? 'text-danger' : undefined}>
          {s.enrolled_count}/{s.max_students}
        </span>
      ),
      sortValue: (s) => s.enrolled_count / s.max_students,
    },
  ];

  return (
    <>
      <DataTable
        title="Secciones"
        description="Cada sección pertenece a un grado y su personal docente depende del nivel."
        columns={columns}
        rows={rows}
        loading={loading}
        error={error}
        searchPlaceholder="Buscar por grado, sección o docente…"
        getSearchText={(s) =>
          [s.grade_name, s.name, s.school_period_name, s.classroom_name, s.teachers?.lead?.name, s.teachers?.assistant?.name, s.guide_teacher_name, LEVELS[s.level_code]?.short].join(' ')
        }
        filters={<LevelFilter value={level} onChange={setLevel} counts={counts} />}
        emptyMessage="Aún no hay secciones creadas."
        createLabel="Nueva sección"
        onCreate={() => setEditing({})}
        canCreate={can('academics', 'create')}
        headerActions={
          can('academics', 'create') && (
            <ImportActions
              type="sections"
              noun="secciones"
              description="Grado, nombre, año escolar, cupo, aula y docentes. Los grados, años, aulas y docentes deben existir antes; la plantilla trae listas con los registrados."
              onImported={reload}
            />
          )
        }
        rowActions={
          can('academics', 'update')
            ? [{ key: 'assign', icon: 'users', label: 'Personal docente', onClick: (s) => setAssigning(s.id) }]
            : []
        }
        onView={(s) => navigate(`/academics/sections/${s.id}`)}
        onEdit={setEditing}
        canEdit={can('academics', 'update')}
      />

      {editing !== null && (
        <SectionFormModal
          initial={editing}
          onClose={() => setEditing(null)}
          onSaved={(saved, isNew) => {
            reload();
            // Recién creada: se abre directamente la asignación docente de su nivel.
            if (isNew && can('academics', 'update')) setAssigning(saved.id);
          }}
        />
      )}

      {assigning && <TeacherAssignmentModal sectionId={assigning} onClose={() => setAssigning(null)} onSaved={reload} />}
    </>
  );
}

function SectionFormModal({ initial, onClose, onSaved }) {
  const isEdit = Boolean(initial.id);
  const { data: grades, loading: loadingGrades } = useFetch(() => academicsApi.listGrades(), []);
  const { data: periods, loading: loadingPeriods } = useFetch(() => academicsApi.listSchoolPeriods(), []);
  const { data: classrooms, loading: loadingClassrooms } = useFetch(() => academicsApi.listClassrooms(), []);
  const toast = useToast();

  const [form, setForm] = useState({
    gradeId: initial.grade_id || '',
    schoolPeriodId: initial.school_period_id || '',
    classroomId: initial.classroom_id || '',
    name: initial.name || '',
    maxStudents: initial.max_students || 30,
  });
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  // Sección nueva: en el año escolar en curso (al editar, el año no cambia).
  useDefaultSchoolPeriod(isEdit ? null : periods, form.schoolPeriodId, (id) => setForm((f) => ({ ...f, schoolPeriodId: id })));

  const { run, loading, error, fieldErrors } = useMutation(
    isEdit ? (data) => academicsApi.updateSection(initial.id, data) : academicsApi.createSection
  );

  const selectedGrade = grades?.find((g) => g.id === form.gradeId);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const base = { name: form.name, maxStudents: Number(form.maxStudents), classroomId: form.classroomId || null };
    try {
      const saved = await run(isEdit ? base : { ...base, gradeId: form.gradeId, schoolPeriodId: form.schoolPeriodId });
      toast.success(isEdit ? 'Sección actualizada' : 'Sección creada', `${saved.grade_name} ${saved.name}`);
      onClose();
      onSaved(saved, !isEdit);
    } catch {
      // error visible en el modal
    }
  };

  const loadingOptions = loadingGrades || loadingPeriods || loadingClassrooms;

  return (
    <Drawer title={isEdit ? `Editar sección ${initial.grade_name} ${initial.name}` : 'Nueva sección'} onClose={onClose}>
      <Alert>{error}</Alert>
      {loadingOptions ? (
        <Spinner />
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <Field
              label="Grado"
              error={fieldErrors.gradeId}
              required
              hint={isEdit ? 'El grado no se puede cambiar: definiría otro nivel y otras reglas docentes.' : undefined}
            >
              <Select sorted value={form.gradeId} onChange={set('gradeId')} required disabled={isEdit}>
                <option value="">Selecciona…</option>
                {LEVEL_CODES.map((code) => {
                  const list = grades.filter((g) => g.level_code === code);
                  return list.length ? (
                    <optgroup key={code} label={LEVELS[code].name}>
                      {list.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name}
                        </option>
                      ))}
                    </optgroup>
                  ) : null;
                })}
              </Select>
            </Field>
            <Field label="Año escolar" error={fieldErrors.schoolPeriodId} required>
              <Select sorted value={form.schoolPeriodId} onChange={set('schoolPeriodId')} required disabled={isEdit}>
                <option value="">Selecciona…</option>
                {periods.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </Select>
            </Field>
            {selectedGrade && !isEdit && (
              <div className="form-field--full">
                <LevelRule code={selectedGrade.level_code} />
              </div>
            )}
            <Field label="Nombre de la sección" error={fieldErrors.name} required>
              <Input value={form.name} onChange={set('name')} placeholder="A" required />
            </Field>
            <Field label="Cupo máximo" error={fieldErrors.maxStudents} required>
              <Input type="number" min="1" value={form.maxStudents} onChange={set('maxStudents')} required />
            </Field>
            <Field label="Aula física" full>
              <Select sorted value={form.classroomId} onChange={set('classroomId')}>
                <option value="">Sin asignar</option>
                {classrooms.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          {grades.length === 0 && <Alert variant="warning">Primero crea al menos un grado en el Paso 2: Grados y aulas.</Alert>}
          <div className="form-actions">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" loading={loading}>
              {isEdit ? 'Guardar cambios' : 'Crear y asignar personal'}
            </Button>
          </div>
        </form>
      )}
    </Drawer>
  );
}

export default SectionsTab;

import { useState } from 'react';
import Icon from '../../../components/ui/Icon';
import Button from '../../../components/ui/Button';
import { SETUP_STEPS } from './useSetupStatus';

const storageKey = (key) => `academics.guide.${key}.collapsed`;

function readCollapsed(key) {
  try {
    // Contraída por defecto; solo queda abierta si el usuario la abrió ('0').
    return localStorage.getItem(storageKey(key)) !== '0';
  } catch {
    return true;
  }
}

/**
 * Banner de ayuda de un paso: qué hacer aquí, cómo se conecta con el resto
 * y cuál es la siguiente acción concreta. Empieza contraída ("Ver guía") y se
 * recuerda por navegador si el usuario la abre.
 */
export function StepGuide({ step, guide, total = SETUP_STEPS.length, eyebrow = null }) {
  const [collapsed, setCollapsed] = useState(() => readCollapsed(step.key));

  const toggle = () => {
    setCollapsed((c) => {
      try {
        localStorage.setItem(storageKey(step.key), c ? '0' : '1');
      } catch {
        // almacenamiento no disponible: solo afecta a recordar la preferencia
      }
      return !c;
    });
  };

  return (
    <div className={`step-guide ${collapsed ? 'step-guide--collapsed' : ''}`}>
      <div className="step-guide__head">
        <span className="step-guide__icon">
          <Icon name={step.icon} size={18} />
        </span>
        <div className="step-guide__heading">
          <div className="step-guide__eyebrow">{eyebrow || `Paso ${step.number} de ${total}`}</div>
          <h3>{step.title}</h3>
        </div>
        <button type="button" className="step-guide__toggle" onClick={toggle} aria-expanded={!collapsed}>
          <Icon name="helpCircle" size={15} />
          {collapsed ? 'Ver guía' : 'Ocultar guía'}
        </button>
      </div>

      {!collapsed && (
        <div className="step-guide__body">
          <p>{guide.intro}</p>
          {guide.links?.length > 0 && (
            <ul className="step-guide__links">
              {guide.links.map((text, i) => (
                <li key={i}>
                  <Icon name="arrowRight" size={14} />
                  <span>{text}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {step.todo ? (
        <div className="step-guide__todo">
          <strong>Qué falta:</strong> {step.todo}
        </div>
      ) : (
        <div className="step-guide__todo step-guide__todo--done">
          <Icon name="checkCircle" size={15} />
          {step.optional ? step.summary : `Paso completo · ${step.summary}`}
        </div>
      )}
    </div>
  );
}

/** Aviso cuando se abre un paso cuyo requisito previo aún no está listo. */
export function BlockedNotice({ blockedBy, onGo }) {
  const prev = SETUP_STEPS.find((s) => s.key === blockedBy);
  if (!prev) return null;
  return (
    <div className="alert alert--warning step-blocked">
      <Icon name="alertTriangle" size={17} />
      <div>
        Antes de este paso completa <strong>Paso {prev.number}: {prev.title}</strong>. Lo que hagas aquí depende de eso.
      </div>
      <Button size="sm" variant="secondary" onClick={() => onGo(prev.key)}>
        Ir al paso {prev.number}
      </Button>
    </div>
  );
}

/**
 * Pie de cada paso: volver / continuar. El botón de continuar es primario solo
 * cuando el paso actual ya está completo, para no competir con la acción
 * principal de la pantalla ("Nuevo grado", "Nueva sección"…).
 * `steps`: los pasos del asistente; `finish` = { label, onClick } para el último
 * (p. ej. "Continuar: Secciones y docentes", que es otra página).
 */
export function StepFooter({ step, onGo, steps = SETUP_STEPS, finish = null }) {
  const index = steps.findIndex((s) => s.key === step.key);
  const prev = steps[index - 1];
  const next = steps[index + 1];
  const nextLabel = next ? next.short : finish?.label;
  const goNext = next ? () => onGo(next.key) : finish?.onClick;

  return (
    <div className="step-footer">
      {prev ? (
        <Button variant="ghost" icon="arrowLeft" onClick={() => onGo(prev.key)}>
          {prev.short}
        </Button>
      ) : (
        <span />
      )}
      {nextLabel && (
        <div className="step-footer__next">
          {!step.done && <span className="text-sm text-muted">Puedes seguir y volver luego.</span>}
          <Button variant={step.done ? 'primary' : 'secondary'} onClick={goNext}>
            Continuar: {nextLabel}
            <Icon name="arrowRight" size={16} />
          </Button>
        </div>
      )}
    </div>
  );
}

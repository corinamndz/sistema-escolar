import { useRef, useState } from 'react';
import evaluationPlansApi from '../../../api/endpoints/evaluationPlans.api';
import { getErrorMessage } from '../../../api/axiosClient';
import Drawer from '../../../components/ui/Drawer';
import Button from '../../../components/ui/Button';
import Field from '../../../components/ui/Field';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Alert from '../../../components/ui/Alert';
import { useToast } from '../../../components/ui/Toast';
import { useConfirm } from '../../../components/ui/ConfirmDialog';
import { termLabel, useTerms } from '../../evaluation-plans/terms';
import { ContentRefsEditor, CriteriaEditor, FormatPicker, detailedBody, detailedFormFrom } from '../../evaluation-plans/components/DetailedPlanner';
import { INSTRUMENT_LABELS } from '../../evaluation-plans/instruments';
import { CATEGORY_LABELS } from '../categories';
import { weekendError } from '../../../utils/weekdays';

const NEW_PLAN = 'new';
const round2 = (n) => Math.round(n * 100) / 100;

/** "Período I · Secc. A, B · 60% usado" para el selector de plan. */
const planLabel = (p) =>
  `${termLabel(p.term_number, p.term_name)} · Secc. ${p.section_names} · ${p.teacher_name} · ${p.total_weight}% usado${p.format === 'detailed' ? ' · detallado' : ''}${p.status === 'closed' ? ' (cerrado)' : ''}`;

/**
 * Incluir una evaluación para un tema del contenido programático: la actividad
 * se agrega a un plan de evaluación de la materia en ese grado (uno existente o
 * uno nuevo, eligiendo período y secciones) y queda vinculada al tema. Un mismo
 * tema puede tener varias (un taller y un examen, por ejemplo).
 *
 * Formato:
 *   Simple     actividad, tipo, porcentaje, fecha y descripción.
 *   Detallado  además instrumento (rúbrica, escala de estimación…), estrategia,
 *              puntaje, criterios con indicadores y puntos (deben sumar el
 *              puntaje) y fecha de aplicación por sección. Si el plan elegido
 *              es simple, pasa a detallado al guardar (en la misma operación).
 */
function IncludeEvaluationModal({ item, content, schoolPeriodId, onClose, onSaved }) {
  const { data: terms } = useTerms(schoolPeriodId);
  const toast = useToast();
  const openPlans = content.plans.filter((p) => p.status !== 'closed' && p.total_weight < 100);
  const firstPlan = openPlans[0] || null;
  const [planId, setPlanId] = useState(firstPlan?.id || NEW_PLAN);
  const [format, setFormat] = useState(firstPlan?.format || 'simple');
  const [newPlan, setNewPlan] = useState({ termNumber: 1, sectionIds: content.sections.length === 1 ? [content.sections[0].id] : [] });
  const [form, setForm] = useState({ title: '', category: 'formative', weightPercent: '', plannedDate: '', description: '' });
  const [detail, setDetail] = useState(() => ({ ...detailedFormFrom({}, []), instrument: '' }));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const confirm = useConfirm();
  const fileInput = useRef(null);
  const [downloading, setDownloading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [imported, setImported] = useState(null); // { fileName, summary, warnings }
  const [importError, setImportError] = useState(null);
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const setD = (key) => (e) => setDetail((d) => ({ ...d, [key]: e.target.value }));

  const plan = content.plans.find((p) => p.id === planId);
  const detailed = format === 'detailed';
  // Secciones a las que se aplica la actividad: las del plan elegido o las marcadas para el plan nuevo.
  const sections = plan ? plan.sections : content.sections.filter((s) => newPlan.sectionIds.includes(s.id));
  const remaining = plan ? round2(100 - plan.total_weight) : 100;
  const typed = form.weightPercent === '' ? null : Number(form.weightPercent);
  const weightError = typed === null ? null : !(typed > 0) ? 'Debe ser mayor que 0.' : typed > remaining ? `Excede lo disponible en el plan (${remaining}%).` : null;
  const needsSections = planId === NEW_PLAN && newPlan.sectionIds.length === 0;
  // Formato detallado: los indicadores deben sumar exactamente el puntaje de la actividad (mismo cálculo que CriteriaEditor).
  const toNum = (v) => Number(String(v ?? '').replace(',', '.'));
  const indicatorPoints = detail.criteria.flatMap((c) => c.indicators).map((i) => toNum(i.points));
  const pointsTotal = round2(indicatorPoints.reduce((n, p) => n + (Number.isFinite(p) ? p : 0), 0));
  const maxScore = toNum(detail.maxScore);
  const pointsMismatch = detailed && (!(maxScore > 0) || indicatorPoints.length === 0 || pointsTotal !== round2(maxScore));
  // Sin evaluaciones en sábado ni domingo (el backend también responde 400).
  const plannedDateError = !detailed ? weekendError(form.plannedDate) : null;
  const sectionDateErrors = detailed
    ? sections.map((s) => weekendError(detail.sectionDates[s.id]) && `Sección ${s.name}: ${weekendError(detail.sectionDates[s.id])}`).filter(Boolean)
    : [];
  const dateError = Boolean(plannedDateError || sectionDateErrors.length);
  const canSave = form.title.trim() && typed && !weightError && !needsSections && !pointsMismatch && !dateError;

  // Al cambiar de plan, el formato sugerido es el del plan (uno detallado sigue en detallado).
  const choosePlan = (id) => {
    setPlanId(id);
    const p = content.plans.find((x) => x.id === id);
    if (p) setFormat(p.format);
  };
  const sectionParams = () => ({ sections: sections.map((s) => s.name).join(',') || undefined });

  const downloadTemplate = async () => {
    setDownloading(true);
    try {
      await evaluationPlansApi.downloadActivityTemplate({ ...sectionParams(), topic: item.topic });
    } catch (err) {
      toast.error('No se pudo descargar la plantilla', getErrorMessage(err));
    } finally {
      setDownloading(false);
    }
  };

  const pickFile = async () => {
    const hasData = form.title.trim() || detail.criteria.some((c) => c.title.trim() || c.indicators.some((i) => i.description.trim()));
    if (hasData) {
      const ok = await confirm({
        title: '¿Reemplazar lo que ya escribiste?',
        message: 'Los datos del Excel reemplazarán la actividad, los criterios e indicadores y las fechas del formulario.',
        confirmLabel: 'Elegir archivo',
      });
      if (!ok) return;
    }
    fileInput.current?.click();
  };

  // El Excel llena el formulario; el usuario revisa y guarda (nada se guarda al importar).
  const importFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setImporting(true);
    setImportError(null);
    try {
      const { activity: a, summary, warnings } = await evaluationPlansApi.parseActivityExcel(file, sectionParams());
      setForm((f) => ({
        ...f,
        title: a.title || '',
        category: a.category || 'formative',
        weightPercent: a.weightPercent === null ? '' : String(a.weightPercent),
        description: a.description || '',
        plannedDate: a.date || '',
      }));
      setDetail((d) => ({
        ...d,
        instrument: a.instrument || '',
        strategy: a.strategy || '',
        maxScore: a.maxScore ?? d.maxScore,
        contentRefs: a.contentRefs.map((t) => ({ topic: t.topic, subtopics: t.subtopics.length ? t.subtopics : [''] })),
        criteria: a.criteria.map((c) => ({ title: c.title, indicators: c.indicators.map((i) => ({ description: i.description, points: String(i.points) })) })),
        sectionDates: Object.fromEntries(sections.map((s) => [s.id, a.sectionDates[s.name] || a.date || ''])),
      }));
      setImported({ fileName: file.name, summary, warnings });
    } catch (err) {
      setImported(null);
      setImportError(getErrorMessage(err));
    } finally {
      setImporting(false);
    }
  };

  const toggleSection = (id) =>
    setNewPlan((p) => ({ ...p, sectionIds: p.sectionIds.includes(id) ? p.sectionIds.filter((x) => x !== id) : [...p.sectionIds, id] }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!canSave) return;
    let extra = {};
    if (detailed) {
      // Solo las fechas de las secciones de la actividad (pudo cambiar el plan elegido).
      const sectionIds = new Set(sections.map((s) => s.id));
      const result = detailedBody({ ...detail, sectionDates: Object.fromEntries(Object.entries(detail.sectionDates).filter(([id]) => sectionIds.has(id))) });
      if (result.error) return setError(result.error);
      if (!result.body.criteria.length) return setError('El formato detallado requiere al menos un criterio con sus indicadores.');
      extra = { ...result.body, instrument: detail.instrument || null, planFormat: 'detailed' };
    }
    setSaving(true);
    setError(null);
    try {
      let targetId = planId;
      if (planId === NEW_PLAN) {
        const created = await evaluationPlansApi.create({
          sectionIds: newPlan.sectionIds,
          termNumber: Number(newPlan.termNumber),
          subjectId: content.subject_id,
          format,
        });
        targetId = created.id;
      }
      await evaluationPlansApi.createActivity(targetId, {
        title: form.title.trim(),
        category: form.category,
        weightPercent: typed,
        plannedDate: form.plannedDate,
        description: form.description.trim(),
        programmaticContentId: item.id,
        ...extra,
      });
      toast.success('Evaluación incluida', `${form.title.trim()} · ${item.topic}`);
      onSaved();
      onClose();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
    return undefined;
  };

  return (
    <Drawer title="Incluir evaluación" onClose={onClose} size="lg">
      <div className="pc-include-topic">
        <span className="pc-unit-chip">{item.unit}</span>
        <strong>{item.topic}</strong>
      </div>
      <form onSubmit={handleSubmit}>
        <Field label="Formato de la evaluación">
          <FormatPicker value={format} onChange={setFormat} />
        </Field>
        {detailed && plan && plan.format !== 'detailed' && (
          <Alert variant="info">
            El plan {termLabel(plan.term_number, plan.term_name)} · Secc. {plan.section_names} pasará a formato detallado al guardar. Sus actividades actuales se conservan.
          </Alert>
        )}
        <Alert>{error}</Alert>
        <div className="form-grid">
          <Field label="Plan de evaluación" full hint="La actividad suma al plan del período y las secciones que elijas.">
            <Select value={planId} onChange={(e) => choosePlan(e.target.value)}>
              {content.plans.map((p) => (
                <option key={p.id} value={p.id} disabled={p.status === 'closed' || p.total_weight >= 100}>
                  {planLabel(p)}
                </option>
              ))}
              <option value={NEW_PLAN} disabled={content.sections.length === 0}>
                + Nuevo plan de evaluación…
              </option>
            </Select>
          </Field>
          {planId === NEW_PLAN && (
            <>
              <Field label="Período">
                <Select value={newPlan.termNumber} onChange={(e) => setNewPlan((p) => ({ ...p, termNumber: e.target.value }))}>
                  {(terms || []).map((t) => (
                    <option key={t.id} value={t.term_number}>
                      {t.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Secciones" error={needsSections ? 'Elige al menos una sección.' : null}>
                <div className="pc-sections">
                  {content.sections.map((s) => (
                    <label key={s.id} className="checkbox-row">
                      <input type="checkbox" checked={newPlan.sectionIds.includes(s.id)} onChange={() => toggleSection(s.id)} />
                      Sección {s.name}
                    </label>
                  ))}
                </div>
              </Field>
            </>
          )}
          <Field label={detailed ? 'Actividad o instrumento' : 'Actividad'} required full>
            <Input value={form.title} onChange={set('title')} maxLength={200} placeholder="Ej. Taller de la célula, Examen práctico" required />
          </Field>
          <Field label="Tipo">
            <Select value={form.category} onChange={set('category')}>
              {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Porcentaje de la nota" required error={weightError} hint={`Disponible en el plan: ${remaining}%`}>
            <Input type="number" min="0.01" max="100" step="0.01" suffix="%" value={form.weightPercent} onChange={set('weightPercent')} error={weightError} required />
          </Field>
          {!detailed && (
            <Field label="Fecha estimada" hint="Opcional; dentro del período, de lunes a viernes." error={plannedDateError}>
              <Input type="date" value={form.plannedDate} onChange={set('plannedDate')} error={Boolean(plannedDateError)} />
            </Field>
          )}
          <Field label="Descripción" full hint="Opcional: instrucciones o criterios generales.">
            <textarea className="input" rows={2} maxLength={1000} value={form.description} onChange={set('description')} />
          </Field>
        </div>

        {detailed && (
          <div className="pc-detailed">
            <div className="pc-detailed__head">
              <h4 className="pc-detailed__title">Evaluación detallada</h4>
              <div className="pc-detailed__actions">
                <Button type="button" size="sm" variant="ghost" icon="download" onClick={downloadTemplate} loading={downloading} loadingText="Generando…">
                  Plantilla
                </Button>
                <Button type="button" size="sm" variant="secondary" icon="spreadsheet" onClick={pickFile} loading={importing} loadingText="Leyendo…">
                  Importar detalle desde Excel
                </Button>
                <input ref={fileInput} type="file" accept=".xlsx,.csv" hidden onChange={importFile} />
              </div>
            </div>
            <Alert>{importError}</Alert>
            {imported && (
              <Alert variant={imported.warnings.length ? 'warning' : 'success'}>
                Se cargaron {imported.summary.criteria} criterio{imported.summary.criteria === 1 ? '' : 's'} y {imported.summary.indicators} indicador
                {imported.summary.indicators === 1 ? '' : 'es'} ({imported.summary.total} pts) desde «{imported.fileName}». Revisa los datos y pulsa «Incluir evaluación» para guardar.
                {imported.warnings.map((w) => (
                  <div key={w}>{w}</div>
                ))}
              </Alert>
            )}
            <div className="form-grid">
              <Field label="Instrumento de evaluación" hint="Opcional.">
                <Select value={detail.instrument} onChange={setD('instrument')}>
                  <option value="">Sin especificar</option>
                  {Object.entries(INSTRUMENT_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Estrategia evaluativa" hint="Ej.: trabajo en parejas, actividad individual.">
                <Input value={detail.strategy} onChange={setD('strategy')} maxLength={200} />
              </Field>
              <Field label="Puntaje de la actividad" required hint="Los indicadores deben sumar este puntaje (ej. 20).">
                <Input inputMode="decimal" value={detail.maxScore} onChange={setD('maxScore')} suffix="pts" required />
              </Field>
              <Field label="Referencias teórico-prácticas adicionales" full hint={`Opcional: el tema «${item.topic}» ya queda como referencia.`}>
                <ContentRefsEditor value={detail.contentRefs} onChange={(contentRefs) => setDetail((d) => ({ ...d, contentRefs }))} />
              </Field>
              <Field label="Criterios e indicadores de logro" required full hint="Cada criterio con sus indicadores y el puntaje de cada uno.">
                <CriteriaEditor value={detail.criteria} onChange={(criteria) => setDetail((d) => ({ ...d, criteria }))} maxScore={detail.maxScore} />
              </Field>
              <Field
                label="Fechas de aplicación"
                full
                error={sectionDateErrors.join(' ') || undefined}
                hint={sections.length ? 'Opcional; dentro del período, de lunes a viernes.' : 'Elige las secciones del plan para indicar sus fechas.'}
              >
                <div className="section-dates">
                  {sections.map((s) => (
                    <label key={s.id} className="section-dates__item">
                      <span>Sección {s.name}</span>
                      <Input
                        type="date"
                        value={detail.sectionDates[s.id] || ''}
                        onChange={(e) => setDetail((d) => ({ ...d, sectionDates: { ...d.sectionDates, [s.id]: e.target.value } }))}
                        aria-label={`Fecha de aplicación en la sección ${s.name}`}
                        error={Boolean(weekendError(detail.sectionDates[s.id]))}
                      />
                    </label>
                  ))}
                </div>
              </Field>
            </div>
          </div>
        )}

        <div className="form-actions">
          {pointsMismatch && (
            <span className="form-actions__hint" role="status">
              {maxScore > 0 && indicatorPoints.length
                ? `Los indicadores suman ${pointsTotal} de ${round2(maxScore)} pts: ajústalos para poder guardar.`
                : 'Indica el puntaje de la actividad y de sus indicadores para poder guardar.'}
            </span>
          )}
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            type="submit"
            loading={saving}
            disabled={!canSave}
            title={pointsMismatch ? 'Los puntajes de los indicadores deben sumar el puntaje de la actividad' : undefined}
          >
            Incluir evaluación
          </Button>
        </div>
      </form>
    </Drawer>
  );
}

export default IncludeEvaluationModal;

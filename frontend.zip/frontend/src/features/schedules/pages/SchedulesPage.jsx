import { useEffect, useMemo, useRef, useState } from 'react';
import schedulesApi from '../../../api/endpoints/schedules.api';
import academicsApi from '../../../api/endpoints/academics.api';
import { getErrorMessage } from '../../../api/axiosClient';
import { useAuth } from '../../../context/AuthContext';
import { useFetch } from '../../../hooks/useFetch';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Alert from '../../../components/ui/Alert';
import Spinner from '../../../components/ui/Spinner';
import Icon from '../../../components/ui/Icon';
import { useToast } from '../../../components/ui/Toast';
import { useConfirm } from '../../../components/ui/ConfirmDialog';
import ScheduleGrid, { hueOf } from '../components/ScheduleGrid';
import SlotsEditorModal from '../components/SlotsEditorModal';
import TeacherScheduleView from '../components/TeacherScheduleView';
import AssignmentsView from '../components/AssignmentsView';
import EvaluationCalendar from '../components/EvaluationCalendar';
import { useTerms } from '../../evaluation-plans/terms';
import QuickAssign from '../components/QuickAssign';
import ScheduleGeneratorModal from '../components/ScheduleGeneratorModal';
import TeacherAvailabilityModal from '../components/TeacherAvailabilityModal';
import { blobErrorMessage, saveBlob } from '../../../utils/download';
import { useDefaultSchoolPeriod } from '../../../hooks/useDefaultSchoolPeriod';
import { mergeSlotRows } from '../slotGrid';

/** Duración del desvanecimiento al quitar una clase (igual que .schedule-entry.is-removing en index.css). */
const REMOVE_FADE_MS = 180;

const VIEWS = [
  { key: 'section', label: 'Por grado / sección', icon: 'layers' },
  { key: 'teacher', label: 'Por docente', icon: 'user' },
  { key: 'assignments', label: 'Asignaciones', icon: 'users' },
  // Horario de evaluaciones: generado desde los planes de evaluación (fechas) y el horario de clases (horas).
  { key: 'evaluations', label: 'Horario de evaluaciones', icon: 'clipboard' },
];

/**
 * Horarios (administración). Dos formas de ver la grilla semanal:
 *
 *   - Por grado / sección: se elige grado y sección; se ve y se ARMA su
 *     horario (lo de abajo).
 *   - Por docente: se elige un profesor (A-Z) y se ve, en solo lectura, toda
 *     su semana en las distintas secciones, con huecos y carga por día. Al
 *     tocar una clase se abre su sección para editarla.
 *
 * Armado del horario de una sección:
 *
 *   - Arrastra una materia del banco (o una clase ya colocada) y suéltala en
 *     una celda; o tócala y luego toca la celda (pantallas táctiles).
 *   - Mientras se arrastra, las celdas en que el profesor de esa materia ya da
 *     clase en otra sección se marcan en rojo y no aceptan la materia.
 *   - El backend vuelve a validar (celda libre, sin cruce del docente) y
 *     responde con el motivo si rechaza la clase.
 *   - Soltar una clase sobre el banco la quita del horario.
 */
function SchedulesPage() {
  const { can, user } = useAuth();
  const toast = useToast();
  const { data: periods } = useFetch(() => schedulesApi.listPeriods(), []);
  const [periodId, setPeriodId] = useState('');
  const { data: terms } = useTerms(periodId);
  // TODOS los grados del colegio (jerarquía escolar), cada uno con sus secciones
  // en el año elegido. Se vuelve a pedir al cambiar de año.
  const {
    data: grades,
    loading: loadingGrades,
    refetch: refetchGrades,
  } = useFetch(() => (periodId ? schedulesApi.listGrades(periodId) : Promise.resolve([])), [periodId]);
  const [view, setView] = useState('section'); // 'section' (grado/sección) | 'teacher' (docente)
  const [gradeId, setGradeId] = useState('');
  const [sectionId, setSectionId] = useState('');
  const [teacherId, setTeacherId] = useState('');
  const [termNumber, setTermNumber] = useState(''); // horario de evaluaciones: período ('' = todos)
  // Docentes A-Z del año: para "Ver por docente" y para asignar profesores al instante.
  const {
    data: teachers,
    loading: loadingTeachers,
    refetch: refetchTeachers,
  } = useFetch(() => (periodId ? schedulesApi.listTeachers(periodId) : Promise.resolve(null)), [periodId]);
  const activeTeachers = useMemo(() => (teachers || []).filter((t) => t.active), [teachers]);
  const canAssign = can('academics', 'update');
  // Bloques del año: si no tiene, se avisa ANTES de elegir sección y se busca
  // otro año con bloques para ofrecer copiarlos.
  const { data: periodSlots, refetch: refetchPeriodSlots } = useFetch(
    () => (periodId ? schedulesApi.getSlots(periodId) : Promise.resolve(null)),
    [periodId],
  );
  const noSlots = Array.isArray(periodSlots) && periodSlots.length === 0;
  const { data: slotSource } = useFetch(async () => {
    if (!noSlots) return null;
    const others = (periods || []).filter((p) => p.id !== periodId).sort((a, b) => String(b.start_date || '').localeCompare(String(a.start_date || '')));
    for (const p of others) {
      if ((await schedulesApi.getSlots(p.id)).length) return p;
    }
    return null;
  }, [noSlots, periodId, periods]);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dragging, setDragging] = useState(null); // { subjectId, teacher, entryId? }
  const [selected, setSelected] = useState(null); // modo tocar-y-colocar: lo mismo que dragging
  const [editingSlots, setEditingSlots] = useState(false);
  const [saving, setSaving] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [generating, setGenerating] = useState(false); // modal del generador automático
  const [availabilityFor, setAvailabilityFor] = useState(null); // { teacherId } | null
  const [scheduleVersion, setScheduleVersion] = useState(0); // recarga las vistas tras guardar lo generado

  // Año por defecto: el EN CURSO (el que contiene la fecha de hoy). Si hay
  // varios años activos (p. ej. ya se creó el próximo), no se abre el futuro,
  // que aún no tiene bloques ni clases.
  useDefaultSchoolPeriod(periods, periodId, setPeriodId);
  useEffect(() => {
    setGradeId('');
    setSectionId('');
    setTeacherId('');
  }, [periodId]);

  /** `silent`: recarga tras guardar sin ocultar la grilla (sin parpadeo). */
  const load = async (id = sectionId, { silent = false } = {}) => {
    if (!id) return setData(null);
    if (!silent) setLoading(true);
    setError(null);
    try {
      setData(await schedulesApi.getSection(id));
    } catch (err) {
      setError(getErrorMessage(err));
      if (!silent) setData(null);
    } finally {
      if (!silent) setLoading(false);
    }
  };
  const refresh = () => load(sectionId, { silent: true });
  useEffect(() => {
    load(sectionId);
    setSelected(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sectionId]);

  const period = (periods || []).find((p) => p.id === periodId);
  const editable = Boolean(data && !data.read_only && can('schedules', 'update'));
  const active = dragging || selected; // lo que se está por colocar

  // Grados (con sus secciones del año) agrupados por nivel para el selector,
  // en el orden de la jerarquía escolar que ya trae el backend.
  const byGrade = useMemo(
    () => (grades || []).map((g) => ({ ...g, list: g.sections.map((s) => ({ ...s, grade_id: g.id, grade_name: g.name })) })),
    [grades],
  );
  const byLevel = useMemo(() => {
    const map = new Map();
    byGrade.forEach((g) => {
      if (!map.has(g.level_code)) map.set(g.level_code, { name: g.level_name, grades: [] });
      map.get(g.level_code).grades.push(g);
    });
    return [...map.values()];
  }, [byGrade]);
  const allSections = useMemo(() => byGrade.flatMap((g) => g.list), [byGrade]);
  const grade = byGrade.find((g) => g.id === gradeId);
  const gradeSections = grade?.list || [];

  const chooseGrade = (id) => {
    setGradeId(id);
    // Se abre de una vez la primera sección del grado (A); se cambia con el otro selector.
    setSectionId(byGrade.find((g) => g.id === id)?.list[0]?.id || '');
  };

  // Grado sin secciones en el año: se puede crear la primera desde aquí.
  const [creatingSection, setCreatingSection] = useState(false);
  const createFirstSection = async () => {
    setCreatingSection(true);
    try {
      const created = await academicsApi.createSection({ gradeId, schoolPeriodId: periodId, name: 'A' });
      toast.success('Sección creada', `${grade.name} · Sección A en ${period?.name}.`);
      await refetchGrades();
      setSectionId(created.id);
    } catch (err) {
      toast.error('No se pudo crear la sección', getErrorMessage(err));
    } finally {
      setCreatingSection(false);
    }
  };

  /** Desde la vista por docente: abrir (y poder editar) el horario de una de sus secciones. */
  const openSection = (id) => {
    const s = allSections.find((x) => x.id === id);
    if (!s) return;
    setGradeId(s.grade_id);
    setSectionId(s.id);
    setView('section');
  };

  /** Cruce: el profesor de lo que se coloca ya da clase en otra sección en ese día y bloque. */
  const conflictAt = (item, day, slot) => {
    if (!item?.teacher) return null;
    const busy = data?.teacher_busy?.[item.teacher.id]?.find((b) => b.day_of_week === day && b.time_slot_id === slot.id);
    if (!busy) return null;
    // Bloque marcado en "Disponibilidad docente".
    if (busy.unavailable) return `El profesor ${item.teacher.name} no está disponible en este bloque (${busy.subject_name}).`;
    return `Conflicto de horario: El profesor ${item.teacher.name} ya dicta clase en ${busy.where} a esta misma hora (${busy.subject_name}).`;
  };

  /** Clase que ya ocupa esa celda en la sección (sin contar la que se está moviendo). */
  const occupantAt = (item, day, slot) => data?.entries.find((e) => e.day_of_week === day && e.time_slot_id === slot.id && e.id !== item?.entryId);

  /**
   * Estado de cada celda mientras se arrastra:
   *   - rojo: el profesor ya tiene clase a esa hora en otra sección;
   *   - celda ocupada: se puede soltar igual → "Reemplazar" (desde el panel)
   *     o "Intercambiar" (al mover una clase ya puesta).
   */
  const cellState = (day, slot) => {
    if (!active) return {};
    const conflict = conflictAt(active, day, slot);
    if (conflict) return { conflict };
    if (active.entryId && active.day === day && active.slotId === slot.id) return {}; // su propia celda
    const occupant = occupantAt(active, day, slot);
    return { droppable: true, action: occupant ? (active.entryId ? 'swap' : 'replace') : null };
  };

  // Indicador de guardado (arriba de la grilla) y destello de las celdas guardadas.
  const [saveStatus, setSaveStatus] = useState(null); // null | 'saving' | 'saved' | 'error'
  const [flash, setFlash] = useState(() => new Set());
  const savedTimer = useRef(null);
  const markSaved = (cells) => {
    setSaveStatus('saved');
    setFlash(new Set(cells));
    clearTimeout(savedTimer.current);
    savedTimer.current = setTimeout(() => {
      setSaveStatus(null);
      setFlash(new Set());
    }, 2200);
  };
  useEffect(() => () => clearTimeout(savedTimer.current), []);

  /** Suelta (o toca) una materia/clase en una celda y la guarda en el backend al instante. */
  const placeAt = async (item, day, slot) => {
    const conflict = conflictAt(item, day, slot);
    if (conflict) {
      toast.error('No se puede colocar', conflict);
      return;
    }
    if (item.entryId && item.day === day && item.slotId === slot.id) return setSelected(null); // misma celda
    const occupant = occupantAt(item, day, slot);
    const onOccupied = occupant ? (item.entryId ? 'swap' : 'replace') : undefined;
    setSaving(true);
    setSaveStatus('saving');
    try {
      const saved = item.entryId
        ? await schedulesApi.move(item.entryId, { dayOfWeek: day, timeSlotId: slot.id, onOccupied })
        : await schedulesApi.place(sectionId, { subjectId: item.subjectId, dayOfWeek: day, timeSlotId: slot.id, onOccupied });
      await refresh();
      const cells = [`${day}|${slot.id}`];
      if (saved.swapped) cells.push(`${saved.swapped.day_of_week}|${saved.swapped.time_slot_id}`);
      markSaved(cells);
      if (saved.replaced) toast.success('Clase reemplazada', `${item.name} ocupa ahora la hora de ${saved.replaced.subject_name}.`);
      if (saved.swapped) toast.success('Clases intercambiadas', `${item.name} ⇄ ${saved.swapped.subject_name}.`);
    } catch (err) {
      setSaveStatus('error');
      toast.error('No se guardó el cambio', getErrorMessage(err));
    } finally {
      setSaving(false);
      setSelected(null);
    }
  };

  /**
   * Quita una clase de la grilla (× de la tarjeta o arrastrándola al panel):
   *   1. la tarjeta se desvanece y la celda queda vacía al instante;
   *   2. se borra en el servidor (la carga del docente se libera: se calcula de las clases);
   *   3. el aviso ofrece "Deshacer" (vuelve a colocarla en la misma hora), en lugar
   *      de una confirmación previa que frenaría cada cambio.
   * Si el servidor falla, la clase vuelve a su celda.
   */
  const [removingIds, setRemovingIds] = useState(() => new Set());
  const removing = (id, on) =>
    setRemovingIds((s) => {
      const next = new Set(s);
      if (on) next.add(id);
      else next.delete(id);
      return next;
    });
  const remove = async (entry) => {
    if (removingIds.has(entry.id)) return; // doble clic
    removing(entry.id, true);
    setSelected(null);
    setSaveStatus('saving');
    await new Promise((r) => setTimeout(r, REMOVE_FADE_MS)); // desvanecimiento
    setData((d) => (d ? { ...d, entries: d.entries.filter((e) => e.id !== entry.id) } : d));
    try {
      await schedulesApi.remove(entry.id);
      markSaved([]);
      refresh(); // horas pendientes del panel y carga de los docentes
      toast.show({
        variant: 'success',
        title: 'Clase quitada',
        message: `${entry.subject_name} · ${entry.teacher_name || 'sin docente'}`,
        duration: 6000,
        action: { label: 'Deshacer', onClick: () => undoRemove(entry) },
      });
    } catch (err) {
      setData((d) => (d && !d.entries.some((e) => e.id === entry.id) ? { ...d, entries: [...d.entries, entry] } : d));
      setSaveStatus('error');
      toast.error('No se pudo quitar', getErrorMessage(err));
    } finally {
      removing(entry.id, false);
    }
  };
  /**
   * "Limpiar horario": con confirmación obligatoria, quita TODAS las clases de la
   * sección. La grilla queda vacía al instante; si el servidor falla, se recarga.
   */
  const confirm = useConfirm();
  const [clearing, setClearing] = useState(false);
  const clearSchedule = async () => {
    const label = `${data.section.grade_name} · Sección ${data.section.name}`;
    const ok = await confirm({
      title: `¿Vaciar todo el horario de ${label}?`,
      message: `Se desasignarán las ${data.entries.length} clases de la semana y la carga de sus docentes quedará libre. Los bloques horarios y la asignación de docentes no cambian. Esta acción no se puede deshacer.`,
      confirmLabel: 'Sí, limpiar horario',
      danger: true,
      icon: 'trash',
    });
    if (!ok) return;
    setClearing(true);
    setSelected(null);
    setSaveStatus('saving');
    const previous = data.entries;
    setData((d) => (d ? { ...d, entries: [] } : d));
    try {
      const { removed } = await schedulesApi.clearSection(sectionId);
      markSaved([]);
      refresh(); // horas pendientes del panel de materias
      toast.success('Horario vaciado', `${label}: ${removed} ${removed === 1 ? 'clase quitada' : 'clases quitadas'}.`);
    } catch (err) {
      setData((d) => (d ? { ...d, entries: previous } : d));
      setSaveStatus('error');
      toast.error('No se pudo limpiar el horario', getErrorMessage(err));
    } finally {
      setClearing(false);
    }
  };

  /** "Deshacer": la vuelve a colocar en la misma hora (con el docente asignado hoy a la materia). */
  const undoRemove = async (entry) => {
    setSaveStatus('saving');
    try {
      await schedulesApi.place(sectionId, { subjectId: entry.subject_id, dayOfWeek: entry.day_of_week, timeSlotId: entry.time_slot_id });
      await refresh();
      markSaved([`${entry.day_of_week}|${entry.time_slot_id}`]);
    } catch (err) {
      setSaveStatus('error');
      toast.error('No se pudo deshacer', getErrorMessage(err));
    }
  };

  /** Año sin bloques: copia los de otro año (sin clases), para no cargarlos a mano. */
  const [copyingSlots, setCopyingSlots] = useState(false);
  const copySlotsFrom = async (source) => {
    setCopyingSlots(true);
    try {
      // Cada jornada por separado: la general y la propia de cada nivel que la tenga.
      const slots = await schedulesApi.getSlots(source.id);
      const byLevel = new Map();
      slots.forEach((s) => byLevel.set(s.level_code || null, [...(byLevel.get(s.level_code || null) || []), s]));
      for (const level of [null, ...[...byLevel.keys()].filter(Boolean)]) {
        if (!byLevel.has(level)) continue;
        await schedulesApi.saveSlots(periodId, byLevel.get(level).map((s) => ({ name: s.name, startTime: s.start_time, endTime: s.end_time, isBreak: s.is_break })), level);
      }
      toast.success('Bloques copiados', `Se copiaron ${slots.length} bloques (${byLevel.size} jornada${byLevel.size === 1 ? '' : 's'}) de ${source.name}.`);
      refetchPeriodSlots();
      await load();
    } catch (err) {
      toast.error('No se pudieron copiar los bloques', getErrorMessage(err));
    } finally {
      setCopyingSlots(false);
    }
  };

  const itemOfEntry = (e) => ({
    entryId: e.id,
    day: e.day_of_week,
    slotId: e.time_slot_id,
    subjectId: e.subject_id,
    teacher: { id: e.staff_id, name: e.teacher_name },
    name: e.subject_name,
  });
  const itemOfSubject = (b) => ({ subjectId: b.subject_id, teacher: b.teacher, name: b.subject_name });

  const totalPlaced = data?.entries?.length || 0;
  const freeCells = data ? data.slots.filter((s) => !s.is_break).length * data.days.length : 0;

  // PDF del horario que se está viendo: la sección elegida o el docente elegido.
  const pdfFilters =
    view === 'section'
      ? sectionId && { section_id: sectionId }
      : view === 'teacher'
        ? teacherId && periodId && { teacher_id: teacherId, school_period_id: periodId }
        : view === 'evaluations'
          ? sectionId && { evaluations: true, section_id: sectionId }
          : null;

  /**
   * Asignación rápida del profesor de una materia en una sección (sin ir a
   * Estructura académica). En Primaria deja a ese docente como especialista.
   */
  const assignSubjectTeacher = async (secId, subjectId, teacherId) => {
    try {
      await academicsApi.setSectionTeachers(secId, { subjects: [{ subjectId, teacherId }] });
      const who = activeTeachers.find((t) => t.id === teacherId)?.name;
      toast.success(teacherId ? 'Profesor asignado' : 'Profesor quitado', who ? `Prof. ${who}` : undefined);
      refetchTeachers();
      if (secId === sectionId) await refresh();
    } catch (err) {
      toast.error('No se pudo asignar', getErrorMessage(err));
    }
  };
  /** Primaria: docente titular de la sección (dicta todas las materias sin especialista). */
  const assignLeadTeacher = async (teacherId) => {
    try {
      await academicsApi.setSectionTeachers(sectionId, { leadTeacherId: teacherId });
      toast.success('Docente titular asignado', `Prof. ${activeTeachers.find((t) => t.id === teacherId)?.name || ''}`);
      refetchTeachers();
      await refresh();
    } catch (err) {
      toast.error('No se pudo asignar', getErrorMessage(err));
    }
  };
  const downloadPdf = async () => {
    setDownloading(true);
    try {
      const { blob, fileName } = pdfFilters.evaluations
        ? await schedulesApi.downloadEvaluationPdf(sectionId, termNumber ? Number(termNumber) : null)
        : await schedulesApi.downloadPdf(pdfFilters);
      saveBlob(blob, fileName);
    } catch (err) {
      toast.error('No se pudo generar el PDF', await blobErrorMessage(err));
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Horarios"
        subtitle="Arma el horario semanal de cada sección. El sistema impide que un profesor tenga dos clases a la misma hora."
        actions={
          <>
            {/* Jornadas por nivel: el Director todas; el coordinador, solo la de su nivel (el backend lo exige igual). */}
            {can('schedules', 'update') && (!user?.coordinator || user.coordinator.level) && period && !period.closed_at && (
              <Button variant="secondary" icon="clock" onClick={() => setEditingSlots(true)}>
                {user?.coordinator ? 'Jornada de mi nivel' : 'Jornadas y bloques'}
              </Button>
            )}
            {can('schedules', 'update') && period && !period.closed_at && (
              <Button variant="secondary" icon="user" onClick={() => setAvailabilityFor({ teacherId: view === 'teacher' ? teacherId : '' })} disabled={!activeTeachers.length}>
                Disponibilidad docente
              </Button>
            )}
            {can('schedules', 'update') && period && !period.closed_at && (
              <Button
                className="btn--generate"
                icon="sparkles"
                onClick={() => setGenerating(true)}
                disabled={noSlots}
                title={noSlots ? 'Configura primero los bloques horarios del año' : 'Arma el horario de todas las secciones sin cruces de profesores'}
              >
                Generar Horario Automático
              </Button>
            )}
            {/* Vaciar la sección abierta (solo en la grilla editable y si tiene clases). */}
            {view === 'section' && editable && data?.entries?.length > 0 && (
              <Button variant="danger" icon="trash" onClick={clearSchedule} loading={clearing} loadingText="Limpiando…">
                Limpiar horario
              </Button>
            )}
            <Button
              icon="download"
              onClick={downloadPdf}
              loading={downloading}
              loadingText="Generando PDF…"
              disabled={!pdfFilters || downloading}
              title={
                pdfFilters
                  ? 'Descargar el horario que estás viendo'
                  : view === 'teacher'
                    ? 'Elige un docente'
                    : view === 'assignments'
                      ? 'Abre el horario de una sección o de un docente para descargarlo'
                      : 'Elige un grado y su sección'
              }
            >
              Descargar PDF
            </Button>
          </>
        }
      />

      <Card>
        <div className="schedule-filters">
          <div className="segmented schedule-filters__views" role="tablist" aria-label="Ver horario">
            {VIEWS.map((v) => (
              <button
                key={v.key}
                type="button"
                role="tab"
                aria-selected={view === v.key}
                className={`segmented__item ${view === v.key ? 'segmented__item--active' : ''}`}
                onClick={() => setView(v.key)}
              >
                <Icon name={v.icon} size={15} /> {v.label}
              </button>
            ))}
          </div>

          <div className="schedule-filters__fields">
            <label>
              <span className="student-card__label">Año escolar</span>
              <Select sorted value={periodId} onChange={(e) => setPeriodId(e.target.value)}>
                {(periods || []).map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                    {p.closed_at ? ' (finalizado)' : ''}
                  </option>
                ))}
              </Select>
            </label>

            {view === 'section' || view === 'evaluations' ? (
              <>
                <label>
                  <span className="student-card__label">Grado</span>
                  {/* Sin `sorted`: orden de la jerarquía escolar (1er Grado, 2do Grado…), no alfabético. */}
                  <Select value={gradeId} onChange={(e) => chooseGrade(e.target.value)} disabled={loadingGrades}>
                    <option value="">{loadingGrades ? 'Cargando grados…' : 'Selecciona…'}</option>
                    {byLevel.map((level) => (
                      <optgroup key={level.name} label={level.name}>
                        {level.grades.map((g) => (
                          <option key={g.id} value={g.id}>
                            {g.name}
                            {g.list.length ? '' : ' · sin secciones'}
                          </option>
                        ))}
                      </optgroup>
                    ))}
                  </Select>
                </label>
                <label>
                  <span className="student-card__label">Sección</span>
                  <Select sorted value={sectionId} onChange={(e) => setSectionId(e.target.value)} disabled={!gradeId || !gradeSections.length}>
                    <option value="">{!gradeId ? 'Primero elige el grado' : gradeSections.length ? 'Selecciona…' : 'Sin secciones'}</option>
                    {gradeSections.map((s) => (
                      <option key={s.id} value={s.id}>
                        Sección {s.name}
                      </option>
                    ))}
                  </Select>
                </label>
                {view === 'evaluations' && (
                  <label>
                    <span className="student-card__label">Período</span>
                    <Select value={termNumber} onChange={(e) => setTermNumber(e.target.value)}>
                      <option value="">Todos los períodos</option>
                      {(terms || []).map((t) => (
                        <option key={t.id} value={t.term_number}>
                          {t.name}
                        </option>
                      ))}
                    </Select>
                  </label>
                )}
              </>
            ) : view === 'assignments' ? null : (
              <label className="schedule-filters__teacher">
                <span className="student-card__label">Docente</span>
                <Select sorted value={teacherId} onChange={(e) => setTeacherId(e.target.value)} disabled={loadingTeachers}>
                  <option value="">{loadingTeachers ? 'Cargando docentes…' : 'Selecciona…'}</option>
                  {(teachers || []).map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                      {t.classes ? ` · ${t.classes} h/sem` : ' · sin clases'}
                      {t.active ? '' : ' (inactivo)'}
                    </option>
                  ))}
                </Select>
              </label>
            )}
          </div>
        </div>
      </Card>

      {view === 'teacher' &&
        (teacherId && periodId ? (
          <TeacherScheduleView key={scheduleVersion} periodId={periodId} teacherId={teacherId} onOpenSection={openSection} />
        ) : (
          <p className="text-muted">Elige un docente para ver su semana completa en todas sus secciones, con sus huecos y su carga por día.</p>
        ))}

      {view === 'evaluations' &&
        (sectionId ? (
          <EvaluationCalendar sectionId={sectionId} termNumber={termNumber ? Number(termNumber) : null} />
        ) : (
          <p className="text-muted">
            Elige un grado y su sección para ver su horario de evaluaciones: se arma solo con las fechas de los planes de evaluación y la hora
            del horario de clases.
          </p>
        ))}

      {view === 'assignments' && periodId && (
        <AssignmentsView
          periodId={periodId}
          grades={grades || []}
          teachers={activeTeachers}
          canAssign={canAssign}
          onAssign={assignSubjectTeacher}
          onOpenSection={openSection}
        />
      )}

      {view === 'section' && (
        <>
          <Alert>{error}</Alert>

          {/* Sin bloques horarios no hay grilla: se avisa de entrada y se ofrece copiarlos de otro año. */}
          {noSlots && period && (
            <Card>
              <div className="empty-state">
                <div className="empty-state__icon">
                  <Icon name="clock" size={24} />
                </div>
                <div className="empty-state__title">El año {period.name} aún no tiene bloques horarios</div>
                <div className="text-sm">
                  Define las horas de clase (por ejemplo 07:00–07:45) para todas las secciones del año; luego podrás arrastrar las materias
                  a la grilla.
                </div>
                {user?.coordinator && <div className="text-sm text-muted">La jornada general es de todo el colegio: pídele al Director que la configure, o define la de tu nivel en «Jornada de mi nivel».</div>}
                {can('schedules', 'update') && !user?.coordinator && !period.closed_at && (
                  <div className="empty-state__actions">
                    {slotSource && (
                      <Button icon="layers" onClick={() => copySlotsFrom(slotSource)} loading={copyingSlots} loadingText="Copiando…">
                        Copiar los bloques de {slotSource.name}
                      </Button>
                    )}
                    <Button variant={slotSource ? 'secondary' : 'primary'} icon="clock" onClick={() => setEditingSlots(true)}>
                      Configurar bloques horarios
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* Grado elegido que aún no tiene secciones en el año: el horario es por sección. */}
          {grade && !gradeSections.length && (
            <Card>
              <div className="empty-state">
                <div className="empty-state__icon">
                  <Icon name="layers" size={24} />
                </div>
                <div className="empty-state__title">
                  {grade.name} no tiene secciones en {period?.name}
                </div>
                <div className="text-sm">El horario se arma por sección. Crea la primera para poder asignarle sus clases.</div>
                {can('academics', 'create') && period && !period.closed_at && (
                  <div className="empty-state__actions">
                    <Button icon="plus" onClick={createFirstSection} loading={creatingSection} loadingText="Creando…">
                      Crear la Sección A
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          )}

          {!noSlots && !gradeId && !loading && (
            <p className="text-muted">
              {byGrade.length
                ? 'Elige un grado para abrir su horario: arrastra las materias del panel a la grilla y cada cambio se guarda al instante.'
                : 'Aún no hay grados configurados: créalos en Estructura académica.'}
            </p>
          )}
          {loading && <Spinner label="Cargando horario…" />}

          {data && !loading && data.slots.length > 0 && (
            <div className={`schedule-board ${editable ? '' : 'is-readonly'}`}>
              {editable && (
                <aside
                  className={`schedule-bank ${dragging?.entryId ? 'is-drop-remove' : ''}`}
                  onDragOver={(e) => dragging?.entryId && e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const entry = dragging?.entryId && data.entries.find((x) => x.id === dragging.entryId);
                    setDragging(null);
                    if (entry) remove(entry);
                  }}
                >
                  <div className="schedule-bank__head">
                    <strong>
                      Materias de {data.section.grade_name} {data.section.name}
                    </strong>
                    <span className="text-sm text-muted">Arrastra a la grilla, o tócala y luego toca la celda.</span>
                  </div>
                  {data.bank.length === 0 && (
                    <p className="text-sm text-muted">El grado no tiene plan de estudios: agrégale materias en Grados y secciones.</p>
                  )}
                  {/* Primaria sin docente titular: nadie dicta las materias sin especialista. */}
                  {data.assignment?.mode === 'homeroom' && !data.assignment.lead && data.bank.length > 0 && (
                    <div className="schedule-bank__lead">
                      <span className="teacher-chip teacher-chip--missing">
                        <Icon name="alertTriangle" size={12} /> Sin docente titular
                      </span>
                      <span className="text-sm text-muted">El titular dicta todas las materias que no tienen especialista.</span>
                      {canAssign && <QuickAssign teachers={activeTeachers} onAssign={assignLeadTeacher} label="Asignar titular" />}
                    </div>
                  )}
                  {(() => {
                    const missing = data.bank.filter((b) => !b.teacher_id).length;
                    return missing > 0 ? (
                      <p className="schedule-bank__missing">
                        <Icon name="alertTriangle" size={14} /> {missing} materia{missing === 1 ? '' : 's'} sin profesor: no se pueden poner en el horario hasta asignarlo.
                      </p>
                    ) : null;
                  })()}
                  <ul className="schedule-bank__list">
                    {data.bank.map((b) => {
                      const done = b.weekly_hours && b.placed >= b.weekly_hours;
                      const isSelected = selected && !selected.entryId && selected.subjectId === b.subject_id;
                      return (
                        <li
                          key={b.subject_id}
                          className={`schedule-bank__item ${b.teacher ? '' : 'is-disabled'} ${isSelected ? 'is-selected' : ''} ${done ? 'is-done' : ''}`}
                          style={{ '--entry-hue': hueOf(b.subject_id) }}
                          draggable={Boolean(b.teacher)}
                          onDragStart={(e) => {
                            e.dataTransfer.effectAllowed = 'copyMove'; // compatible con el dropEffect 'move' de las celdas
                            e.dataTransfer.setData('text/plain', b.subject_id);
                            setDragging(itemOfSubject(b));
                          }}
                          onDragEnd={() => setDragging(null)}
                        >
                          {/* div (no <button>): Firefox no inicia el arrastre desde un botón. */}
                          <div
                            role="button"
                            tabIndex={b.teacher ? 0 : -1}
                            className="schedule-bank__card"
                            aria-disabled={!b.teacher}
                            aria-pressed={isSelected}
                            onClick={() => b.teacher && setSelected(isSelected ? null : itemOfSubject(b))}
                            onKeyDown={(e) => {
                              if (b.teacher && (e.key === 'Enter' || e.key === ' ')) {
                                e.preventDefault();
                                setSelected(isSelected ? null : itemOfSubject(b));
                              }
                            }}
                            title={b.teacher ? 'Arrástrala a la grilla, o tócala y luego toca la celda' : 'Asígnale un profesor para poder ponerla en el horario'}
                          >
                            <span className="schedule-bank__name">{b.subject_name}</span>
                            {/* Profesor SIEMPRE visible; sin profesor: aviso + asignación al instante. */}
                            <span className="schedule-bank__teacher">
                              {b.teacher_id ? (
                                <>
                                  <span className="teacher-chip">
                                    <Icon name="user" size={12} /> Prof. {b.teacher_name}
                                  </span>
                                  {b.teacher_source === 'homeroom' && (
                                    <span className="teacher-chip__note" title="Primaria: la dicta el docente titular porque no tiene especialista.">
                                      titular
                                    </span>
                                  )}
                                  {canAssign && (
                                    <QuickAssign
                                      teachers={activeTeachers}
                                      currentId={b.teacher_source === 'subject' ? b.teacher_id : null}
                                      onAssign={(id) => assignSubjectTeacher(sectionId, b.subject_id, id)}
                                      label="Cambiar"
                                      variant="ghost"
                                      allowClear={b.teacher_source === 'subject'}
                                    />
                                  )}
                                </>
                              ) : (
                                <>
                                  <span className="teacher-chip teacher-chip--missing">
                                    <Icon name="alertTriangle" size={12} /> Sin profesor asignado
                                  </span>
                                  {canAssign && (
                                    <QuickAssign teachers={activeTeachers} onAssign={(id) => assignSubjectTeacher(sectionId, b.subject_id, id)} />
                                  )}
                                </>
                              )}
                            </span>
                            <span className={`schedule-bank__hours ${done ? 'is-done' : ''}`}>
                              {b.placed}
                              {b.weekly_hours ? ` / ${b.weekly_hours}` : ''} h
                            </span>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                  {dragging?.entryId && (
                    <div className="schedule-bank__drop">
                      <Icon name="trash" size={16} /> Suelta aquí para quitarla del horario
                    </div>
                  )}
                  <p className="text-sm text-muted schedule-bank__summary">
                    {totalPlaced} de {freeCells} horas de la semana ocupadas.
                  </p>
                </aside>
              )}

              <div className="schedule-main">
                {editable && (
                  <div className="schedule-toolbar">
                    <span className="text-sm text-muted">
                      Suelta sobre una clase para <strong>reemplazarla</strong> (desde el panel) o <strong>intercambiarlas</strong> (moviendo una
                      clase). Para quitar una, usa la × o arrástrala al panel.
                    </span>
                    <SaveIndicator status={saveStatus} />
                  </div>
                )}
                {selected && (
                  <Alert variant="info">
                    Toca la celda donde va <strong>{selected.name}</strong> ({selected.teacher?.name}). Si la celda tiene otra clase, se{' '}
                    {selected.entryId ? 'intercambian' : 'reemplaza'}. Las celdas en rojo son horas en que el profesor ya tiene clase.{' '}
                    <button type="button" className="link-button" onClick={() => setSelected(null)}>
                      Cancelar
                    </button>
                  </Alert>
                )}
                {data.read_only && (
                  <Alert variant="info">
                    Horario de solo lectura
                    {data.section.period_closed_at ? `: el año ${data.section.school_period_name} está finalizado.` : '.'}
                  </Alert>
                )}
                <ScheduleGrid
                  days={data.days}
                  slots={data.slots}
                  entries={data.entries}
                  editable={editable && !saving}
                  cellState={cellState}
                  colorOf={(e) => hueOf(e.subject_id)}
                  onCellDrop={(day, slot) => {
                    const item = dragging;
                    setDragging(null);
                    if (item) placeAt(item, day, slot);
                  }}
                  onCellClick={(day, slot) => {
                    if (selected) placeAt(selected, day, slot);
                  }}
                  onEntryDragStart={(e) => setDragging(itemOfEntry(e))}
                  onEntryDragEnd={() => setDragging(null)}
                  onEntryRemove={remove}
                  removingIds={removingIds}
                  // Tocar una clase: con algo elegido, se coloca ahí (reemplaza/intercambia);
                  // si no, se elige esa clase para moverla (pantallas táctiles, teclado).
                  onEntrySelect={(e) => {
                    if (selected && selected.entryId !== e.id) placeAt(selected, e.day_of_week, { id: e.time_slot_id });
                    else setSelected(selected?.entryId === e.id ? null : itemOfEntry(e));
                  }}
                  selectedEntryId={selected?.entryId}
                  cellHint={(day, slot) => (flash.has(`${day}|${slot.id}`) ? { className: 'is-saved' } : null)}
                />
              </div>
            </div>
          )}
        </>
      )}

      {generating && period && (
        <ScheduleGeneratorModal
          periodId={periodId}
          periodName={period.name}
          grades={grades || []}
          initialGradeId={view === 'section' ? gradeId : ''}
          initialSectionId={view === 'section' ? sectionId : ''}
          onClose={() => setGenerating(false)}
          onOpenAvailability={() => setAvailabilityFor({ teacherId: '' })}
          onApplied={() => {
            setScheduleVersion((v) => v + 1);
            refetchTeachers();
            load(sectionId, { silent: true });
          }}
        />
      )}

      {availabilityFor && period && (
        <TeacherAvailabilityModal
          periodId={periodId}
          // Todas las jornadas del año en una grilla (mismas horas = una fila): la no
          // disponibilidad se aplica por horas en cualquier nivel.
          slots={mergeSlotRows(periodSlots || []).slots}
          teachers={activeTeachers}
          initialTeacherId={availabilityFor.teacherId}
          onClose={() => {
            setAvailabilityFor(null);
            if (sectionId) load(sectionId, { silent: true }); // marca los bloques no disponibles al arrastrar
          }}
        />
      )}

      {editingSlots && period && (
        <SlotsEditorModal
          period={period}
          onlyLevel={user?.coordinator?.level || null}
          onClose={() => setEditingSlots(false)}
          onSaved={() => {
            refetchPeriodSlots();
            load();
          }}
        />
      )}
    </div>
  );
}

/** Estado del último cambio de la grilla: guardando… / guardado ✓ / error. */
function SaveIndicator({ status }) {
  if (!status) return null;
  const view = {
    saving: { icon: null, text: 'Guardando…' },
    saved: { icon: 'checkCircle', text: 'Cambios guardados' },
    error: { icon: 'alertCircle', text: 'No se guardó' },
  }[status];
  return (
    <span className={`save-indicator save-indicator--${status}`} role="status" aria-live="polite">
      {view.icon ? <Icon name={view.icon} size={14} /> : <span className="save-indicator__spinner" aria-hidden="true" />}
      {view.text}
    </span>
  );
}

export default SchedulesPage;

import { rankNote, rankText } from '../../grading/sectionRank';
import { useState } from 'react';
import Badge from '../../../components/ui/Badge';
import Icon from '../../../components/ui/Icon';
import { LevelBadge } from '../../academics/levels';
import { termLabel } from '../../evaluation-plans/terms';
import { recoveredOk, recoveryState } from '../../carryovers/recovery';

const STATUS_VARIANT = { active: 'info', promoted: 'success', retained: 'warning', graduated: 'primary', withdrawn: 'neutral' };

/** "A" → "Sección A"; si ya dice "Sección…", igual. */
const sectionLabel = (name) => (/^secci[oó]n/i.test(name) ? name : `Sección ${name}`);
const fmt = (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString('es', { maximumFractionDigits: 2 }));

/**
 * Historial académico de un alumno: un bloque por año escolar (el más reciente
 * primero) con grado, sección, resultado (Cursando / Promovido / Repite /
 * Egresado / Retirado), promedio y la boleta por materia y período. Los años
 * cerrados muestran la boleta congelada al momento de la promoción.
 * `data` viene de GET /students/:id/academic-history o /portal/students/:id/history.
 * `initiallyOpen`: todos los años desplegados (impresión, "Expandir todo").
 */
function AcademicHistory({ data, initiallyOpen = false }) {
  // Años CERRADOS por defecto: la cabecera resume cada uno (grado, resultado, promedio); se abre el que se quiere ver.
  const [open, setOpen] = useState(() => new Set(initiallyOpen ? (data?.years || []).map((y) => y.enrollment_id) : []));
  if (!data?.years?.length) {
    return (
      <div className="empty-state">
        <div className="empty-state__icon">
          <Icon name="graduation" size={24} />
        </div>
        <div className="empty-state__title">Sin historial académico</div>
        <div className="text-sm">El alumno todavía no ha sido inscrito en ningún año escolar.</div>
      </div>
    );
  }

  const toggle = (id) =>
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <div className="history-years">
      {data.years.map((y) => {
        const isOpen = open.has(y.enrollment_id);
        const termNames = [...new Set(y.subjects.flatMap((s) => s.terms.map((t) => t.term_name)))];
        const headerOf = (name) => name;
        return (
          <section key={y.enrollment_id} className={`history-year ${isOpen ? 'is-open' : ''}`}>
            <button type="button" className="history-year__head" onClick={() => toggle(y.enrollment_id)} aria-expanded={isOpen}>
              <Icon name="chevronDown" size={18} className="history-year__chevron" />
              <span className="history-year__period">{y.school_period.name}</span>
              <span className="history-year__grade">
                {y.grade_name} · {sectionLabel(y.section_name)}
              </span>
              <LevelBadge code={y.level_code} />
              <Badge variant={STATUS_VARIANT[y.status] || 'neutral'}>{y.status_label}</Badge>
              <span className="history-year__avg">
                {y.final_average !== null ? (
                  <>
                    Promedio <strong>{fmt(y.final_average)}</strong>/{data.scale}
                    {y.recalculated && (
                      <span className="history-year__recalc" title={`Promedio original de la boleta: ${fmt(y.original_final_average)}`}>
                        {' '}
                        (con recuperación; original {fmt(y.original_final_average)})
                      </span>
                    )}
                    {y.failed_subjects > 0 && <span className="text-danger"> · {y.failed_subjects} reprobada{y.failed_subjects === 1 ? '' : 's'}</span>}
                  </>
                ) : (
                  <span className="text-muted">Sin notas</span>
                )}
                {y.section_rank && (
                  <span className="history-year__rank">
                    {' '}
                    · Puesto en sección <strong>{rankText(y.section_rank)}</strong>
                    {rankNote(y.section_rank) ? ` (${rankNote(y.section_rank)})` : ''}
                  </span>
                )}
              </span>
            </button>

            {isOpen && (
              <div className="history-year__body">
                {y.frozen ? (
                  <p className="form-hint">
                    <Icon name="lock" size={13} /> Boleta cerrada el {new Date(y.closed_at).toLocaleDateString('es')}: estas notas no cambian.
                    {y.subjects.some((s) => s.recovery) && ' Las materias pendientes muestran aparte su recuperación; si la aprobó, cuenta como aprobada y su nota entra en el promedio.'}
                    {y.outcome_notes && <> Observación: {y.outcome_notes}</>}
                  </p>
                ) : (
                  <p className="form-hint">
                    <Icon name="info" size={13} /> Año en curso: notas acumuladas hasta hoy.
                  </p>
                )}
                {y.subjects.length === 0 ? (
                  <p className="text-muted text-sm">No hay calificaciones registradas en este año.</p>
                ) : (
                  <div className="table-wrap">
                    <table className="table history-table">
                      <thead>
                        <tr>
                          <th>Materia</th>
                          {termNames.map((t) => (
                            <th key={t} style={{ textAlign: 'center' }}>
                              {headerOf(t)}
                            </th>
                          ))}
                          <th style={{ textAlign: 'center' }}>Final</th>
                          <th>Estado</th>
                        </tr>
                      </thead>
                      <tbody>
                        {y.subjects.map((s) => (
                          <tr key={s.subject_key}>
                            <td className="cell-person__name">{s.subject_name}</td>
                            {termNames.map((t) => {
                              const term = s.terms.find((x) => x.term_name === t);
                              return (
                                <td key={t} style={{ textAlign: 'center' }}>
                                  {term ? fmt(term.grade) : <span className="text-muted">—</span>}
                                </td>
                              );
                            })}
                            <td style={{ textAlign: 'center' }}>
                              <strong className={s.passed === false && !recoveredOk(s) ? 'text-danger' : undefined}>{fmt(s.final_grade)}</strong>
                              {recoveredOk(s) && <span className="history-recovery__grade">{fmt(s.recovery.grade)}</span>}
                            </td>
                            <td>
                              {recoveryState(s) ? (
                                <>
                                  <Badge variant={recoveryState(s).variant}>{recoveryState(s).label}</Badge>
                                  <span className="cell-person__sub history-recovery__note">{recoveryState(s).note}</span>
                                </>
                              ) : s.passed === null ? (
                                <span className="text-muted text-sm">Sin notas</span>
                              ) : s.passed ? (
                                <Badge variant="success">Aprobada</Badge>
                              ) : (
                                <Badge variant="danger">Reprobada</Badge>
                              )}
                              {!s.complete && s.passed !== null && <span className="cell-person__sub">Notas incompletas</span>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}

export default AcademicHistory;
